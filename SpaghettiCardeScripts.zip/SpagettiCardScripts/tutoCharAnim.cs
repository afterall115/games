using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tutoCharAnim : MonoBehaviour
{
    public Animator tutoAnim;
    public int tutoAnimChange;
    [SerializeField] float tutoTime;
    private void Update()
    {
        tutoTime += 0.01f;
        if (tutoTime > 70f)
        {
            tutoAnimChange = Random.Range(0, 2);
            Debug.Log(tutoAnimChange);
            if (tutoAnimChange == 0)
            {
                tutoAnim.SetInteger("paka", 1);
                tutoTime = 0;
            }
            if (tutoAnimChange == 1)
            {
                tutoAnim.SetInteger("paka", 0);
                tutoTime = 0;
            }

        }
    }
}
