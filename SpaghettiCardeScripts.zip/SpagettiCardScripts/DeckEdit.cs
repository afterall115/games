using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class DeckEdit : MonoBehaviour
{
    public GameData gameData;
    public GameObject deckEdit;
    public GameObject popUp;
    public CardDataBase cardLib;
    private DeckScript main;
    public List<int> deckEditDeck;
    public List<int> deckEditCard;
    public string[] deckText;
    //�f�b�L�z���N�Ԗڂ̃f�b�L���Q�Ƃ���
    public int deckIndex;
    private void Awake()
    {
        deckIndex = 0;
        //���݂̃f�b�L�ƃJ�[�h�v�[����ҏW�pList��
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        deckEditDeck.AddRange(gameData.myDecks[deckIndex].myDeck);
    }
    private void Start()
    {
       
        for (int i = 0; i < cardLib.cardList.Count; i++)
        {
            deckEditCard.Add(i);
        }
        if (deckEditCard.Count == 0)
        {
            for (int i = 0; i < cardLib.cardList.Count; i++)
            {
                deckEditCard.Add(i);
            }
        }
        if (deckEditDeck.Count == 0)
        {
            deckEditDeck.AddRange(gameData.myDecks[deckIndex].myDeck);
        }

    }
}
