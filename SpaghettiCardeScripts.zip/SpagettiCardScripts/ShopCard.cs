using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShopCard : MonoBehaviour
{
    public CardDataBase cardLib;
    public int cardId;
    public int myPrice;
    public Text myPricePrint;
    private GameData gameData;
    private GameObject clone;
    public GameObject pop;
    private GameObject yes;
    private ShopCard yesData;
    public ShopManager cardChange;
    public int select;
    [Space(20)]
    [TextArea(3,4)]
    public string cardText;

    [SerializeField]
    private PopManager popMana;

    private void Start()
    {
    }
    public void SelectWindow()
    {
        popMana = GameObject.Find("PopUpManager").GetComponent<PopManager>();
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        if (cardLib.cardList[this.cardId].bought == false && gameData.myCoins >= myPrice)
        {
            pop.SetActive(true);
            yes = pop.transform.GetChild(0).gameObject;
            yesData = yes.GetComponent<ShopCard>();
 
            yesData.myPrice = this.myPrice;
            yesData.cardId = this.cardId;
            yesData.pop = this.pop;
            yesData.select = this.select;

            popMana.OnUpFlag();
        }
       
    }

    public void ShpoCard()
    {
        cardChange= GameObject.Find("ShopBack").GetComponent<ShopManager>();
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        if (cardLib.cardList[this.cardId].bought == false && gameData.myCoins >= myPrice)
        {
            gameData.myCoins -= myPrice;
            cardLib.cardList[this.cardId].bought = true;
            //cardLib.cardList[this.cardId].hasCard = 3;
            cardChange.shopObject[select].GetComponent<Image>().color=new Color(0.7f, 0.7f, 0.7f, 0.7f);
        }
       
    }
    public string effectText { get { return cardText; } set { cardText = value; } }
}
