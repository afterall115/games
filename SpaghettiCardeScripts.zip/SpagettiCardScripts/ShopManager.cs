using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShopManager : MonoBehaviour
{
    public Text myCoins;
    public GameData gameData;
    public Text CardText;
    public List<GameObject> shopObject;
    public FocusShopManager TxtCh;
    private void Update()
    {
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        myCoins.text = gameData.myCoins.ToString();

    //�I�������J�[�h�̐������ɃJ�G��
            CardText.text = shopObject[TxtCh.selectNumber].GetComponent<ShopCard>().cardText;
        
    }
}
