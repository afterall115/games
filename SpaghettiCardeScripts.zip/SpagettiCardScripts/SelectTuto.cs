using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class SelectTuto : MonoBehaviour
{
    public GameObject buttonTutoWindow;
    private EventSystem eveSys;
    private GameObject nextSelect;
    [SerializeField]
    string[] tutoText; // ���͂��i�[����
    [SerializeField] Text uiText;   // uiText�ւ̎Q��
    [SerializeField] Image tutoChar;
    public GameData gameData;
    public GameObject tutoPanel;
    public GameManager gameManager;
    public enum Tutoreal
    {
        Select,
        Stage1,
        Stage2,
        Stage3,
        Stage4,
        End,
    }
    //[SerializeField]
    //[Range(0.001f, 0.3f)]
    //float intervalForCharDisplay = 0.05f;   // 1�����̕\���ɂ����鎞��
    public Tutoreal nowTuto;
    private int currentSentenceNum = 0; //���ݕ\�����Ă��镶�͔ԍ�

    private void Start()
    {
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        if (gameData.nowTuto == Tutoreal.Select)
        {
            tutoPanel.SetActive(true);
            tutoChar.gameObject.SetActive(true);
            uiText.gameObject.SetActive(true);
            uiText.text = tutoText[currentSentenceNum];
            eveSys = GameObject.Find("EventSystem").GetComponent<EventSystem>();
            nextSelect = eveSys.firstSelectedGameObject;
            EventSystem.current.SetSelectedGameObject(buttonTutoWindow);
        }
        else
        {
            tutoPanel.SetActive(false);
            gameObject.SetActive(false);
            tutoChar.gameObject.SetActive(false);
            uiText.gameObject.SetActive(false);
        }
    }
   
    public void TextChange()
    {
        currentSentenceNum++;
        if (tutoText.Length == currentSentenceNum)
        {
            tutoPanel.SetActive(false);
            uiText.gameObject.SetActive(false);
            tutoChar.gameObject.SetActive(false);
            gameData.nowTuto = Tutoreal.Stage1;
            gameManager.LoadScene("1-1");
        }
        else
        {
            uiText.text = tutoText[currentSentenceNum];  
        }
    }

}



