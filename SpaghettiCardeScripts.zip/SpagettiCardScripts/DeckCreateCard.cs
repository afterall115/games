using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class DeckCreateCard : MonoBehaviour
{
    public GameObject cardImage;
    public Transform deckParent;
    public Transform editParent;
    public CardDataBase cardLib;
    private CardScript cardScript;
    private GameObject clone;
    private DeckEdit deckEdit;
    private cloneId cloneIdComponent;
    private Image cloneImageComponent;
    private int cardId;
    public string[] deckCardText;�@//529
    public FocusDeckEdit fDE;

    void Start()
    {
        deckEdit = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();

        fDE = GameObject.Find("FocusDeckEdit").GetComponent<FocusDeckEdit>();


        for (int i = 0; i < deckEdit.deckEditDeck.Count; i++)
        {
            
            //�N���[���̐���
            Sprite cardSprite = cardLib.cardList[deckEdit.deckEditDeck[i]].cardSprite;

            clone = Instantiate(cardImage, deckParent);
            cloneIdComponent = clone.GetComponent<cloneId>();
            cloneImageComponent = clone.GetComponent<Image>();
            cloneIdComponent.cardId = deckEdit.deckEditDeck[i];
            cloneIdComponent.deckParent = deckParent;
            cloneIdComponent.editParent = editParent;
            cloneImageComponent.sprite = cardSprite;

            clone.name = cardLib.cardList[deckEdit.deckEditDeck[i]].cardScript.name;
            cardLib.cardList[deckEdit.deckEditDeck[i]].hasCard--;
            cloneIdComponent.cardText = deckCardText[cloneIdComponent.cardId];

            fDE.deckList.Add(clone);


            //�J�[�h�����L���ĂȂ�������f�b�L�������
            if (cardLib.cardList[deckEdit.deckEditDeck[i]].hasCard < 0)
            {
                cardLib.cardList[deckEdit.deckEditDeck[i]].hasCard = 0;
                Destroy(clone);

                fDE.deckList.Remove(clone);
            }
        }
        
    }
}

