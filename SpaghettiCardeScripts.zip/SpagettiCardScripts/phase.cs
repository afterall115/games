using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class phase : MonoBehaviour
{
    public MainGameScript main;
    public Animator anim;
    void PhaseDes()
    {
        anim.SetBool("phase", false);
        anim.SetBool("mainPhase", false);
        gameObject.SetActive(false);
    }
}


