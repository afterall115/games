using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainGameScript : MonoBehaviour
{
    public CardDataBase cardLib;
    public GameData gameData;

    public DeckScript scriptDeck;
    public HandScript scriptHand;

    public PlayerScript player;

    public List<int> Log;
    public List<int> deletLog;
    public List<int> deck;
   
    public List<GimmickScript> gimmick;
    [SerializeField]
    GameObject[] gimmickList;

    public int deckNumber;

    public static int totalTurn;
    [SerializeField]
    public int act;
    public int cardUsed;

    public int gimmicCount;
    public int nowCost;
    public static int totalCost;
   
    public bool shuffleCmp;

    public bool playCode;

    public Camera cardCamera;

    //bool testGimmick = false;   //�M�~�b�N�̃t���O���u��
    //�^�[���e�L�X�g
    public Text trun;
    //�`���[�g���A��
    public GameObject tutoPanel;
    public GameObject tutoCanvas;
    [SerializeField]
    string[] tutoText; // ���͂��i�[����
    [SerializeField] Text uiText;   // uiText�ւ̎Q��
    [SerializeField] Image tutoChar;
    public int currentSentenceNum = 0; //���ݕ\�����Ă��镶�͔ԍ�
    public bool standPhase;
    //�t�F�C�Y�̕\��
    public Text printPhase;
    public GameObject phaseImage;
    public Animator anim;//�t�F�C�Y�p�A�j���[�^�[
    private Animator animator;
    public bool PhaseFlag;
    public Image imagePhase;

    //�{��
    private GameManager gameMana;

    //�{���t���O
    private bool doubleSpeedFlag;

    public AudioClip s_shuffle;//�~���x
    public AudioClip s_phase;   //�~���x
    public AudioClip s_decide;  //�~���x
    AudioSource m_audioSource;  //�~���x

    public enum Phase
    {
        Standby = 0,    //�����h���[
        Draw = 1,       //�}���K���h���[
        Main = 2,       //�J�[�h�I��
        Reset = 3,      //�v���C���[�ƃM�~�b�N�̍��W���Z�b�g
        Act = 4,        //�v���C�{�^�������Ă���^�[���I���܂�
        End = 5         //�I������(���邩�m��񂯂ǈꉞ)
    }
    public Phase phase;

    private void Start()
    {
        totalCost = 0;
        totalTurn = 0;
        cardUsed = 0;
        anim = phaseImage.GetComponent<Animator>();
        phase = Phase.Standby;
        
        player = GameObject.Find("Player").GetComponent<PlayerScript>();
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        m_audioSource = GetComponent<AudioSource>();//�~���x
        gameMana = GameObject.Find("GameManager").GetComponent<GameManager>();

        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1 ||
            gameData.nowTuto == SelectTuto.Tutoreal.Stage2)
        {
            tutoCanvas.SetActive(true);
            uiText.text = tutoText[currentSentenceNum];
        }
       //===============GameData�̃f�b�L===========================
        for(int i=0;i<gameData.myDecks[deckNumber].myDeck.Count;i++)
        {
            deck.Add(gameData.myDecks[deckNumber].myDeck[i]);
        }
    }

    private void FixedUpdate()
    {
       
        if (doubleSpeedFlag)
        {
            Time.timeScale = 2;
        }
        else
        {
            Time.timeScale = 1;
        }

        if (phase == Phase.Standby)
        {
            totalTurn++;
            Shuffle();

            ///HandID�̊��蓖��
            if (scriptHand.objHand.Count > 0)
            {
                for (int i = 0; i < scriptHand.hand.Count; i++)
                {
                    scriptHand.objHand[i].GetComponent<CardScript>().handID = i;
                }
            }
            phase = Phase.Draw;
        }

        if (phase == Phase.Draw)
        {
            if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1 && currentSentenceNum == 0)
            {
                phaseImage.SetActive(false);
            }
            if (PhaseFlag == false)
            {
                phaseImage.SetActive(true);
                anim.SetBool("phase", true);

                PhaseFlag = true;
            }

            if (scriptHand.hand.Count < 5)
            {
                int j = scriptHand.hand.Count;
                for (int i = 0; i < 5 - j; i++)
                {
                    DrawCard();
                    m_audioSource.PlayOneShot(s_shuffle);
                }
            }
            if (Input.GetKey(KeyCode.Return))
            {
                handDelete();
                Shuffle();
                ///HandID�̊��蓖��
                if (scriptHand.objHand.Count > 0)
                {
                    for (int i = 0; i < scriptHand.hand.Count; i++)
                    {
                        scriptHand.objHand[i].GetComponent<CardScript>().handID = i;
                    }
                }
                int j = scriptHand.hand.Count;
                for (int i = 0; i < 5 - j; i++)
                {
                    DrawCard();
                }
                if (PhaseFlag == true)
                {
                    phaseImage.SetActive(true);
                    anim.SetBool("mainPhase", true);
                    m_audioSource.PlayOneShot(s_phase);//�~���x
                    PhaseFlag = false;
                }
                phase = Phase.Main;
            }
        }
       
        if (Input.GetKey(KeyCode.P) && phase == Phase.Main)
        {
            act = 0;
            GameObject.Find("Player").transform.position = GameObject.Find("Start").transform.position;
            gimmickList = GameObject.FindGameObjectsWithTag("Gimmick");
            for (int i = 0; i < gimmickList.Length; i++)
            {
                gimmick.Add(gimmickList[i].GetComponent<GimmickScript>());
                gimmick[i].transform.position = gimmick[i].enemySetPosition;
            }
            for (int i = 0; i < gimmickList.Length; i++)
            {
                gimmick.Add(gimmickList[i].GetComponent<GimmickScript>());
                gimmick[i].transform.position = gimmick[i].blockPos;
            }

            player.finAction = false;
            //=======================�R�X�g
            totalCost += nowCost;
            nowCost = 0;
            //========================
         

            Invoke("PlayTrue", 1.0f);
            phase = Phase.Reset;
        }

        //�Đ��{�^��������
        if (playCode == true && phase == Phase.Act)
        {
            if (player.setStart == false)
            {
                player.SetStart(true);
                gimmickList = GameObject.FindGameObjectsWithTag("Gimmick");
            }
            if (gimmickList.Length > 0)
            {
                if (gimmick.Count != gimmickList.Length)
                {
                    for (int i = 0; i < gimmickList.Length; i++)
                    {
                        gimmick.Add(gimmickList[i].GetComponent<GimmickScript>());
                        if (gimmick[i].setStart == false)
                        {
                            gimmick[i].SetStart(true);
                        }
                    }
                }

                if (player.finAction == false && gimmick.Count > gimmicCount)
                {
                    player.MovePlayer(Log[act]);

                }
                if (player.finAction == true && gimmick.Count > gimmicCount)
                {
                    for (int i = 0; i < gimmick.Count; i++)
                    {
                        gimmick[i].MoveGimmick();
                    }
                }

                if (player.finAction == true && gimmick.Count == gimmicCount)
                {
                    player.setStart = false;

                    for (int i = 0; i < gimmick.Count; i++)
                    {
                        gimmick[i].setStart = false;
                    }

                    if (act < Log.Count - 1)
                    {
                        player.finAction = false;
                        player.jump = false;
                        player.YFlag = false;

                        for (int i = 0; i < gimmick.Count; i++)
                        {
                            gimmick[i].finAction = false;
                        }
                        act++;
                        gimmicCount = 0;
                        gimmick.Clear();
                    }
                    else
                    {
                        for (int i = 0; i < gimmick.Count; i++)
                        {
                            gimmick[i].finAction = false;
                            gimmick[i].enemy2AttackLeft = false;
                            gimmick[i].enemy2AttackRight = false;
                            gimmick[i].enemy3DffenceFlag = false;
                        }

                        if (player.goalFlag == true)
                        {
                            if (gameData.nowTuto == SelectTuto.Tutoreal.End)
                            {
                                gameData.totalCost = totalCost;
                                gameData.totalTurn = totalTurn;
                                gameData.cardUsed = cardUsed;
                                gameData.retryScene = SceneManager.GetActiveScene().name;
                                gameData.nextScene = SceneManager.GetActiveScene().buildIndex + 1;
                                GameObject.Find("GameManager").GetComponent<GameManager>().LoadScene("Result");
                            }
                            else
                            {
                                if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage2;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage2)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage3;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage3)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage4;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage4)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.End;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().LoadScene("Result");
                                }
                            }
                        }
                        act = 0;
                        playCode = false;
                        player.jump = false;
                        player.YFlag = false;
                        player.hoverFlag = false;
                        player.rb.constraints = RigidbodyConstraints2D.FreezeRotation;
                        gimmicCount = 0;
                        gimmick.Clear();
                        phase = Phase.End;

                    }
                }
            }
            else
            {
                if (player.finAction == false)
                {
                    player.MovePlayer(Log[act]);
                }

                if (player.finAction == true)
                {
                    player.setStart = false;
                    player.rb.constraints = RigidbodyConstraints2D.FreezeRotation;

                    if (act < Log.Count - 1)
                    {
                        player.finAction = false;
                        player.jump = false;

                        act++;
                    }
                    else
                    {
                        if (player.goalFlag == true)
                        {
                            if (gameData.nowTuto == SelectTuto.Tutoreal.End || gameData.nowTuto == SelectTuto.Tutoreal.Stage4)
                            {
                                gameData.nowTuto = SelectTuto.Tutoreal.End;
                                gameData.totalCost = totalCost;
                                gameData.totalTurn = totalTurn;
                                gameData.cardUsed = cardUsed;
                                gameData.retryScene = SceneManager.GetActiveScene().name;
                                gameData.nextScene = SceneManager.GetActiveScene().buildIndex + 1;
                                GameObject.Find("GameManager").GetComponent<GameManager>().LoadScene("Result");
                            }
                            else
                            {
                                if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage2;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage2)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage3;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage3)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.Stage4;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().NextScene(SceneManager.GetActiveScene().buildIndex + 1);
                                }
                                else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage4)
                                {
                                    gameData.nowTuto = SelectTuto.Tutoreal.End;
                                    GameObject.Find("GameManager").GetComponent<GameManager>().LoadScene("Result");
                                }
                            }
                        }
                        act = 0;
                        playCode = false;
                        player.jump = false;
                        phase = Phase.End;

                    }
                }
            }
        }
    }
    private void Update()
    {
        if (phase == Phase.End)
        {
            handDelete();
            phase = Phase.Standby;
            Debug.Log(phase);
        }
        if (phase == Phase.Main || phase == Phase.Draw) 
        {
            cardCamera.enabled = true;
        }
        else
        {
            cardCamera.enabled = false;   
        }
      
    }
    void SetDeck()
    {
        for (int i = 0; i < scriptDeck.myDecks[deckNumber].myDeck.Count; i++)
        {
            deck.Add(scriptDeck.myDecks[deckNumber].myDeck[i]);
        }
    }
    void DrawCard()
    {
        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1)
        {
            deck.Clear();
            for (int i = 0; i < 3; i++)
            {
                deck.Add(0);
                deck.Add(1);
            }
            Shuffle();
        }
        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage2)
        {
            deck.Clear();
            for (int i = 0; i < 3; i++)
            {
                deck.Add(0);
                deck.Add(1);
                deck.Add(2);
                deck.Add(3);
            }
            Shuffle();
        }
        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage3)
        {
            deck.Clear();
            for (int i = 0; i < 3; i++)
            {
                deck.Add(0);
                deck.Add(1);
                deck.Add(2);
                deck.Add(3);
            }
            Shuffle();
        }
        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage4)
        {
            deck.Clear();
            for (int i = 0; i < 3; i++)
            {
                deck.Add(0);
                deck.Add(1);
                deck.Add(2);
                deck.Add(3);
            }
            Shuffle();
        }
        scriptHand.hand.Add(deck[0]);
        GameObject clone = Instantiate(cardLib.cardList[deck[0]].cardScript.gameObject, transform);
        clone.name = cardLib.cardList[deck[0]].cardScript.gameObject.name;
        clone.transform.parent = GameObject.Find("Cards").transform;
        clone.GetComponent<CardScript>().handID = scriptHand.hand.Count - 1;

        scriptHand.objHand.Add(clone);

        deck.RemoveAt(0);
    }
    public void PlayTrue()
    {
        if (phase == Phase.Draw)
        {
            handDelete();
            Shuffle();
            ///HandID�̊��蓖��
            if (scriptHand.objHand.Count > 0)
            {
                for (int i = 0; i < scriptHand.hand.Count; i++)
                {
                    scriptHand.objHand[i].GetComponent<CardScript>().handID = i;
                }
            }
            int j = scriptHand.hand.Count;
            for (int i = 0; i < 5 - j; i++)
            {
                DrawCard();
            }
            if (PhaseFlag == true)
            {
                Debug.Log("main");
                phaseImage.SetActive(true);
                anim.SetBool("mainPhase", true);
                m_audioSource.PlayOneShot(s_phase);//�~���x
                PhaseFlag = false;
            }
            phase = Phase.Main;

        }
        else
        {
            if (Log.Count > 0)
            {
         
                act = 0;
                GameObject.Find("Player").transform.position = GameObject.Find("Start").transform.position;
                player.finAction = false;
                //=======================�R�X�g
                totalCost += nowCost;
                nowCost = 0;
                //========================
                Invoke("PlayCodeChanger", 1.0f);
                phase = Phase.Reset;


                gimmickList = GameObject.FindGameObjectsWithTag("Gimmick");
            }
            else
            {
                phase = Phase.End;
            }
        }
    }
    void PlayCodeChanger()
    {
        playCode = true;
        phase = Phase.Act;
    }

    //�w��̎�D���폜
    void handDelete()
    {
        if (deletLog.Count > 0)
        {
            deletLog.Sort((a, b) => b - a);
            for (int i = 0; i < deletLog.Count; i++)
            {

                if (scriptHand.hand.Count == 0)
                {
                    break;
                }
                scriptHand.hand.RemoveAt(deletLog[i]);
                scriptHand.objHand.RemoveAt(deletLog[i]);
                Debug.Log(deletLog[i]);
            }
            deletLog.Clear();
            Debug.Log(phase.ToString());
        }
       
    }
    /// <summary>
    /// �V���b�t��������
    /// </summary>
    void Shuffle()
    {
        for (int i = 0; i < deck.Count; i++)
        {
            //�i�����P�j���݂̗v�f��a���Ă���
            int temp = deck[i];
            //�i�����Q�j����ւ����������_���ɑI��
            int randomIndex = UnityEngine.Random.Range(0, deck.Count);
            //�i�����R�j���݂̗v�f�ɏ㏑��
            deck[i] = deck[randomIndex];
            //�i�����S�j����ւ����ɗa���Ă������v�f��^����
            deck[randomIndex] = temp;
        }
    }
    public void TextChangeStage()
    {
        currentSentenceNum++;
        if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1)
        {
            if (currentSentenceNum == 1)
            {
                phaseImage.SetActive(true);
                anim.SetBool("phase", true);
                PhaseFlag = true;
            }
            if (currentSentenceNum == 3)
            {
                phaseImage.SetActive(true);
                anim.SetBool("mainPhase", true);
                PhaseFlag = false;
            }
        }

        if (tutoText.Length == currentSentenceNum)
        {
            if (gameData.nowTuto == SelectTuto.Tutoreal.Stage1)
            {
                phaseImage.SetActive(true);
                anim.SetBool("phase", true);
                PhaseFlag = true;
                tutoCanvas.SetActive(false);
            }
            else if (gameData.nowTuto == SelectTuto.Tutoreal.Stage2)
            {
                tutoCanvas.SetActive(false);
            }


        }
        else
        {
            uiText.text = tutoText[currentSentenceNum];
        }
    }
    public int GetTotalTurn()
    {
        return totalTurn;
    }
}

