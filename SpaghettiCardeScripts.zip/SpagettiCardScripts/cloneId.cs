using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cloneId : MonoBehaviour
{
    public Transform editParent;
    public Transform deckParent;
    private DeckEdit deckEdit;
    public CardDataBase cardLib;
    public GameObject cardImageCurrent;
    public GameObject cardImageNext;
    private GameObject clone;
    public bool cardUse;
    public int cardId;
    public string cardText;
    private FocusDeckEdit fDE;
    public DeckEdit dE;
    private void Start()
    {
        fDE = GameObject.Find("FocusDeckEdit").GetComponent<FocusDeckEdit>();
        dE = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();
    }
    //�N���b�N���̃N���[������
    public void EditUI()
    {
        if (cardLib.cardList[this.cardId].hasCard>=1)
        {
            //�J�[�h�ꗗ�ŃN���b�N��
            if (cardUse == true)
            {
                cardLib.cardList[cardId].hasCard--;
                Sprite cardSprite = cardLib.cardList[cardId].cardSprite;

                clone = Instantiate(cardImageNext, deckParent);

                clone.GetComponent<cloneId>().cardId = cardId;
                clone.GetComponent<cloneId>().deckParent = this.deckParent;
                clone.GetComponent<cloneId>().editParent = this.editParent;
                clone.GetComponent<Image>().sprite = cardSprite;
                clone.name = cardLib.cardList[cardId].cardScript.name;
                clone.GetComponent<cloneId>().cardText = dE.deckText[cardId];
                fDE.deckList.Add(clone);

                clone.SetActive(true);
            }
           
        }
       
    }
    //�J�[�h�v�[���ŃN���b�N���ɏ���
    public void PickUp()
    {
        deckEdit = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();
        if (cardLib.cardList[this.cardId].hasCard >= 1)
        {
            deckEdit.deckEditDeck.Add(cardId);
           // deckEdit.deckEditCard.Remove(cardId);

        
            //�A�C�e���̎擾
            //Destroy(this.gameObject);

            cardUse = true;
        }
    }
    //�f�b�L�ҏW�ŃN���b�N���ɏ���
    public void PickUp1()
    {
        deckEdit = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();
       // deckEdit.deckEditCard.Add(cardId);
        deckEdit.deckEditDeck.Remove(cardId);
        cardLib.cardList[cardId].hasCard++;
        
        //fDE.deckList.Remove(clone);
        fDE.deckList.RemoveAt(fDE.listIndex);
        //fDE.deckList[fDE.listIndex]=null;


        //�A�C�e���̎擾
        Destroy(this.gameObject);

        Debug.Log("����");

        fDE.RewriteSelect();
       // cardUse = false;
    }

}





