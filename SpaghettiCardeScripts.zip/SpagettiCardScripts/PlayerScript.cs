using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    public Rigidbody2D rb;

    public CardDataBase cardLib;
    public bool jump;
    public bool finAction;
    public bool setStart = false;
    public bool goalFlag;
    public bool landing;

    public Vector2 StartPosition;
    public Vector2 ResetPosition;

    private float baseSpeed = 20.0f;
    private float baseJump = 50.0f;
    private Animator animator;

    public float timer;
    //=======================
    public bool YFlag;
    public bool hoverFlag;
    public bool reversalFlag;
    public bool hoge;
    // public int  reversalTimes;
    public int moveRot;
    public bool doubleFlag;
    public int movepos;
    public float jumppos;
    public float jumppos2;
    public bool forFlag;
    public int forCount;
    public MainGameScript main;
    public bool charge;
    public bool beam;
    public GameObject beamPrehab;
    public bool StanFlag;
    public bool CamouflageFlag;
    public bool parent;
    public bool gimmick;
    public GameObject enemy;
    public GameObject enemy2;
    public GameObject enemy3;
    private GimmickScript g_enemy3;
    public GameObject warp;
    public GameObject move;

    //SE
    public AudioClip s_move;
    public AudioClip s_jump;
    public AudioClip s_jump2;
    public AudioClip s_beam;
    public AudioClip s_vanish;
    public AudioClip s_hober;
    public AudioClip s_stan;
    public AudioClip s_warp;
    public AudioClip s_power;
    public AudioClip s_attack;
    public AudioClip s_goal;
    AudioSource p_audioSource;

    private void Start()
    {
        jumppos = 1.1f;
        jumppos2 = 0.55f;
        movepos = 20;
        animator = GetComponent<Animator>();
        p_audioSource = GetComponent<AudioSource>();

        goalFlag = false;
        forFlag = false;
        moveRot = 0;
        doubleFlag = false;
        forCount = 0;
        hoge = false;
        charge = false;
        beam = false;
    }

    public void SetStart(bool setStartBool)
    {
        StartPosition = transform.position;
        setStart = setStartBool;
        timer = 0;
    }

    public void MovePlayer(int id)
    {
        timer += Time.deltaTime;

        //��������
        if(transform.position.y <= -30)
        {
            finAction = true;
            GetComponent<GimmickScript>().ResetPlayer();
            GetComponent<GimmickScript>().StartCoroutine("Coroutine");
        }

        //���A�j��������
        animator.SetBool("walkLeft", false);
        animator.SetBool("jumpLeftVer", false);
        animator.SetBool("jumpLeft", false);
        animator.SetBool("deathLeft", false);
        animator.SetBool("stealthLeft", false);
        animator.SetBool("stealthWaitLeft", false);
        animator.SetBool("restartLeft", false);
        animator.SetBool("limitJumpLeft", false);
        animator.SetBool("beamLeft", false);
        animator.SetBool("stunLeft", false);
        animator.SetBool("restartLeft", false);


        //�E�A�j��������
        animator.SetBool("standRight", false);
        animator.SetBool("walk", false);
        animator.SetBool("jumpVer", false);
        animator.SetBool("jump", false);
        animator.SetBool("death", false);
        animator.SetBool("stealth", false);
        animator.SetBool("stealthWait", false);
        animator.SetBool("restart", false);
        animator.SetBool("limitJump", false);
        animator.SetBool("rush", false);
        animator.SetBool("beam", false);
        animator.SetBool("doubleCast", false);
        animator.SetBool("stun", false);

        //�z�Q
        if (cardLib.cardList[id].cardScript.Status.livID == 0)
        {
            hoge = true;
            if (timer > 3.0f)
            {
                finAction = true;
            }
        }

        //�X�^�[�g�ɖ߂�J�[�h
        if (cardLib.cardList[id].cardScript.Status.livID == 14)
        {
            animator.SetBool("jumpVer", false);
            animator.SetBool("limitJumpLeft", true);
            p_audioSource.PlayOneShot(s_warp);
            Invoke("ReStart", 0.8f);
            finAction = true;

        }
        //Y���
        if (cardLib.cardList[id].cardScript.Status.livID == 15)
        {
            animator.SetBool("limitJumpLeft", true);
            p_audioSource.PlayOneShot(s_warp);
            if (this.transform.position.y < 250 && YFlag == false)
            {
                Invoke("YWarp", 1.5f);
            }
        }
        //�z�o�[
        if (cardLib.cardList[id].cardScript.Status.livID == 7)
        {
            Hover();
        }
        //�������]
        if (cardLib.cardList[id].cardScript.Status.livID == 10)
        {
            reversalFlag = true;
            if (enemy == null || enemy2 == null || enemy3 == null || warp == null || move == null)
            {
                finAction = true;
            }
            else
            {
                main.gimmicCount = main.gimmick.Count; //�G�𓮂����Ȃ����߂̏���
                finAction = true;
            }
        }
        if (reversalFlag == true)
        {
            moveRot = cardLib.cardList[id].cardScript.Status.move * -1;
        }
        //�ړ�2�{
        if (cardLib.cardList[id].cardScript.Status.livID == 11)
        {
            movepos = movepos * 2;
            jumppos = jumppos * 2;
            jumppos2 = jumppos2 * 2;
            doubleFlag = true;
            animator.SetTrigger("doubleCastLeft");
            p_audioSource.PlayOneShot(s_power);

            if (enemy == null || enemy2 == null || enemy3 == null || warp == null || move == null)
            {
                finAction = true;
            }
            else
            {
                main.gimmicCount = main.gimmick.Count; //�G�𓮂����Ȃ����߂̏���
                finAction = true;
            }

        }
        //for�J�[�hn����s
        if (forCount > 0)
        {
            forCount--;
            main.Log.Add(cardLib.cardList[id].cardScript.Status.livID);
        }
        //for3
        if (cardLib.cardList[id].cardScript.Status.livID == 12)
        {
            animator.SetTrigger("doubleCastLeft");
            p_audioSource.PlayOneShot(s_power);
            forCount = 2;
            forFlag = true;
            main.gimmicCount = main.gimmick.Count;
            finAction = true;
        }
        //for5
        if (cardLib.cardList[id].cardScript.Status.livID == 13)
        {
            animator.SetTrigger("doubleCastLeft");
            p_audioSource.PlayOneShot(s_power);
            forCount = 4;
            forFlag = true;
            main.gimmicCount = main.gimmick.Count;
            finAction = true;
        }
        //�`���[�W�A�^�b�N
        if (cardLib.cardList[id].cardScript.Status.livID == 8)
        {
            charge = true;
        }
        //�r�[��
        if (cardLib.cardList[id].cardScript.Status.livID == 9)
        {

            //if(timer > 3.0f)
            //{
                BeamAttack();
                
            //}
         
        }
        //�X�^��
        if (cardLib.cardList[id].cardScript.Status.livID == 16)
        {
            animator.SetBool("jumpVer", false);
            animator.SetBool("stunLeft", true);
            p_audioSource.PlayOneShot(s_stan);
            StanFlag = true;
            main.gimmicCount = main.gimmick.Count;
            finAction = true;
            animator.SetBool("stunLeft", false);

        }
        //���w����
        if (cardLib.cardList[id].cardScript.Status.livID == 17)
        {
            animator.SetBool("jumpVer", false);
            animator.SetBool("stealthLeft", true);
            p_audioSource.PlayOneShot(s_vanish);
            CamouflageFlag = true;
            main.gimmicCount = main.gimmick.Count;
            finAction = true;
            animator.SetBool("stealthLeft", false);

        }

        //======================================================================
        if (cardLib.cardList[id].cardScript.Status.move > 0)
        {
            animator.SetBool("standRight", true);
            if (transform.position.x < StartPosition.x + cardLib.cardList[id].cardScript.Status.move * movepos)
            {
                if (charge == true)
                {
                    animator.SetBool("rush", true);
                    p_audioSource.PlayOneShot(s_attack);
                }
                if (jump == false && reversalFlag == false && charge == false)
                {
                    animator.SetBool("walk", true);
                    p_audioSource.PlayOneShot(s_move);
                    animator.SetBool("standRight", false);
                }
                if (jump == false && reversalFlag == true)
                {
                    animator.SetBool("standRight", false);
                    animator.SetBool("walkLeft", true);
                    p_audioSource.PlayOneShot(s_move);
                }
                //���]�����Ƃ�
                if (reversalFlag == true && doubleFlag == false)
                {

                    rb.velocity = new Vector2(baseSpeed * moveRot, rb.velocity.y);
                    if ((transform.position.x <= StartPosition.x + moveRot * movepos && landing == true))
                    {
                        //rb.velocity = new Vector2(0, 0);
                        reversalFlag = false;
                        animator.SetBool("standRight", true);
                        
                        animator.SetBool("walkLeft", false);
                        finAction = true;
                    }

                }

                else
                {
                    //�ʏ� 
                    rb.velocity = new Vector2(baseSpeed * cardLib.cardList[id].cardScript.Status.move, rb.velocity.y);
                }

            }
            else if (transform.position.x >= StartPosition.x + cardLib.cardList[id].cardScript.Status.move * movepos && landing == true)
            {
                if (true/*rb.velocity.x == 0.0f && rb.velocity.y == 0.0f && landing == true*/)
                {
                    reversalFlag = false;
                    doubleFlag = false;
                    charge = false;
                    movepos = 20;
                    animator.SetBool("walk", false);
                    animator.SetBool("standRight", true);
                    animator.SetBool("rush", false);
                    finAction = true;
                }
            }
        }
        //========================��
        //���Ɉړ�
        if (cardLib.cardList[id].cardScript.Status.move < 0)
        {
            // Charge = true;
            if (reversalFlag == true)
            {
                animator.SetBool("standRight", true);
            }
            if (transform.position.x > StartPosition.x + cardLib.cardList[id].cardScript.Status.move * movepos)
            {
                if (jump == false && reversalFlag == false)
                {
                    animator.SetBool("walkLeft", true);
                    p_audioSource.PlayOneShot(s_move);
                }
                if (jump == false && reversalFlag == true)
                {
                    animator.SetBool("walk", true);
                    p_audioSource.PlayOneShot(s_move);
                    animator.SetBool("standRight", false);
                }
                //���]�����Ƃ�
                if (reversalFlag == true)
                {

                    rb.velocity = new Vector2(baseSpeed * moveRot, rb.velocity.y);
                    if (transform.position.x >= StartPosition.x + moveRot * movepos && landing == true)
                    {
                        finAction = true;
                        reversalFlag = false;
                        animator.SetBool("walk", false);
                        animator.SetBool("standRight", true);

                    }

                }
                else
                {
                    rb.velocity = new Vector2(baseSpeed * cardLib.cardList[id].cardScript.Status.move, rb.velocity.y);
                }
            }
            else if (transform.position.x <= StartPosition.x + cardLib.cardList[id].cardScript.Status.move * movepos && landing == true)
            {

                //rb.velocity = new Vector2(0, 0);
                reversalFlag = false;
                doubleFlag = false;
                charge = false;
                movepos = 20;
                animator.SetBool("standRight", false);
                animator.SetBool("walkLeft", false);
                animator.SetBool("rush", false);
                finAction = true;
            }
        }

        //1�W�����v����
        if (jump == false && cardLib.cardList[id].cardScript.Status.jump == 1)
        {

            if (cardLib.cardList[id].cardScript.Status.move > 0)
            {

                if (reversalFlag == true)
                {
                    animator.SetBool("jumpLeft", true);
                    p_audioSource.PlayOneShot(s_jump);
                    animator.SetBool("walkLeft", false);
                }
                else
                {
                    animator.SetBool("jump", true);
                    p_audioSource.PlayOneShot(s_jump);

                    animator.SetBool("walk", false);
                }

            }
            else
            {

                if (reversalFlag == true)
                {
                    animator.SetBool("jump", true);
                    p_audioSource.PlayOneShot(s_jump);
                    animator.SetBool("walk", false);
                }
                else
                {
                    animator.SetBool("jumpLeft", true);
                    p_audioSource.PlayOneShot(s_jump);
                    animator.SetBool("walkLeft", false);
                }

            }
            rb.AddForce(transform.up * baseJump * cardLib.cardList[id].cardScript.Status.jump * jumppos, ForceMode2D.Impulse);
            jump = true;

        }
        //2�W�����v����
        else if (jump == false && cardLib.cardList[id].cardScript.Status.jump == 2)
        {
            if (cardLib.cardList[id].cardScript.Status.move > 0)
            {

                if (reversalFlag == true)
                {
                    animator.SetBool("jumpLeft", true);
                    p_audioSource.PlayOneShot(s_jump);
                    animator.SetBool("walkLeft", false);
                }
                else
                {
                    animator.SetBool("jumpVer", true);
                    p_audioSource.PlayOneShot(s_jump2);
                    animator.SetBool("walk", false);
                }

            }
            else
            {

                if (reversalFlag == true)
                {
                    animator.SetBool("jump", true);
                    p_audioSource.PlayOneShot(s_jump);
                    animator.SetBool("walk", false);
                }
                else
                {
                    animator.SetBool("jumpLeftVer", true);
                    p_audioSource.PlayOneShot(s_jump2);
                    animator.SetBool("walkLeft", false);
                }
            }

            rb.AddForce(transform.up * baseJump * cardLib.cardList[id].cardScript.Status.jump * jumppos2, ForceMode2D.Impulse);
            jump = true;
        }

        if (timer > 4.0f && landing == true)
        {
            //��
            if (cardLib.cardList[id].cardScript.Status.move < 0)
            {
                if (reversalFlag == false)
                {
                    GameObject.Find("Player").transform.Translate(new Vector3(8, 0, 0));
                    animator.SetBool("walkLeft", false);
                    animator.SetBool("jumpLeftVer", false);
                    animator.SetBool("jumpLeft", false);
                }
                else
                {
                    GameObject.Find("Player").transform.Translate(new Vector3(-8, 0, 0));
                    Debug.Log("move2");
                    animator.SetBool("standRight", true);
                    animator.SetBool("walk", false);
                    animator.SetBool("jumpVer", false);
                    animator.SetBool("jump", false);

                }

            }//�E
            if (cardLib.cardList[id].cardScript.Status.move > 0)
            {
                if (reversalFlag == false)
                {
                    this.transform.Translate(new Vector3(-8, 0, 0));
                    //GameObject.Find("Player").transform.Translate(new Vector3(-8, 0, 0));
                    Debug.Log("move3");
                    animator.SetBool("standRight", true);
                    animator.SetBool("walk", false);
                    animator.SetBool("jumpVer", false);
                    animator.SetBool("jump", false);
                }
                else
                {
                    this.transform.Translate(new Vector3(8, 0, 0));
                    //GameObject.Find("Player").transform.Translate(new Vector3(8, 0, 0));
                    Debug.Log("move4");
                    animator.SetBool("walkLeft", false);
                    animator.SetBool("jumpLeftVer", false);
                    animator.SetBool("jumpLeft", false);
                }

            }
            //Debug.Log(cardLib.cardList[id].cardScript.Status.move.ToString());
            reversalFlag = false;
            doubleFlag = false;
            charge = false;
            finAction = true;
            animator.SetBool("rush", false);
        }


    }

    private string DelayCoroutine()
    {
        throw new NotImplementedException();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Goal")
        {
            goalFlag = true;
            p_audioSource.PlayOneShot(s_goal);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Goal")
        {
            goalFlag = false;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //�~���x�ǉ�
        if (collision.gameObject.name == "BlockMoveX")
        {
            transform.SetParent(collision.gameObject.transform);
            parent = true;
            Debug.Log(collision.gameObject.transform);
        }

        if (collision.gameObject.name == "BlockMoveY")
        {
            transform.SetParent(collision.gameObject.transform);
            parent = true;
        }

       
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
        landing = true;
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        landing = false;
        //�~���x�ǉ�
        if (collision.gameObject.name == "BlockMoveX")
        {
            transform.SetParent(null);
            Debug.Log(collision.gameObject.transform);
            parent = false;
        }
        if (collision.gameObject.name == "BlockMoveY")
        {
            transform.SetParent(null);
            parent = false;
        }
        ////�v���C���[���u���Ă����ꂽ�Ƃ��␳����
        //if (landing == false && dir == -1)
        //{
        //    transform.Translate(new Vector3(7.8f, 0, 0));
        //}
        //if (landing == true && dir == 1)
        //{
        //    transform.Translate(new Vector3(-7.8f, 0, 0));
        //}
    }
    //�X�^�[�g�n�_�ɖ߂�J�[�h
    private void ReStart()
    {
        Debug.Log("restart");
        this.transform.position = GameObject.Find("Start").transform.position;
        animator.SetBool("limitJumpLeft", false);
        p_audioSource.PlayOneShot(s_warp);
        p_audioSource.PlayOneShot(s_jump2);
    }
    ///y���W����ړ�
    private void YWarp()
    {
        Debug.Log("limit");
        this.transform.position = new Vector2(this.transform.position.x, 120);
        YFlag = true;
        animator.SetBool("limitJumpLeft", false);
        if (YFlag == true)
        {
            animator.SetBool("limitJumpFallLeft", true);
            p_audioSource.PlayOneShot(s_jump2);

        }
    }
    ///�z�o�[�ړ�
    private void Hover()
    {
        Debug.Log("hoberOn");
        if (transform.position.y < StartPosition.y + 10 || timer > 5)
        {
            rb.AddForce(transform.up * 2, ForceMode2D.Impulse);
            animator.SetTrigger("hober");
            animator.SetTrigger("hoberNow");
        }
        else
        {
            rb.constraints = RigidbodyConstraints2D.FreezePositionY;
            animator.SetTrigger("hoberNow");
            animator.SetTrigger("hoberFall");
            finAction = true;
        }
    }
    private void BeamAttack()
    {
        //Debug.Log("beamOn");

        if (reversalFlag == true)//��
        {
            Debug.Log("beamRightOn");

            Instantiate(beamPrehab, new Vector3(transform.position.x - 3, transform.position.y, transform.position.z), Quaternion.Euler(0, 0, 0));
            //beam = false;

            //�r�[���œG��|������
            animator.SetBool("beamLeft", true);
            if (transform.position.x > enemy.transform.position.x + 80)
            {
                enemy.GetComponent<GimmickScript>().Damage();
            }
            if (transform.position.x > enemy2.transform.position.x + 80)
            {
                enemy2.GetComponent<GimmickScript>().Damage();

            }
            if (transform.position.x > enemy3.transform.position.x + 80)
            {
                if (g_enemy3.enemy3DffenceFlag == false)
                {
                    enemy3.GetComponent<GimmickScript>().Damage();

                }
            }
        }

        else//�E
        {
            Debug.Log("beamRightOn");
            animator.SetBool("standright", true);
            animator.SetBool("beam", true);


            Instantiate(beamPrehab, new Vector3(transform.position.x + 50, transform.position.y, transform.position.z), Quaternion.Euler(0, 0, 0));

            //beam = false;


            //�r�[���œG��|������
            if (transform.position.x + 80 > enemy.transform.position.x)
            {
                enemy.GetComponent<GimmickScript>().Damage();
            }
            if (transform.position.x + 80 > enemy2.transform.position.x)
            {
                enemy2.GetComponent<GimmickScript>().Damage();
            }
            if (transform.position.x + 80 > enemy3.transform.position.x)
            {
                if (g_enemy3.enemy3DffenceFlag == false)
                {
                    enemy3.GetComponent<GimmickScript>().Damage();
                }
            }
        }
        animator.SetBool("Standright", false);
        animator.SetBool("beamLeft", false);
        animator.SetBool("beam", false);

        finAction = true;
    }

  
}