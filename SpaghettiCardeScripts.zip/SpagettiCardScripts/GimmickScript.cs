using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GimmickScript : MonoBehaviour
{
    private MainGameScript main;
    private Collider2D myCollider;
    private PlayerScript player;
    public Rigidbody2D rbEnemy2;
    private float baseSpeed = 60.0f;
    private int enemy2Move = 60;
    public bool enemy2AttackLeft;
    public bool enemy2AttackRight;
    public bool enemy3DffenceFlag;

    public class BlockMoveStatus
    {
        public int Move;
        public int Direction;
    }
    public enum TAG
    {
        Block,
        Enemy,
        Event
    }
    //�ǉ�
    public enum EnemyType
    {
        NONE,
        Enemy1,
        Enemy2,
        Enemy3
    }

    public int hp;
    public Vector2 StartPosition;
    public Vector2 enemySetPosition;
    public bool setStart = false;
    public bool finAction = false;
    private float enemy1Range = 16.0f;
    private float enemy2Range = 56.0f;
    private SpriteRenderer _Renderer;
    public bool trueAct = false;

    private float blockSpeed = 20.0f;
    public Rigidbody2D rb;
    public Rigidbody2D rbPlyaer;

    public CardDataBase cardLib;

    public GameObject WarpPoint;

    private Animator animatorPl;
    private Animator animatorEn1;
    private Animator animatorEn2;
    private Animator animatorEn3;
    private Animator animatorBl;
    public GameObject Player;

    //�u���b�N�֘A
    public int dir;//�u���b�N�̕��������߂�@1���]1�����
    public int setAmount;
    public int nowPos;
    public int nowPosCopy;
    public int moveAmount = 0;
    public Vector3 blockPos;
    public bool ChFlag;

    public AudioClip s_Rattack;
    public AudioClip s_Rdelete;
    public AudioClip s_Rstannow;
    public AudioClip s_Rstanstrat;
    public AudioClip s_Gattck;
    public AudioClip s_Gdelete;
    public AudioClip s_Gstannow;
    public AudioClip s_Gstanstrat;
    public AudioClip s_YOpen;
    public AudioClip s_YClose;
    public AudioClip s_Ydelete;
    public AudioClip s_Ystannow;
    public AudioClip s_Ystanstrat;
    public AudioClip s_Bwarp;
    public AudioClip s_Bmove;
    public AudioClip s_delete;
    public AudioClip s_hit;
   

    AudioSource g_audioSource;



    [SerializeField]
    public TAG myTag;
    public EnemyType myEnemyType;//�ǉ�
    float timer;


    void Start()
    {
        ChFlag = false;
        nowPosCopy = nowPos;
        animatorPl = Player.GetComponent<Animator>();
        main = GameObject.Find("GameManager").GetComponent<MainGameScript>();
        g_audioSource = GetComponent<AudioSource>();
        myCollider = GetComponent<Collider2D>();
        player = GameObject.Find("Player").GetComponent<PlayerScript>();
        rbPlyaer = player.rb;
        rbEnemy2 = GetComponent<Rigidbody2D>();
        enemySetPosition = transform.position;
        animatorEn1 = GetComponent<Animator>();
        animatorEn2 = GetComponent<Animator>();
        animatorEn3 = GetComponent<Animator>();
        animatorBl = GetComponent<Animator>();
        blockPos = transform.position;
        enemy2AttackLeft = false;
        enemy2AttackRight = false;
        enemy3DffenceFlag = false;
    }

    public void SetStart(bool setStartBool)
    {
       if (main.act == 0)
       {
           Debug.Log("���Z�b�g�����܂��I");
           transform.position = blockPos;
           moveAmount = 0;
            nowPos = nowPosCopy;

            if (dir == 1 && ChFlag == true)
            {
                dir = -1;
            }
            if (dir == -1 && ChFlag == true)
            {
                dir = 1;
            }

        }
        StartPosition = transform.position;
        setStart = setStartBool;
        timer = 0.0f;
    }

    public void MoveGimmick()
    {


        if (myTag == TAG.Enemy)
        {
            if (myEnemyType == EnemyType.Enemy1)
            {
                animatorEn1.SetBool("E1Stun", false);
                animatorEn1.SetBool("E1Death", false);
                animatorEn1.SetBool("E1Atack", false);
                animatorEn1.SetBool("E1StunFin", false);
            }
            if (myEnemyType == EnemyType.Enemy2)
            {
                animatorEn2.SetBool("E2Stun", false);
                animatorEn2.SetBool("E2WaitL", false);
                animatorEn2.SetBool("E2Death", false);
                animatorEn2.SetBool("E2StunFin", false);
            }
            if (myEnemyType == EnemyType.Enemy3)
            {
                animatorEn3.SetBool("E3Stun", false);
                animatorEn3.SetBool("E3Death", false);
                animatorEn3.SetBool("E3Open", false);
                animatorEn3.SetBool("E3Close", false);
                animatorEn3.SetBool("E3StunFinC", false);
                animatorEn3.SetBool("E3StunFinO", false);
            }

            if (hp > 0)
            {
                if (myEnemyType == EnemyType.Enemy1 && player.StanFlag == false)
                {
                    if (player.StanFlag == true)
                    {
                        animatorEn1.SetBool("E1StunFin", true);
                        animatorEn1.SetBool("E1Stun", false);

                    }
                    if (finAction == false)
                    {
                        timer += Time.deltaTime;
                        if (timer > 1.0f)
                        {
                            Enemy1();
                        }

                    }
                }
                if (myEnemyType == EnemyType.Enemy2 && player.StanFlag == false)
                {
                    if (player.StanFlag == true)
                    {
                        animatorEn1.SetBool("E2StunFin", true);
                        animatorEn1.SetBool("E2Stun", false);
                    }
                    if (finAction == false)
                    {
                        timer += Time.deltaTime;
                        if (timer > 1.0f)
                        {
                            if (enemy2AttackLeft == false && enemy2AttackRight == false)
                            {
                                Enemy2();
                            }
                            else
                            {
                                if (enemy2AttackLeft == true)
                                {
                                    rbEnemy2.velocity = new Vector2(-baseSpeed, rbEnemy2.velocity.y);
                                    animatorEn2.SetBool("E2AtackL", true);
                                    g_audioSource.PlayOneShot(s_Gattck);

                                    if (transform.position.x <= StartPosition.x + (-enemy2Move / 3))
                                    {
                                        rbEnemy2.gravityScale = 30;
                                    }
                                    if (transform.position.x >= StartPosition.x + (enemy2Move / 2))
                                    {
                                        rbEnemy2.gravityScale = 30;
                                    }
                                    if (transform.position.x <= StartPosition.x + -enemy2Move)
                                    {
                                        rbEnemy2.velocity = new Vector2(0, 0);
                                        enemy2AttackLeft = false;
                                        rbEnemy2.gravityScale = 1;

                                        main.gimmicCount += 1;
                                        finAction = true;
                                    }
                                    if (timer > 5f)
                                    {
                                        transform.Translate(new Vector3(6, 0, 0));
                                        rbEnemy2.velocity = new Vector2(0, 0);
                                        enemy2AttackLeft = false;
                                        rbEnemy2.gravityScale = 1;

                                        main.gimmicCount += 1;
                                        finAction = true;
                                    }
                                }
                                if (enemy2AttackRight == true)
                                {
                                    animatorEn2.SetBool("E2AtackR", true);
                                    g_audioSource.PlayOneShot(s_Gattck);

                                    rbEnemy2.velocity = new Vector2(baseSpeed, rbEnemy2.velocity.y);
                                    if (transform.position.x >= StartPosition.x + (enemy2Move / 3))
                                    {
                                        rbEnemy2.gravityScale = 30;
                                    }
                                    if (transform.position.x >= StartPosition.x + (enemy2Move / 2))
                                    {
                                        rbEnemy2.gravityScale = 30;
                                    }
                                    if (transform.position.x >= StartPosition.x + enemy2Move)
                                    {
                                        rbEnemy2.velocity = new Vector2(0, 0);
                                        enemy2AttackRight = false;
                                        rbEnemy2.gravityScale = 1;
                                        Debug.Log("true2");
                                        main.gimmicCount += 1;
                                        Debug.Log(main.gimmicCount);
                                        finAction = true;
                                    }
                                    if (timer > 5f)
                                    {
                                        transform.Translate(new Vector3(-6, 0, 0));
                                        rbEnemy2.velocity = new Vector2(0, 0);
                                        enemy2AttackLeft = false;
                                        rbEnemy2.gravityScale = 1;

                                        main.gimmicCount += 1;
                                        finAction = true;
                                    }
                                }
                            }
                        }
                    }
                }

                if (myEnemyType == EnemyType.Enemy3 && player.StanFlag == false)
                {
                    if (player.StanFlag == true)
                    {
                        if (enemy3DffenceFlag == false)
                        {
                            animatorEn3.SetBool("E3StunFinO", true);
                            g_audioSource.PlayOneShot(s_YOpen);

                            animatorEn3.SetBool("E3Stun", false);

                        }
                        else
                        {
                            animatorEn3.SetBool("E3StunFinC", true);
                            g_audioSource.PlayOneShot(s_YClose);
                            animatorEn3.SetBool("E3Stun", false);
                        }
                    }
                    if (finAction == false)
                    {
                        timer += Time.deltaTime;
                        if (timer > 1.0f)
                        {
                            Enemy3();
                        }
                    }
                }
                if (player.StanFlag == true)
                {
                    animatorEn1.SetBool("E1Stun", true);
                    g_audioSource.PlayOneShot(s_Rstanstrat);

                    animatorEn1.SetBool("E2Stun", true);
                    g_audioSource.PlayOneShot(s_Gstanstrat);

                    animatorEn1.SetBool("E3Stun", true);
                    g_audioSource.PlayOneShot(s_Ystanstrat);


                    if (finAction == false)
                    {
                        timer += Time.deltaTime;
                        Debug.Log("Stan�g����");
                        main.gimmicCount = main.gimmick.Count;
                        finAction = true;
                        player.StanFlag = false;
                    }
                }
                if (player.CamouflageFlag == true)
                {
                    if (finAction == false)
                    {
                        timer += Time.deltaTime;
                        Debug.Log("�����g����");
                        main.gimmicCount = main.gimmick.Count;
                        finAction = true;
                        player.CamouflageFlag = false;
                    }
                }
            }

            else
            {
                Debug.Log("true111");
                main.gimmicCount += 1;
                finAction = true;
                gameObject.SetActive(false);
            }
        }

        if (myTag == TAG.Block)
        {
            animatorBl = GetComponent<Animator>();

            if (finAction == false)
            {
                if (gameObject.name == "BlockMoveX")
                {
                    animatorBl.SetBool("MoveXLeft", false);
                    timer += Time.deltaTime;
                   

                    if (player.finAction == false)
                    {
                        Debug.Log("freezeX");
                        rb.constraints = RigidbodyConstraints2D.FreezePositionX;
                    }
                    if (setAmount == nowPos + moveAmount)
                    {
                        dir *= -1;
                        moveAmount = 0;
                        nowPos = 0;
                        ChFlag = true;
                    }
                    if (player.finAction == true)
                    {
                        transform.Translate(0.5f * dir, 0f, 0f);
                        if (dir == 1)//�A�j���[�V�����@�{���ǉ�
                        {
                            animatorBl.SetBool("MoveXLeft", true);
                            g_audioSource.PlayOneShot(s_Bmove);

                        }
                        else if (dir == -1)
                        {
                            animatorBl.SetBool("MoveXRight", true);
                            g_audioSource.PlayOneShot(s_Bmove);
                        }


                        if (timer > 3.0f || transform.position.x <= StartPosition.x - 20 || transform.position.x >= StartPosition.x + 20)
                        {
                            Debug.Log("�Ƃ܂�");
                            //rb.velocity = Vector2.zero;
                            main.gimmicCount += 1;
                            moveAmount += 1;
                            finAction = true;
                            animatorBl.SetBool("MoveXLeft", false);
                            animatorBl.SetBool("MoveXRight", false);
                        }
                    }
                }

                if (gameObject.name == "BlockMoveY")
                {
                    animatorBl.SetBool("MoveYUp", false);
                    timer += Time.deltaTime;

                    if (dir == 1)//�A�j���[�V���� �{���ǉ�
                    {
                        animatorBl.SetBool("MoveYUp", true);
                    }
                    else if (dir == -1)
                    {
                        animatorBl.SetBool("MoveYDown", true);
                    }

                    transform.Translate(0f, 0.5f * dir, 0f);
                  
                    
                    //����
                    if(transform.position == player.transform.position)
                    {
                        ResetPlayer();
                    }
                   
                    if (setAmount == nowPos + moveAmount)
                    {
                        dir *= -1;
                        moveAmount = 0;
                        nowPos = 0;
                        ChFlag = true;
                    }

                    if (timer > 3.0f || transform.position.y > StartPosition.y + 10f || transform.position.y < StartPosition.y - 10f)//
                    {

                        Debug.Log(StartPosition);
                        animatorBl.SetBool("MoveYUp", false);
                        animatorBl.SetBool("MoveYDown", false);
                        main.gimmicCount += 1;
                        moveAmount += 1;
                        finAction = true;
                    }
                }


                if (gameObject.name == "WarpA")
                {
                    if (trueAct == true)//�u���b�N���v���C���[�Ɠ���������
                    {
                        WarpPoint.GetComponent<GimmickScript>().finAction = true;
                        g_audioSource.PlayOneShot(s_Bwarp);

                        GameObject.Find("Player").transform.position = WarpPoint.transform.position;
                        main.gimmicCount += 1;
                        finAction = true;
                    }
                    else
                    {
                        if (WarpPoint.GetComponent<GimmickScript>().trueAct == false)
                        {
                            Debug.Log("aElse");
                            main.gimmicCount += 1;
                            finAction = true;
                        }
                    }
                }

                if (gameObject.name == "WarpB")
                {
                    if (trueAct == true)//�u���b�N���v���C���[�Ɠ���������
                    {
                        WarpPoint.GetComponent<GimmickScript>().finAction = true;
                        g_audioSource.PlayOneShot(s_Bwarp);
                        GameObject.Find("Player").transform.position = WarpPoint.transform.position;
                        Debug.Log("b");
                        main.gimmicCount += 1;

                        finAction = true;
                    }
                    else
                    {
                        if (WarpPoint.GetComponent<GimmickScript>().trueAct == false)
                        {
                            Debug.Log("belse");
                            main.gimmicCount += 1;
                            Debug.Log(main.gimmicCount);
                            finAction = true;
                        }
                    }
                }
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
       
            if (collision.name == "Player")
            {
                trueAct = true;
                if (myTag == TAG.Enemy)
                {
                    if (myEnemyType == EnemyType.Enemy3 && player.charge == true)
                    {
                        player.timer += 4;
                        if (transform.position.x > collision.transform.position.x)
                        {
                            player.transform.Translate(new Vector3(-8, 0, 0));

                        }
                        if (transform.position.x < collision.transform.position.x)
                        {
                            player.transform.Translate(new Vector3(8, 0, 0));
                        }
                    }
                    else
                    {
                        if (player.charge == true)
                        {
                            trueAct = true;
                            Damage();
                            gameObject.SetActive(false);
                        }
                        else
                        {
                            trueAct = true;
                            StartCoroutine("PlayerDeath");
                            ResetPlayer();
                            StartCoroutine("Coroutine");
                        }
                    }
                }
            }
        }
    

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.name == "Player")
        {
            trueAct = false;
        }
    }

    public void Damage()
    {
        if (myTag == TAG.Enemy)
        {
            hp -= 1;
            g_audioSource.PlayOneShot(s_hit);
            if (myTag == TAG.Enemy && myEnemyType == EnemyType.Enemy1 && hp == 0)
                animatorEn1.SetBool("E1Death", true);
            g_audioSource.PlayOneShot(s_Rdelete);

            if (myTag == TAG.Enemy && myEnemyType == EnemyType.Enemy2 && hp == 0)
                animatorEn1.SetBool("E2Death", true);
            g_audioSource.PlayOneShot(s_Gdelete);

            if (myTag == TAG.Enemy && myEnemyType == EnemyType.Enemy3 && hp == 0)
                animatorEn1.SetBool("E3Death", true);
            g_audioSource.PlayOneShot(s_Ydelete);

        }
    }
    public void Enemy1()
    {
        if (player.CamouflageFlag == true)
        {
            if (finAction == false)
            {
                timer += Time.deltaTime;
                Debug.Log("�����g����");
                main.gimmicCount = main.gimmick.Count;
                finAction = true;
                player.CamouflageFlag = false;
            }
        }
        else
        {
            RaycastHit2D raycastHitLeft = Physics2D.Raycast(transform.position + new Vector3(-4.1f, 0.0f, 0.0f), Vector2.left, enemy1Range);
            RaycastHit2D raycastHitRight = Physics2D.Raycast(transform.position + new Vector3(4.1f, 0.0f, 0.0f), Vector2.right, enemy1Range);

            if (raycastHitLeft)
            {
                if (raycastHitLeft.collider.gameObject.name == "Player")
                {
                    animatorEn1.SetBool("E1Atack", true);
            g_audioSource.PlayOneShot(s_Rattack);


                    if (player.reversalFlag == true)
                        StartCoroutine("PlayerDeathLeft");

                    else
                        StartCoroutine("PlayerDeath");

                    ResetPlayer();
                    StartCoroutine("Coroutine");
                }
            }
            if (raycastHitRight)
            {
                if (raycastHitRight.collider.gameObject.name == "Player")
                {
                    animatorEn1.SetBool("E1Atack", true);
                    g_audioSource.PlayOneShot(s_Rattack);


                    if (player.reversalFlag == true)
                        StartCoroutine("PlayerDeathLeft");

                    else
                        StartCoroutine("PlayerDeath");

                    ResetPlayer();
                    StartCoroutine("Coroutine");
                }
            }

            main.gimmicCount += 1;
            finAction = true;
        }
    }
    public void Enemy2()
    {
        if (player.CamouflageFlag == true)
        {
            if (finAction == false)
            {
                timer += Time.deltaTime;
                Debug.Log("�����g����");
                main.gimmicCount = main.gimmick.Count;
                finAction = true;
                player.CamouflageFlag = false;
            }
        }
        else
        {
            RaycastHit2D raycastHitLeft = Physics2D.Raycast(transform.position + new Vector3(-4.1f, 0.0f, 0.0f), Vector2.left, enemy2Range);
            RaycastHit2D raycastHitRight = Physics2D.Raycast(transform.position + new Vector3(4.1f, 0.0f, 0.0f), Vector2.right, enemy2Range);
            if (raycastHitLeft)
            {
                if (raycastHitLeft.collider.gameObject.name == "Player")
                {
                    enemy2AttackLeft = true;
                    animatorEn2.SetBool("E2AtWaitL", true);
                }
            }
            if (raycastHitRight)
            {
                if (raycastHitRight.collider.gameObject.name == "Player")
                {
                    enemy2AttackRight = true;
                    animatorEn2.SetBool("E2AtWaitR", true);
                }
            }
            main.gimmicCount += 1;
            Debug.Log("enemy2");
            finAction = true;
        }
    }


    public void Enemy3()
    {
        if (enemy3DffenceFlag == false)
        {
            enemy3DffenceFlag = true;
            StartCoroutine("E3Open");
            main.gimmicCount += 1;
            finAction = true;
        }
        else
        {
            enemy3DffenceFlag = false;
            StartCoroutine("E3Close");
            main.gimmicCount += 1;
            finAction = true;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (myEnemyType == EnemyType.Enemy2)
        {
            if (collision.gameObject.name == "Player")
            {
                if (player.charge == true)
                {
                    trueAct = true;
                    Damage();
                    gameObject.SetActive(false);
                }
                else
                {
                    trueAct = true;
                    if (player.reversalFlag == true)
                        StartCoroutine("PlayerDeathLeft");

                    else
                        StartCoroutine("PlayerDeath");

                    ResetPlayer();
                    StartCoroutine("Coroutine");
                }
            }
            else if (collision.gameObject.name == "Enemy2")
            {
                rbEnemy2.velocity= Vector2.zero;
               
            }
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Player")
        {
            trueAct = false;
        }
    }
    public void ResetPlayer()
    {

        player.setStart = false;
        enemy2AttackLeft = false;
        enemy2AttackRight = false;
        enemy3DffenceFlag = false;
        main.act = 0;
        main.playCode = false;
        player.jump = false;
        player.YFlag = false;
        player.hoverFlag = false;
        player.timer = 0;
        player.rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        main.gimmicCount = 0;
        main.gimmick.Clear();
    }
    IEnumerator Coroutine()
    {
        yield return new WaitForSeconds(3f);
        player.transform.position = GameObject.Find("Start").transform.position;
        player.gameObject.SetActive(true);
        this.transform.position = enemySetPosition;
        main.phase = MainGameScript.Phase.End;
    }

    IEnumerator PlayerDeath()
    {
        yield return new WaitForSeconds(0.3f);
        animatorPl.SetBool("death", true);
        g_audioSource.PlayOneShot(s_delete);
        yield return new WaitForSeconds(0.79f);
        player.gameObject.SetActive(false);
        if (myEnemyType == EnemyType.Enemy1)
        {
            animatorEn1.SetBool("E1Atack", false);
        }
    }

    IEnumerator PlayerDeathLeft()
    {
        yield return new WaitForSeconds(0.3f);
        animatorPl.SetBool("deathLeft", true);
        g_audioSource.PlayOneShot(s_delete);
        yield return new WaitForSeconds(0.79f);
        player.gameObject.SetActive(false);
        if(myEnemyType==EnemyType.Enemy1)
        {
            animatorEn1.SetBool("E1Atack", false);
        }
    }

    IEnumerator E3Open()
    {
        animatorEn3.SetBool("E3Open", true);
        g_audioSource.PlayOneShot(s_YOpen);

        yield return new WaitForSeconds(1.0f);

    }

    IEnumerator E3Close()
    {
        animatorEn3.SetBool("E3Close", true);
        g_audioSource.PlayOneShot(s_YClose);
        yield return new WaitForSeconds(1.0f);

    }
    
}
