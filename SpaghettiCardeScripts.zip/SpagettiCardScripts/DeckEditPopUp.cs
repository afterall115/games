using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeckEditPopUp : MonoBehaviour
{
    public CardDataBase cardLib;
    private GameObject de;
    private GameData gameData;
    // private GameData main;
    private DeckEdit deckEdit;
    public GameObject popYes18;
    public GameManager gameManager;
    //�f�b�L�Ґ��̊m��
    public void Confirm()
    {
        gameData = GameObject.Find("GameData").GetComponent<GameData>();
        deckEdit = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();
        if (deckEdit.deckEditDeck.Count >= 18)
        {

            gameData.myDecks[deckEdit.deckIndex].myDeck.Clear();
            gameData.myDecks[deckEdit.deckIndex].myDeck.AddRange(deckEdit.deckEditDeck);

            for (int i = 0; i < deckEdit.deckEditDeck.Count; i++)
            {
                cardLib.cardList[deckEdit.deckEditDeck[i]].hasCard++;
            }
            deckEdit.deckEditCard.Clear();
            deckEdit.deckEditDeck.Clear();
            deckEdit.deckEdit.SetActive(false);
            gameManager.LoadScene("Menu");
        }
        else
        {
            popYes18.SetActive(true);
        }
    }
}
