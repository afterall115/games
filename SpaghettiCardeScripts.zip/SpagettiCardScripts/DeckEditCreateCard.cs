using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class DeckEditCreateCard : MonoBehaviour
{

    public GameObject cardImage;
    public Transform editParent;
    public Transform deckParent;
    public CardDataBase cardLib;
    private CardScript cardScript;
    private GameObject clone;
    private DeckEdit deckEdit;
    private cloneId cloneIdComponent;
    private Image cloneImageComponent;
    private int cardId;
    public string[] editCardText;�@//529
    public FocusDeckEdit fDE;

    void Start()
    {
        deckEdit = GameObject.Find("DeckEditManager").GetComponent<DeckEdit>();
        fDE = GameObject.Find("FocusDeckEdit").GetComponent<FocusDeckEdit>();


        for (int i = 0; i < cardLib.cardList.Count; i++)
        {
            //�N���[���̐���
            Sprite cardSprite = cardLib.cardList[i].cardSprite;

            clone = Instantiate(cardImage, editParent);
            cloneIdComponent = clone.GetComponent<cloneId>();
            cloneImageComponent = clone.GetComponent<Image>();
            cloneIdComponent.cardId = i;
            cloneIdComponent.deckParent = deckParent;
            cloneIdComponent.editParent = editParent;
            cloneImageComponent.sprite = cardSprite;
            clone.name = cardLib.cardList[i].cardScript.name;
            cloneIdComponent.cardText = editCardText[i];
            //�t�H�[�J�X�p�̃��X�g�ɒǉ�
            fDE.editList.Add(clone);

            //�f�b�L�ɓ����Ă��Ȃ������瓧���ɂ���
            if (cardLib.cardList[i].bought==false)
            {
                cloneImageComponent.color = new Color(0.7f, 0.7f, 0.7f, 0.7f);
            }
            //�f�b�L�ɓ����Ă����炵������\������
            else
            {
                cloneImageComponent.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }

        
    }
}


