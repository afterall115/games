using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deckPop18 : MonoBehaviour
{
    public float timer;
    public GameObject thisObj;
    void Update()
    {
        timer += Time.deltaTime;

        if (timer > 1.5f)
        {
            thisObj.SetActive(false);
            timer = 0;
        }
    }
}