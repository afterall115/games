using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shop : MonoBehaviour
{
    public GameObject cardImage;
    public CardDataBase cardLib;
    public Transform shopParent;
    public ShopManager shopManager;
    private ShopCard cloneIdComponent;
    private GameObject clone;
    private Image cloneImageComponent;
    private Text myPricePrint;
    private Text myCardText;
    private GameObject cloneChild;
    private GameObject pop;
    [SerializeField]
    private int[] ShopCardList = { };
    private int cardNum = 0;
    public string[] shopCardText;�@//529


    public List<GameObject> shopObjectList = new List<GameObject>();
    private void Start()
    {
       
        for (; cardNum < ShopCardList.Length; cardNum++)
        {
            if (cardLib.cardList[ShopCardList[cardNum]].bought == false)
            {
               
                //�N���[���̐���
                Sprite cardSprite = cardLib.cardList[ShopCardList[cardNum]].cardSprite;
                clone = Instantiate(cardImage,shopParent);
                cloneChild = clone.transform.GetChild(0).gameObject;
                clone.name = "ShopBox" + cardNum;
                cloneIdComponent = cloneChild.GetComponent<ShopCard>();
                cloneImageComponent = cloneChild.GetComponent<Image>();
                cloneIdComponent.cardId = ShopCardList[cardNum];
                cloneIdComponent.myPrice = cardLib.cardList[ShopCardList[cardNum]].price;
                cloneImageComponent.sprite = cardSprite;
                cloneChild.name = cardLib.cardList[ShopCardList[cardNum]].cardScript.name;
                cloneImageComponent.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
                cloneIdComponent.pop = GameObject.Find("Canvas").transform.Find("ShopPop").gameObject;
                //�l�i�̕\��
                myPricePrint = cloneChild.GetComponentInChildren<Text>();
                myPricePrint.text = cloneIdComponent.myPrice.ToString();

                shopObjectList.Add(clone);

                cloneIdComponent.cardText = shopCardText[cardNum];
                shopManager.shopObject.Add(cloneChild);
                cloneIdComponent.select = cardNum;
                //Debug.Log(cardNum);
            }
            else
            {
              
                //�N���[���̐���
                Sprite cardSprite = cardLib.cardList[ShopCardList[cardNum]].cardSprite;

                clone = Instantiate(cardImage,shopParent);
                cloneChild = clone.transform.GetChild(0).gameObject;
                clone.name = "ShopBox" + cardNum;

                cloneIdComponent = cloneChild.GetComponent<ShopCard>();
                cloneImageComponent = cloneChild.GetComponent<Image>();
                cloneIdComponent.cardId = ShopCardList[cardNum];
                cloneIdComponent.myPrice = cardLib.cardList[ShopCardList[cardNum]].price;
                cloneImageComponent.sprite = cardSprite;
                cloneChild.name = cardLib.cardList[ShopCardList[cardNum]].cardScript.name;
                cloneImageComponent.color = new Color(0.7f, 0.7f, 0.7f, 0.7f);
                //�l�i�̕\��
                myPricePrint = cloneChild.GetComponentInChildren<Text>();
                myPricePrint.text = cloneIdComponent.myPrice.ToString();
             
                cloneIdComponent.cardText = shopCardText[cardNum];
                shopManager.shopObject.Add(cloneChild);
                cloneIdComponent.select = cardNum;
            }

        }

    }
 
    
}


