
#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "weapon.h"
#include "map.h"
#include "bat.h"

static int g_Texturebat;

static BAT g_bat[50];
static BATANIM g_batani;

void Initbat()
{
	g_Texturebat = LoadTexture((char*)"data/TEXTURE/bat.png");

	for (int i = 0; i < 50; i++)
	{
		g_bat[i].animmode = 0;
		g_bat[i].yimpulse = 0;
		g_bat[i].windowhit = false;
	}
}


void Uninitbat()
{

}


void Updatebat()
{
	PLAYER* pPlayer = GetPlayer();

	for (int i = 0 ; i < g_bat[1].usecount; i++)
	{
		if (HitCheckBox(g_bat[i].pos, 128.0f, 128.0f, pPlayer->pos, 1500.0f, 700.0f))
		{
			if (g_bat[i].pos.y < pPlayer->pos.y)
			{
				g_bat[i].windowhit = true;
				g_bat[i].animmode = 1;
			}
		}
		if (pPlayer->hitcool <= 0 && HitCheckBox(g_bat[i].pos, 80.0f, 80.0f, pPlayer->pos, 88.0f, 170.0f))
		{
			pPlayer->hit = true;
			pPlayer->hitcool = 100;
			pPlayer->moveinpulse = -5.0f;
		}

		if (g_bat[i].windowhit == true)
		{
			if (g_bat[i].pos.y >= pPlayer->pos.y)
			{
				g_bat[i].yimpulse -= 0.1f;
			}
			else
			{
				g_bat[i].yimpulse += 0.1f;
			}
			g_bat[i].pos.y += g_bat[i].yimpulse;
			g_bat[i].pos.x -= 2.0f;
		}
	}
	
	if (g_batani.animcool >= 10)
	{
		if (g_batani.animcount > 10)
		{
			g_batani.animcount = 0;
		}
		else
		{
			g_batani.animcount++;
		}

		g_batani.animcool = 0;
	}
	g_batani.animcool++;
}


void Drawbat()
{
	D3DXVECTOR2 basePos = GetBase();

	for (int i = 0; i < g_bat[1].usecount; i++)
	{
		DrawSpriteColorRotate(g_Texturebat, basePos.x + g_bat[i].pos.x, basePos.y + g_bat[i].pos.y, 128.0f, 128.0f, 0.0f + (0.1f * g_batani.animcount), 0.0f + (0.5f * g_bat[i].animmode), 0.1f, 0.5f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), 0.0f);
	}
}

BAT* Getbat(void)
{
	return &g_bat[0];
}