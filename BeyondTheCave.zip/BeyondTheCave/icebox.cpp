
#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "weapon.h"
#include "map.h"
#include "icebox.h"


static int g_Textureicebox = 0;

static ICEBOX g_icebox[500];

void Initice(void)
{
	g_Textureicebox = LoadTexture((char*)"data/TEXTURE/icebox.png");
	for (int n = 0; n < 500; n++)
	{
		g_icebox[n].size = 64.0f;
		g_icebox[n].use = true;
	}
}

void Uninitice(void)
{

}

void Updateice(void)
{

	PLAYER*pPlayer = GetPlayer();
	WEAPON* pweapon = Getweapon();
	PLAYERBIRD* pBird = GetBird();


	for (int n = 0; n < g_icebox[1].usecount; n++)
	{
		if (g_icebox[n].use == true)
		{
			//if (HitCheckBox(pPlayer->pos, 172.0f, 30.0f, g_icebox[x].pos, 64.0f, 64.0f))
			//{

			//}
			if (HitCheckBox(pPlayer->pos, 88.0f, 170.0f, g_icebox[n].pos, 64.0f, 64.0f))
			{
				if (HitCheckField(pPlayer->pos, 88.0f, 160.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.y = g_icebox[n].pos.y - 112.0f;
					pPlayer->gravityscale = 0.0f;
					pPlayer->icework = true;
					pPlayer->jumpFlag = false;
				}
				if (HitCheckwallleft(pPlayer->pos, 88.0f, 160.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.x = g_icebox[n].pos.x + 76.0f;

				}
				if (HitCheckwallright(pPlayer->pos, 88.0f, 160.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.x = g_icebox[n].pos.x - 76.0f;

				}
				if (HitCheckCelling(pPlayer->pos, 88.0f, 160.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.y = g_icebox[n].pos.y + 120.0f;
				}
			}

			if (pBird->actstyle == true)
			{
				if (HitCheckBox(pBird->pos, 60.0f, 60.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					if (HitCheckField(pBird->pos, 52.0f, 52.0f, g_icebox[n].pos, 64.0f, 64.0f))
					{
						pBird->pos.y = g_icebox[n].pos.y - 58.0f;
					}
					if (HitCheckwallleft(pBird->pos, 52.0f, 52.0f, g_icebox[n].pos, 64.0f, 64.0f))
					{
						pBird->pos.x = g_icebox[n].pos.x + 58.0f;


					}
					if (HitCheckwallright(pBird->pos, 52.0f, 52.0f, g_icebox[n].pos, 64.0f, 64.0f))
					{
						pBird->pos.x = g_icebox[n].pos.x - 58.0f;

					}
					if (HitCheckCelling(pBird->pos, 52.0f, 52.0f, g_icebox[n].pos, 64.0f, 64.0f))
					{
						pBird->pos.y = g_icebox[n].pos.y + 58.0f;
					}
				}
			}


			if (HitCheckBox(pweapon->bulletpos, 55.0f, 55.0f, g_icebox[n].pos, 64.0f, 64.0f))
			{
				if (pweapon->firegun == true)
				{
					if (pweapon->gunhit == true)
					{
						g_icebox[n].use = false;
					}
				}
				if (HitCheckField(pweapon->bulletpos, 50.0f, 50.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pweapon->bulletpos.y = g_icebox[n].pos.y - 57.0f;
					pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
				}
				if (HitCheckwallleft(pweapon->bulletpos, 50.0f, 50.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pweapon->bulletpos.x = g_icebox[n].pos.x + 57.0f;
					pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;

				}
				if (HitCheckwallright(pweapon->bulletpos, 50.0f, 50.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pweapon->bulletpos.x = g_icebox[n].pos.x - 57.0f;
					pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;

				}
				if (HitCheckCelling(pweapon->bulletpos, 50.0f, 50.0f, g_icebox[n].pos, 64.0f, 64.0f))
				{
					pweapon->bulletpos.y = g_icebox[n].pos.y + 57.0f;
					pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
				}
			}
		}
		else
		{
			if(g_icebox[n].size >= 0.0f)
			g_icebox[n].size -= 1.0f;
		}
	}
}

void Drawice(void)
{
	D3DXVECTOR2 basePos = GetBase();

	for (int n = 0; n < g_icebox[1].usecount; n++)
	{
		if (g_icebox[n].size >= 0)
		{
			DrawSprite(g_Textureicebox, basePos.x + g_icebox[n].pos.x, basePos.y + g_icebox[n].pos.y, g_icebox[n].size, g_icebox[n].size, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
}

ICEBOX* Getice(void)
{
	return &g_icebox[0];
}