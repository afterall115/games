#include "fade.h"
#include "Texture.h"
#include "sound.h"
#include "Sprite.h"


static int g_Texturefade = 0;

static FADE g_fade[20];

static FADECENTER g_fadec;


void Initfade()
{
	g_Texturefade = LoadTexture((char*)"data/TEXTURE/fadeline.png");

	for (int i = 0; i < 20; i++)
	{
		g_fade[i].ypos = 2000.0f;
	}

	g_fadec.fadeOFF = false;
	g_fadec.fadeON = false;
}

void Uninitfade()
{

}

void Updatefade()
{

	for (int i = 0; i < 20; i++)
	{
		if (g_fadec.fadeON == true)
		{
			g_fade[i].fademove += frand() * 3.0f;
			if (g_fade[i].ypos >= 540.0f)
			{
				g_fade[i].ypos -= g_fade[i].fademove;
			}
		}

		if (g_fadec.fadeOFF == true)
		{
			g_fade[i].fademove += frand() * 3.0f;
			if (g_fade[i].ypos > -1920.0f)
			{
				g_fade[i].ypos -= g_fade[i].fademove;
			}

		}
	}
}

void Setfadeout()
{
	for (int i = 0; i < 20; i++)
	{
		g_fade[i].ypos = 2400.0f;
		g_fade[i].fademove = 0.0f;
	}

	g_fadec.fadeON = true;

}

void Setfadein()
{
	for (int i = 0; i < 20; i++)
	{
		g_fade[i].ypos = 540.0f;
		g_fade[i].fademove = 0.0f;
	}
	g_fadec.fadeOFF = true;

}

void Drawfade()
{
	for (int i = 0; i < 20; i++)
	{
			DrawSpriteColorRotate(g_Texturefade, 48.0 + (96.0f * i ),g_fade[i].ypos , 96.0f, 1800.0f, 1.0f, 1.0f, 0.0f, 0.0f,D3DXCOLOR(1.0f,1.0f,1.0f,1000.0f),0.0f);
	}
}

FADE* Getfade()
{
	return &g_fade[0];
}

FADECENTER* Getfadec()
{
	return &g_fadec;
}

bool fadeoutOK()
{
	if (g_fadec.fadeON == true)
	{
		if (g_fade[0].ypos <= 540.0f)
		{
			if (g_fade[1].ypos <= 540.0f)
			{
				if (g_fade[2].ypos <= 540.0f)
				{
					if (g_fade[3].ypos <= 540.0f)
					{
						if (g_fade[4].ypos <= 540.0f)
						{
							if (g_fade[5].ypos <= 540.0f)
							{
								if (g_fade[6].ypos <= 540.0f)
								{
									if (g_fade[7].ypos <= 540.0f)
									{
										if (g_fade[8].ypos <= 540.0f)
										{
											if (g_fade[9].ypos <= 540.0f)
											{
												if (g_fade[10].ypos <= 540.0f)
												{
													if (g_fade[11].ypos <= 540.0f)
													{
														if (g_fade[12].ypos <= 540.0f)
														{
															if (g_fade[13].ypos <= 540.0f)
															{
																if (g_fade[14].ypos <= 540.0f)
																{
																	if (g_fade[15].ypos <= 540.0f)
																	{
																		if (g_fade[16].ypos <= 540.0f)
																		{
																			if (g_fade[17].ypos <= 540.0f)
																			{
																				if (g_fade[18].ypos <= 540.0f)
																				{
																					if (g_fade[19].ypos <= 540.0f)
																					{
																						g_fadec.fadeON = false;
																						return true;
																					}
																					else
																					{
																						return false;
																					}
																				}
																				else
																				{
																					return false;
																				}
																			}
																			else
																			{
																				return false;
																			}
																		}
																		else
																		{
																			return false;
																		}
																	}
																	else
																	{
																		return false;
																	}
																}
																else
																{
																	return false;
																}
															}
															else
															{
																return false;
															}
														}
														else
														{
															return false;
														}
													}
													else
													{
														return false;
													}
												}
												else
												{
													return false;
												}
											}
											else
											{
												return false;
											}
										}
										else
										{
											return false;
										}
									}
									else
									{
										return false;
									}
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}