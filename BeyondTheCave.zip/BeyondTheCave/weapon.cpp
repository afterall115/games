
#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "Itemstack.h"
#include "weapon.h"
#include "sound.h"
#include "icebox.h"
#include "icespike.h"


static D3DXVECTOR2 vel;

static WEAPON g_weapon;
static WEAPONEFFECT g_weffect[500];
static WEAPONROAP g_weaponroap[20];
static WINDEFFECT g_windeff[400];

static int g_Texturewindchain;
static int g_Texturewindarea;
static int g_Texturehookgun;
static int g_Texturehookchain;
static int g_Texturehooklance;
static int g_Texturefiregunidle;
static int g_Texturefiregunfire;
static int g_Texturefireguneffect;
static int g_Texturefirechain;
static int g_Texturefirelance;
static int g_Textureroap;
static int g_windparticle;


static int g_BGMchainroll;
static int g_BGMgun;
static int g_BGMwindlance;

WEAPON* Getweapon(void)
{
	return &g_weapon;
}


void Initweapon()
{
	g_Texturewindchain = LoadTexture((char*)"data/TEXTURE/windchain.png");
	g_Texturewindarea = LoadTexture((char*)"data/TEXTURE/windarea.png");
	g_Texturehookgun = LoadTexture((char*)"data/TEXTURE/hookgun.png");
	g_Texturehooklance = LoadTexture((char*)"data/TEXTURE/hooklance.png");
	g_Texturefiregunidle = LoadTexture((char*)"data/TEXTURE/match_idle.png");
	g_Texturefiregunfire = LoadTexture((char*)"data/TEXTURE/match_fire.png");
	g_Texturefireguneffect = LoadTexture((char*)"data/TEXTURE/fireparticle.png");
	g_Textureroap = LoadTexture((char*)"data/TEXTURE/roap.png");
	g_Texturefirelance = LoadTexture((char*)"data/TEXTURE/lance.png");
	g_windparticle = LoadTexture((char*)"data/TEXTURE/particletable.png");


	g_BGMchainroll = LoadSound((char*)"data/SE/chain.wav");
	g_BGMgun = LoadSound((char*)"data/SE/gun.wav");
	g_BGMwindlance = LoadSound((char*)"data/SE/windlance.wav");

	if (g_weapon.chainhit == NULL || g_weapon.chainhit == true)
	{
		g_weapon.chainhit = false;
	}

}

void Uninitweapon()
{

}

void Updateweapon()
{
	D3DXVECTOR2 basePos = GetBase();
	PLAYER* pPlayer = GetPlayer();

	if (g_weapon.windgun == true)
	{
			windgun();
			pPlayer->gravityscale = 0.0f;

			if (pPlayer->speed <= 0.0f || g_weapon.windgun == false)
		{
			g_weapon.windgun = false;
			g_weapon.impulse = 0.0f;
			g_weapon.onetimewindgun = 0;
		}
	}

	if (g_weapon.windchain == true)
	{
		windchain();
		pPlayer->jumpFlag = true;
		if(g_weapon.windchainuseframe >= 300 || g_weapon.windchain == false || GetThumbLeftYTriggered(0, -0.9f)) //DIK_S
		{
			StopSound(g_BGMwindlance);
			g_weapon.windchain = false;
			g_weapon.windchainuseframe = 0;
			g_weapon.onetimewindchain = 0;

		}
	}

	if (g_weapon.windlance == true)
	{
		windlance();
		if (g_weapon.windlanceuseframe >= 500 || g_weapon.windlance == false)
		{
			StopSound(g_BGMwindlance);
			g_weapon.windlance = false;
			g_weapon.windlanceuseframe = 0;
			g_weapon.onetimewindlance = 0;
		}
	}

	if (g_weapon.hookgun == true)
	{
		hookgun();
		if (g_weapon.hookgun == false || GetThumbLeftYTriggered(0, -0.9f)) //DIK_S
		{
			g_weapon.hookgun = false;
			g_weapon.onetimehookgun = 0;
			g_weapon.gunhit = false;
		}
	}

	if (g_weapon.hookchain == true)
	{
		hookchain();
		pPlayer->jumpFlag;
		if (g_weapon.hookchain == false || GetThumbLeftYTriggered(0, -0.9f) || IsButtonTriggered(0,XINPUT_GAMEPAD_A) || g_weapon.chainweaponspeed <=0.0f) //DIK_S DIK_SPACE
		{
			g_weapon.hookchain = false;
			g_weapon.onetimehookchain = 0;
			g_weapon.chainhit = false;
			pPlayer->moveinpulse = g_weapon.hookchainwave;
		}
	}


	if (g_weapon.hooklance == true)
	{
		hooklance();
		if (g_weapon.hooklance == false || g_weapon.hooklanceuseframe >= 800)
		{
			g_weapon.hooklance = false;
			g_weapon.onetimehookgun = 0;
			g_weapon.hooklanceuseframe = 0;
		}
	}

	if (g_weapon.firegun == true)
	{
		firegun();
		if (g_weapon.firegun == false || g_weapon.bulletcount >= 4)
		{
			g_weapon.firegun = false;
			g_weapon.onetimefiregun = 0;
			g_weapon.bulletrotate = 0;
			g_weapon.bulletcount = 0;
		}
	}
	if (g_weapon.firechain == true)
	{
		firechain();
		if (g_weapon.firechain == false )
		{
			g_weapon.firechain = false;
			g_weapon.onetimefirechain = 0;
		}
	}
	if (g_weapon.firelance == true)
	{
		firelance();
		if (g_weapon.firelance == false || g_weapon.firelanceuseframe >= 500)
		{
			g_weapon.firelance = false;
			g_weapon.firelanceuseframe = 0;
			g_weapon.onetimefirelance = 0;
		}
	}
}

void Drawweapon()
{
	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();



	if (g_weapon.windgun == true)
	{
		for (int i = 0; i < 100; i++)
		{
			DrawSpriteColorRotate(g_windparticle, basePos.x + g_windeff[i].windeffect.x, basePos.y + g_windeff[i].windeffect.y, 5.0f, 5.0f, 0.25f, 0.0f, 0.25f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_windeff[i].windcolor), 0.0f);
		}
	}

	if (g_weapon.windchain == true)
	{
		DrawSprite(g_Texturewindchain, basePos.x + pPlayer->pos.x, basePos.y + pPlayer->pos.y - 70.0f, 384.0f, 32.0f, 0.0f, 0.0f + (0.5f * (g_weapon.windchainani % 2)), 1.0f, 0.5f);
		for (int i = 100; i < 200; i++)
		{
			if (g_windeff[i].use == true)
			{
				DrawSpriteColorRotate(g_windparticle, basePos.x + g_windeff[i].windeffect.x, basePos.y + g_windeff[i].windeffect.y, 5.0f, 50.0f, 0.25f, 0.0f, 0.25f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_windeff[i].windcolor), 0.0f);
			}
		}
	}

	if (g_weapon.windlance == true)
	{
		DrawSprite(g_Texturewindarea, basePos.x + g_weapon.windlancepos.x, basePos.y + g_weapon.windlancepos.y, 192.0f, 512.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		for (int i = 200; i < 400; i++)
		{
			DrawSpriteColorRotate(g_windparticle, basePos.x + g_windeff[i].windeffect.x, basePos.y + g_windeff[i].windeffect.y, 4.0f, 35.0f, 0.25f, 0.0f, 0.25f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_windeff[i].windcolor), 0.0f);
		}
	}


	if (g_weapon.hookgun == true)
	{
		for (int n = 0; n < 20; n++)
		{
			DrawSpriteColorRotate(g_Textureroap, basePos.x + g_weaponroap[n].pos.x, basePos.y + g_weaponroap[n].pos.y, 10.0f, 10.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);
		}
		DrawSprite(g_Texturehookgun, basePos.x + g_weapon.bulletpos.x, basePos.y + g_weapon.bulletpos.y, 32.0f, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	if (g_weapon.hooklance == true)
	{
		DrawSpriteColorRotate(g_Texturehooklance, basePos.x + g_weapon.hooklancepos.x, basePos.y + g_weapon.hooklancepos.y, 212.0f, 64.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), 0.0f + 3.13f * g_weapon.lancerotate);
	}
	if (g_weapon.hookchain == true)
	{
		for (int n = 0; n < 20; n++)
		{
			DrawSpriteColorRotate(g_Textureroap, basePos.x + g_weaponroap[n].pos.x, basePos.y + g_weaponroap[n].pos.y, 10.0f, 10.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);
		}
		DrawSprite(g_Texturehookgun, basePos.x + g_weapon.hookchainpos.x, basePos.y + g_weapon.hookchainpos.y, 32.0f, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	if (g_weapon.firegun == true)
	{
		if (g_weapon.gunhit == true)
		{
			DrawSpriteColorRotate(g_Texturefiregunfire, basePos.x + g_weapon.bulletpos.x, basePos.y + g_weapon.bulletpos.y, 60.0f, 60.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);

		}
		else
		{
			DrawSpriteColorRotate(g_Texturefiregunidle, basePos.x + g_weapon.bulletpos.x, basePos.y + g_weapon.bulletpos.y, 60.0f, 60.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);
		}
	}

	if (g_weapon.firechain == true)
	{
		DrawSprite(g_Texturehookgun, basePos.x + g_weapon.firechainbulletpos.x, basePos.y + g_weapon.firechainbulletpos.y, 32.0f, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	
		for (int n = 0; n < 20; n++)
		{
			DrawSpriteColorRotate(g_Textureroap, basePos.x + g_weaponroap[n].pos.x, basePos.y + g_weaponroap[n].pos.y, 10.0f, 10.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);
		}
	
	}

	if (g_weapon.firelance == true)
	{
		DrawSprite(g_Texturefirelance, basePos.x + g_weapon.firelancepos.x, basePos.y + g_weapon.firelancepos.y, 32.0f, 128.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	for (int i = 0; i < 100; i++)
	{
		if (g_weffect[i].use == true)
		{
			for (int i = 0; i < 100; i++)
			{
				DrawSpriteColorRotate(g_Texturefireguneffect, basePos.x + g_weffect[i].bulleteffect.x, basePos.y + g_weffect[i].bulleteffect.y, g_weffect[i].useframe, g_weffect[i].useframe, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_weapon.bulletrotate);
			}
			if (g_weffect[i].useframe <= 0)
			{
				g_weffect[i].use = false;
			}
			g_weffect[i].useframe -= 1.0f;
		}
	}
	for (int i = 100; i < 200; i++)
	{
		if (g_weffect[i].use == true)
		{
			for (int i = 100; i < 200; i++)
			{
				DrawSpriteColorRotate(g_Texturefireguneffect, basePos.x + g_weffect[i].chaineffect.x, basePos.y + g_weffect[i].chaineffect.y, g_weffect[i].useframe, g_weffect[i].useframe, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), frand() * 10.0f);
			}
			if (g_weffect[i].useframe <= 0)
			{
				g_weffect[i].use = false;
			}
			g_weffect[i].useframe -= 1.0f;
		}
	}
	for (int i = 300; i < 400; i++)
	{
		if (g_weffect[i].use == true)
		{
			DrawSpriteColorRotate(g_Texturefireguneffect, basePos.x + g_weffect[i].lanceeffect.x, basePos.y + g_weffect[i].lanceeffect.y, g_weffect[i].useframe, g_weffect[i].useframe, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), frand() * 10.0f);
		}
		if (g_weffect[i].useframe <= 0)
		{
			g_weffect[i].use = false;
		}
		g_weffect[i].useframe -= 0.5f;
	}

}


void windgun()
{
	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();

	if (g_weapon.onetimewindgun == 0)
	{
		PlaySound(g_BGMgun, 0);
		g_weapon.onetimewindgun = 1;
		g_weapon.impulse = 0;
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		D3DXVec2Normalize(&vel, &vel);

		for (int i = 0; i < 100; i++)
		{
			g_windeff[i].windeffect = pPlayer->pos;
			g_windeff[i].windrand.x = 10.0f - (frand() * 20.0f);
			g_windeff[i].windrand.y = 10.0f - (frand() * 20.0f);
			g_windeff[i].windcolor = 1.0f;
			g_windeff[i].use = true;
		}

	}




	pPlayer->vel.x = vel.x;
	pPlayer->vel.y = vel.y;
	pPlayer->pos += (pPlayer->vel * pPlayer->speed);
	for (int i = 0; i < 100; i++)
	{
		g_windeff[i].windeffect -= (pPlayer->vel * pPlayer->speed);
		g_windeff[i].windeffect += g_windeff[i].windrand;
		g_windeff[i].windcolor -= 0.05f;
	}
	pPlayer->speed = 40 - g_weapon.impulse;
	g_weapon.impulse += 1.0f;
	pPlayer->moveinpulse = 0.0f;

}

void windchain()
{
	PLAYER* pPlayer = GetPlayer();
	PlaySound(g_BGMwindlance, 0);

	if (g_weapon.onetimewindchain == 0)
	{
		g_weapon.windchainuseframe = 0;
		g_weapon.windchainani = 0;
		g_weapon.onetimewindchain = 1;


	}
	for (int i = 100; i < 200; i++)
	{
		if (g_weapon.windeffecount >= 2)
		{
			if (g_windeff[i].use == false)
			{
				g_windeff[i].windeffect.x = pPlayer->pos.x + (192.0f - (frand() * 384.0f));
				g_windeff[i].windeffect.y = pPlayer->pos.y - 70.0f;
				g_windeff[i].windcolor = 1.0f;
				g_windeff[i].use = true;
				g_weapon.windeffecount = 0;
			}
		}

		if (g_windeff[i].use == true)
		{
			g_windeff[i].windcolor -= 0.05f;
			g_windeff[i].windeffect.y = g_windeff[i].windeffect.y + 6.0f;
			if (g_windeff[i].windcolor <= 0)
			{
				g_windeff[i].use = false;
			}
		}
	}
	g_weapon.windeffecount++;
	pPlayer->gravityscale = -0.8f;
	g_weapon.windchainuseframe += 1;
	if (g_weapon.windchainuseframe % 5 == 0)
	{
		g_weapon.windchainani++;
	}

}

void windlance()
{
	PLAYER* pPlayer = GetPlayer();

	if(g_weapon.onetimewindlance == 0)
	{
		PlaySound(g_BGMwindlance, 0);
		g_weapon.windlancepos.x = pPlayer->pos.x;
		g_weapon.windlancepos.y = pPlayer->pos.y - 330.0f;
		g_weapon.onetimewindlance = 1;
		g_weapon.windlanceuseframe = 0;
	}
	for (int i = 200; i < 400; i++)
	{
		if (g_weapon.windeffecount >= 1)
		{
			if (g_windeff[i].use == false)
			{
				g_windeff[i].windeffect.x = g_weapon.windlancepos.x + (96.0f - (frand() * 192.0f));
				g_windeff[i].windeffect.y = g_weapon.windlancepos.y + (256.0f - (frand() * 512.0f));
				g_windeff[i].windcolor = 1.0f;
				g_windeff[i].use = true;
				g_weapon.windeffecount = 0;
			}
		}
		if (g_windeff[i].use == true)
		{
			g_windeff[i].windeffect.y -= frand() * 20.0f;
			g_windeff[i].windeffect.x += 2.0f - (frand() * 4.0f);
			g_windeff[i].windcolor -= 0.05f;
			if (g_windeff[i].windcolor <= 0)
			{
				g_windeff[i].use = false;
			}
		}
	}
	g_weapon.windeffecount++;


	if (HitCheckBox(pPlayer->pos, 88.0f, 128.0f, g_weapon.windlancepos, 192.0f, 512.0f))
	{
		if (pPlayer->gravityscale >= -6.0f)
		{
			pPlayer->gravityscale -= 1.0f;
		}
	}
	g_weapon.windlanceuseframe += 1;

}



void hookgun()
{

	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();
	ICEBOX* pice = Getice();


	if (g_weapon.onetimehookgun == 0)
	{
		PlaySound(g_BGMgun, 0);
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		D3DXVec2Normalize(&vel, &vel);
		pPlayer->vel.x = vel.x;
		pPlayer->vel.y = vel.y;
		g_weapon.bulletpos = pPlayer->pos;
		g_weapon.gunhit = false;
		g_weapon.onetimehookgun = 1;
		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos = pPlayer->pos;
		}
	}
	if (g_weapon.hooklance == true)
	{
		if (HitCheckBox(g_weapon.bulletpos, 60.0f, 60.0f, g_weapon.hooklancepos, 200.0f, 64.0f))
		{
			g_weapon.gunhit = true;
		}
	}
	for (int i = 0; i < pice[1].usecount; i++)
	{
		if (pice[i].use == true)
		{
			if (HitCheckBox(g_weapon.bulletpos, 60.0f, 60.0f, pice[i].pos, 64.0f, 64.0f))
			{
				g_weapon.gunhit = true;
			}
		}
	}
	if (g_weapon.gunhit == true)
	{
		PlaySound(g_BGMchainroll, 0);
		if (g_weapon.gunweaponspeed == 40.0f)
		{
			g_weapon.gunweaponspeed = 0.0f;
		}
		pPlayer->vel.x = pPlayer->pos.x - g_weapon.bulletpos.x;
		pPlayer->vel.y = pPlayer->pos.y - g_weapon.bulletpos.y;
		g_weapon.hookgunroapspeed = sqrt((pPlayer->vel.x * pPlayer->vel.x) + (pPlayer->vel.y * pPlayer->vel.y));
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);
		g_weapon.gunweaponspeed += 0.6f;
		pPlayer->gravityscale = 0.0f;
		pPlayer->pos -= (pPlayer->vel * g_weapon.gunweaponspeed);

		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos = g_weapon.bulletpos + (pPlayer->vel * g_weapon.hookgunroapspeed * (1.0f - (0.05 * i)));
		}

		if (HitCheckBox(g_weapon.bulletpos, 50.0f, 50.0f, pPlayer->pos, 88.0f, 160.0f))
		{
			g_weapon.hookgun = false;
			pPlayer->gravityscale = -10.0f;
		}


	}
	else
	{
		g_weapon.bulletpos -= (pPlayer->vel * g_weapon.gunweaponspeed);
		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos -= pPlayer->vel * g_weapon.gunweaponspeed * (0.05 * i);
		}
		g_weapon.gunweaponspeed = 40.0f;
	}
}



void hookchain()
{
	PLAYER* pPlayer = GetPlayer();
	PLAYERBIRD* pBird = GetBird();
	D3DXVECTOR2 basePos = GetBase();
	ICEBOX* pice = Getice();

	if (g_weapon.onetimehookchain == 0)
	{
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0) + 2.2f);
		pPlayer->vel.x = vel.x;
		pPlayer->vel.y = vel.y;
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);
		g_weapon.hookchainpos = pPlayer->pos;
		g_weapon.chainweaponspeed = 30.0f;
		g_weapon.chaingravity = 0.0f;
		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos = pPlayer->pos;
		}
		g_weapon.chainhit = false;
		g_weapon.onetimehookchain = 1;
	}

	if (g_weapon.chainhit == false)
	{
		g_weapon.hookchainpos -= (pPlayer->vel * g_weapon.chainweaponspeed);
		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos -= (pPlayer->vel * g_weapon.chainweaponspeed * (0.05f * i));
		}
		g_weapon.chainweaponspeed -= 0.5f;
	}
	for (int i = 0; i < pice[1].usecount; i++)
	{
		if (pice[i].use == true)
		{
			if (HitCheckBox(g_weapon.hookchainpos, 50.0f, 50.0f, pice[i].pos, 64.0f, 64.0f))
			{
				g_weapon.chainhit = true;
			}
		}
	}

	if (g_weapon.chainhit == true)
	{
		pPlayer->vel.x = pPlayer->pos.x - g_weapon.hookchainpos.x;
		pPlayer->vel.y = pPlayer->pos.y - g_weapon.hookchainpos.y;
		if (g_weapon.chainweaponspeed <= 30.0f)
		{
			if (pPlayer->jumpFlag == false)
			{
				g_weapon.chainweaponspeed = pPlayer->pos.y - g_weapon.hookchainpos.y;
			}
			else
			{
				g_weapon.chainweaponspeed = sqrt((pPlayer->vel.x * pPlayer->vel.x) + (pPlayer->vel.y * pPlayer->vel.y));
			}
		}
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);

		if (GetThumbLeftXPressed(0, -0.9f) && pBird->actstyle == false) //DIK_A
		{
			g_weapon.hookchainwave -= 0.05f;
			pPlayer->gravityscale = 0.1f;
		}
		if (GetThumbLeftXPressed(0, 0.9f) && pBird->actstyle == false) //DIK_D
		{
			g_weapon.hookchainwave += 0.05f;
			pPlayer->gravityscale = 0.1f;
		}
		if (GetThumbLeftYPressed(0, 0.9f) && pBird->actstyle == false) //DIK_W
		{
			if (g_weapon.chainweaponspeed >= 200.0f)
			{
				PlaySound(g_BGMchainroll, 0);
				g_weapon.chainweaponspeed -= 3.0f;
			}
			pPlayer->gravityscale = 0.1f;
		}

		if (g_weapon.hookchainpos.y < pPlayer->pos.y)
		{
			pPlayer->moveinpulse = 0.0f;
			if (g_weapon.hookchainwave > 30.0f)
			{
				g_weapon.hookchainwave = 30.0f;
			}
			if (g_weapon.hookchainwave < -30.0f)
			{
				g_weapon.hookchainwave = -30.0f;
			}
			pPlayer->pos = g_weapon.hookchainpos + (pPlayer->vel * g_weapon.chainweaponspeed);

			for (int i = 0; i < 20; i++)
			{
				g_weaponroap[i].pos = g_weapon.hookchainpos + (pPlayer->vel * g_weapon.chainweaponspeed * (0.05f * i));
			}
			g_weapon.hookchainwave -= (pPlayer->pos.x - g_weapon.hookchainpos.x) * 0.005f;
			pPlayer->pos.x += g_weapon.hookchainwave;
		}
	}
}




void hooklance()
{
	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();
	ICEBOX* pice = Getice();


	if (g_weapon.onetimehooklance == 0)
	{
		g_weapon.lancehit = false;
		g_weapon.hooklancepos = pPlayer->pos;
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		pPlayer->vel.x = vel.x;
		pPlayer->vel.y = vel.y;
		if (GetThumbLeftXPressed(0, -0.001f))
		{
			g_weapon.lancerotate = 1;
		}
		else
		{
			g_weapon.lancerotate = 0;

		}
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);
		g_weapon.hooklanceuseframe = 0;
		g_weapon.lancegravity = 0.02f;
		g_weapon.lanceweaponspeed = 30.0f;
		g_weapon.onetimehooklance = 1;
	}
	if (g_weapon.lancehit == true)
	{
		if (HitCheckBox(pPlayer->pos, 120.0f, 140.0f, g_weapon.hooklancepos, 200.0f, 64.0f))
		{
			if (HitCheckField(pPlayer->pos, 88.0f, 140.0f, g_weapon.hooklancepos, 192.0f, 54.0f))
			{
				pPlayer->pos.y = g_weapon.hooklancepos.y - 97.0f;
				pPlayer->gravityscale = 0.0f;
				pPlayer->jumpFlag = false;
			}
			if (HitCheckwallleft(pPlayer->pos, 88.0f, 140.0f, g_weapon.hooklancepos, 192.0f, 54.0f))
			{
				pPlayer->pos.x = g_weapon.hooklancepos.x + 140.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckwallright(pPlayer->pos, 88.0f, 140.0f, g_weapon.hooklancepos, 192.0f, 54.0f))
			{
				pPlayer->pos.x = g_weapon.hooklancepos.x - 140.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckCelling(pPlayer->pos, 88.0f, 140.0f, g_weapon.hooklancepos, 192.0f, 54.0f))
			{
				pPlayer->jumpPower = 0.0f;
				pPlayer->pos.y = g_weapon.hooklancepos.y + 105.0f;

			}
		}

		g_weapon.hooklanceuseframe++;
	}
	else
	{
		g_weapon.hooklancepos -= (pPlayer->vel * g_weapon.lanceweaponspeed);
		g_weapon.hooklancepos.y += g_weapon.lancegravity;
		g_weapon.lancegravity += 0.5f;
	}

	for (int i = 0; i < pice[1].usecount; i++)
	{
		if (pice[i].use == true)
		{
			if (HitCheckBox(g_weapon.hooklancepos, 170.0f, 54.0f, pice[i].pos, 64.0f, 64.0f))
			{
				g_weapon.lancehit = true;
			}
		}
	}

}




void firegun()
{

	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();

	if (g_weapon.onetimefiregun == 0)
	{
		PlaySound(g_BGMgun, 0);
		g_weapon.bulletcount = 0;
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		pPlayer->vel.x = vel.x;
		pPlayer->vel.y = vel.y;
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);
		g_weapon.gunweaponspeedy = 20.0f;
		g_weapon.gunweaponspeedx = 20.0f;
		g_weapon.bulletpos = pPlayer->pos;
		g_weapon.gunhit = false;
		g_weapon.onetimefiregun = 1;
	}
	g_weapon.bulletpos.x -= (pPlayer->vel.x * g_weapon.gunweaponspeedx);
	g_weapon.bulletpos.y -= (pPlayer->vel.y * g_weapon.gunweaponspeedy);

	g_weapon.bulletrotate += 0.8f;

	if (g_weapon.gunhit == true)
	{
		if (g_weapon.bulleteffectcool >= 2)
		{
			if (g_weffect[g_weapon.bulleteffectcount].use == false)
			{
				g_weffect[g_weapon.bulleteffectcount].bulleteffect = g_weapon.bulletpos;
				g_weffect[g_weapon.bulleteffectcount].use = true;
				g_weffect[g_weapon.bulleteffectcount].useframe = 30.0f;
				g_weapon.bulleteffectcool = 0;
			}

			if (g_weapon.bulleteffectcount > 100)
			{
				g_weapon.bulleteffectcount = 0;
			}
			else
			{
				g_weapon.bulleteffectcount++;
			}
		}
		if (g_weapon.bulleteffectcount > 100)
		{
			g_weapon.bulleteffectcount = 0;
		}

			g_weapon.bulleteffectcool++;
	}

}

void firechain()
{

	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();
	ICEBOX* picebox = Getice();
	ICESPIKE* pspike = Geticespike();


	if (g_weapon.onetimefirechain == 0)
	{
		vel = D3DXVECTOR2(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		pPlayer->vel.x = vel.x;
		pPlayer->vel.y = vel.y;
		D3DXVec2Normalize(&pPlayer->vel, &pPlayer->vel);
		g_weapon.chainweaponspeed = 35.0f;
		g_weapon.firechainbulletpos = pPlayer->pos;


		for (int i = 0; i < 20; i++)
		{
			g_weaponroap[i].pos = pPlayer->pos;
		}

		g_weapon.onetimefirechain = 1;
	}

	g_weapon.firechainbulletpos -= (pPlayer->vel * g_weapon.chainweaponspeed);
	g_weapon.chainweaponspeed -= 1.0f;
	for (int i = 0; i < 20 ; i++)
	{
		g_weaponroap[i].pos -= (pPlayer->vel * g_weapon.chainweaponspeed * (0.05f * i));
	}


	if (g_weapon.chainweaponspeed <= 0)
	{
		for (int i = 100 ; i < 200; i++)
		{
			g_weffect[i].roaprand = frand() * 20;
			g_weffect[i].chaineffect.x = g_weaponroap[g_weffect[i].roaprand].pos.x + (32.0f - (frand() * 64.0f));
			g_weffect[i].chaineffect.y = g_weaponroap[g_weffect[i].roaprand].pos.y + (32.0f - (frand() * 64.0f));
			g_weffect[i].useframe = 32.0f;
			g_weffect[i].use = true;
		}
		for (int n = 0; n < 20; n++)
		{
			for (int i = 0; i < picebox[1].usecount; i++)
			{
				if (HitCheckBox(g_weaponroap[n].pos, 64.0f, 64.0f, picebox[i].pos, 64.0f, 64.0f))
				{
					picebox[i].use = false;
				}
			}
			for (int m = 0; m < pspike[1].usecount; m++)
			{
				if (HitCheckBox(g_weaponroap[n].pos, 64.0f, 64.0f, pspike[m].pos, 64.0f, 128.0f))
				{
					pspike[m].crack = true;
				}
			}

		}
	}
	if (g_weapon.chainweaponspeed < -2)
	{
		g_weapon.firechain = false;
	}
}


void firelance()
{
	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();
	ICEBOX* picebox = Getice();
	ICESPIKE* pspike = Geticespike();


	if (g_weapon.onetimefirelance == 0)
	{
		g_weapon.firelancepos = pPlayer->pos;
		for (int i = 300; i < 400; i++)
		{
			g_weffect[i].lanceeffect.x = pPlayer->pos.x;
			g_weffect[i].lanceeffect.y = pPlayer->pos.y - 200.0f;
			g_weffect[i].randmove = 5.0f - (frand() * 10.0f);
			g_weapon.onetimefirelance = 1;
			g_weapon.firelanceuseframe = 0;
		}
	}

	g_weapon.firelanceuseframe++;

	for (int i = 300; i < 400; i++)
	{
		if (g_weapon.firelancecool >= 5)
		{
			if (g_weffect[i].use == false)
			{
				g_weffect[i].lanceeffect = g_weapon.firelancepos;
				g_weffect[i].gravity = -16.0f;
				g_weffect[i].use = true;
				g_weffect[i].useframe = 32.0f;
				g_weapon.firelancecool = 0;
			}
		}
		if (g_weffect[i].use == true)
		{
			g_weffect[i].lanceeffect.x += g_weffect[i].randmove;
			g_weffect[i].lanceeffect.y += g_weffect[i].gravity;
			for (int n = 0; n < picebox[1].usecount; n++)
			{
				if (HitCheckBox(g_weffect[i].lanceeffect, 20.0f, 20.0f, picebox[n].pos, 64.0f, 64.0f))
				{
					picebox[n].use = false;
				}
			}
			for (int m = 0; m < pspike[1].usecount; m++)
			{
				if (HitCheckBox(g_weffect[i].lanceeffect, g_weffect[i].useframe, g_weffect[i].useframe, pspike[m].pos, 64.0f, 128.0f))
				{
					pspike[m].crack = true;
				}
			}
			g_weffect[i].gravity += 0.5f;
		}
	}
	g_weapon.firelancecool++;
}
