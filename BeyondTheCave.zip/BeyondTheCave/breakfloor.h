#pragma once

#include "main.h"
#include "renderer.h"

struct BREAKFLOOR
{
	D3DXVECTOR2 pos;

	int mesh[MAX_YMAP][MAX_XMAP];
	int spotcount;

	bool use;
	int repopcool;
};

void InitBreakfloor(void);
void UninitBreakfloor(void);
void UpdateBreakfloor(void);
void DrawBreakfloor(void);


BREAKFLOOR* GetBreakFloor(void);