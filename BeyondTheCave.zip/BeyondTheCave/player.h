#pragma once

#include "main.h"
#include "renderer.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
struct PLAYER
{
	D3DXVECTOR2 pos;
	D3DXVECTOR2 cameraact;
	D3DXVECTOR2	vel;	//���x�x�N�g��

	float		height;	//����
	float		jumpPower;//�W�����v��
	float		gravity;//�d��
	int			jumpFlag;//�W�����v���t���O
	float   speed;
	int    HP;
	int hitcool;
	float hitanim;

	int			muki;
	int			animePtn;
	int			animeCounter;
	int			animemove;
	int			animecont;
	float       moveinpulse;
	float		gravityscale;

	int			use;
	bool		aimmode;
	bool		hit;
	bool        fieldstand;  //�n�ʂ̏�ɗ����Ă��邩�ǂ���
	bool		wallhitleft;
	bool		wallhitright;
	bool       icework;

	int cameracount;

};

struct PLAYERBIRD
{
	D3DXVECTOR2 pos;
	int muki;
	int animecount;
	int count;
	bool actstyle;

};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
HRESULT InitPlayer(void);
void UninitPlayer(void);
void UpdatePlayer(void);
void DrawPlayer(void);
void Drawhealth(void);

PLAYER* GetPlayer(void);
PLAYERBIRD* GetBird(void);
static int cooltime;
