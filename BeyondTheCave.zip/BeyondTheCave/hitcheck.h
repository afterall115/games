#pragma once

#include "main.h"
#include "renderer.h"


struct FMAP
{
	D3DXVECTOR2 pos;



};

void CheckHitSomething(D3DXVECTOR2 mappos, float width, float height);