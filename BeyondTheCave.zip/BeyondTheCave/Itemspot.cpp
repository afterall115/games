

#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "Itemspot.h"
#include "Itemstack.h"
#include "sound.h"

//===================================================

static int   g_TextureSpot = 0;
static ITEMSPOT  g_spot;

static int g_Seget;

static ITEMSPOTWIND g_ItemspotWind[50];
static ITEMSPOTHOOK g_ItemspotHook[50];
static ITEMSPOTFIRE g_Itemspotfire[50];
static ITEMSPOT g_Itemspot;

FILE  *fpMapspotdate00;


void InitItemspot(void)
{

	g_TextureSpot = LoadTexture((char*)"data/TEXTURE/balloon.png");

	g_Seget = LoadSound((char*)"data/SE/decide.wav");

	g_Itemspot.spotcount = 0;

	for (int i = 0; i < 50; i++)
	{
		g_ItemspotWind[i].use = false;
	}

	g_Itemspot.fall = true;
	g_Itemspot.ymove = 0;


}

void UninitItemspot(void)
{

}

void UpdateItemspot(void)
{
	PLAYER* pPlayer = GetPlayer();
	ITEMSTACK* pStack = GetItemStack();
	if (g_Itemspot.fall == true)
	{
		g_Itemspot.ymove -= 0.01f;
	}
	if (g_Itemspot.fall == false)
	{
		g_Itemspot.ymove += 0.01f;
	}

	if (g_Itemspot.ymove >= 0.5f)
	{
		g_Itemspot.fall = true;
	}
	if (g_Itemspot.ymove <= -0.5f)
	{
		g_Itemspot.fall = false;
	}

	if (g_Itemspot.animcool >= 5)
	{
		if (g_Itemspot.animcount >= 3)
		{
			g_Itemspot.animcount = 0;
		}
		else
		{
			g_Itemspot.animcount++;
		}
		g_Itemspot.animcool = 0;
	}
	g_Itemspot.animcool++;


	for (int x = 0; x < g_ItemspotWind[1].usecount; x++)
	{
		if (g_ItemspotWind[x].use == true)
		{
			if (HitCheckBox(pPlayer->pos, 128.0f, 120.0f, g_ItemspotWind[x].pos, 120.0f, 120.0f))
			{
				PlaySound(g_Seget, 0);
				pStack->stack = 1;
				g_ItemspotWind[x].use = false;
			}
		}

		if (g_ItemspotWind[x].use == false)
		{
			if (g_ItemspotWind[x].repopcool >= 150)
			{
				g_ItemspotWind[x].use = true;
				g_ItemspotWind[x].repopcool = 0;


			}

			g_ItemspotWind[x].repopcool+= 1;
		}
		g_ItemspotWind[x].pos.y += g_Itemspot.ymove;

	}

	for (int y = 0; y < g_ItemspotHook[1].usecount; y++)
	{
		{
			if (g_ItemspotHook[y].use == true)
			{
				if (HitCheckBox(pPlayer->pos, 128.0f, 120.0f, g_ItemspotHook[y].pos, 120.0f, 120.0f))
				{
					PlaySound(g_Seget, 0);
					pStack->stack = 2;
					g_ItemspotHook[y].use = false;
				}
			}

			if (g_ItemspotHook[y].use == false)
			{
				if (g_ItemspotHook[y].repopcool >= 150)
				{
					g_ItemspotHook[y].use = true;
					g_ItemspotHook[y].repopcool = 0;


				}

				g_ItemspotHook[y].repopcool += 1;
			}
			g_ItemspotHook[y].pos.y += g_Itemspot.ymove;

		}
	}

	for (int z = 0; z < g_Itemspotfire[1].usecount; z++)
	{
		{
			if (g_Itemspotfire[z].use == true)
			{
				if (HitCheckBox(pPlayer->pos, 128.0f, 120.0f, g_Itemspotfire[z].pos, 120.0f, 120.0f))
				{
					PlaySound(g_Seget, 0);
					pStack->stack = 3;
					g_Itemspotfire[z].use = false;
				}
			}

			if (g_Itemspotfire[z].use == false)
			{
				if (g_Itemspotfire[z].repopcool >= 150)
				{
					g_Itemspotfire[z].use = true;
					g_Itemspotfire[z].repopcool = 0;


				}

				g_Itemspotfire[z].repopcool += 1;
			}

			g_Itemspotfire[z].pos.y += g_Itemspot.ymove;

		}
	}
}

void DrawItemspot(void)
{

	D3DXVECTOR2 basePos = GetBase();

	for (int x = 0; x < g_ItemspotWind[1].usecount; x++)
	{
		if (g_ItemspotWind[x].use == true)
		{
			DrawSprite(g_TextureSpot, basePos.x + g_ItemspotWind[x].pos.x, basePos.y + g_ItemspotWind[x].pos.y, 128.0f, 128.0f, 0.0f + 0.25 * g_Itemspot.animcount, 0.0f, 1.0f / 4, 1.0f / 3);
		}
	}

	for (int y = 0; y < g_ItemspotHook[1].usecount; y++)
	{
		if (g_ItemspotHook[y].use == true)
		{
			DrawSprite(g_TextureSpot, basePos.x + g_ItemspotHook[y].pos.x, basePos.y + g_ItemspotHook[y].pos.y, 128.0f, 128.0f, 0.0f + 0.25 * g_Itemspot.animcount, 0.33333f, 1.0f / 4, 1.0f / 3);
		}
	}

	for (int z = 0; z < g_Itemspotfire[1].usecount; z++)
	{
		if (g_Itemspotfire[z].use == true)
		{
			DrawSprite(g_TextureSpot, basePos.x + g_Itemspotfire[z].pos.x, basePos.y + g_Itemspotfire[z].pos.y, 128.0f, 128.0f, 0.0f + 0.25 * g_Itemspot.animcount, 0.666667f, 1.0f / 4, 1.0f / 3);
		}
	}

}

ITEMSPOTWIND* GetSpotwind(void)
{
	return (&g_ItemspotWind[0]);
}


ITEMSPOTHOOK* GetSpotHook(void)
{
	return (&g_ItemspotHook[0]);
}

ITEMSPOTFIRE* GetSpotfire(void)
{
	return (&g_Itemspotfire[0]);
}