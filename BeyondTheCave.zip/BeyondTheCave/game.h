#pragma once

#include "main.h"
#include "renderer.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
struct GAME
{
	bool  pause;

	int  choise;
	int  pausechoise;
	bool config;
};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
void InitGame(void);
void UninitGame(void);
void UpdateGame(void);
void DrawGame(void);


void InitTitlemode(void);
void UninitTitlemode(void);
void UpdateTitlemode(void);
void DrawTitlemode(void);

void InitResultmode(void);
void UninitResultmode(void);
void UpdateResultmode(void);
void DrawResultmode(void);
