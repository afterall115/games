#include "Texture.h"
#include "Sprite.h"
#include "goal.h"
#include "player.h"
#include "main.h"
#include "game.h"
#include "Fieldcollision.h"
#include "collision.h"
#include "main.h"
#include "fade.h"
#include "camera.h"
#include "Title.h"


static int g_TextureGoal;
static int g_TextureGoalhit;
static int g_TextureGoalparticle;


struct GOAL g_Goal;
struct GOALEFFECT g_Goalef[100];

void InitGoal()
{
	TITLECOUNT* pTitlecount = GetTitlecount();


	g_TextureGoal = LoadTexture((char*)"data/TEXTURE/Goal.png");
	g_TextureGoalhit = LoadTexture((char*)"data/TEXTURE/Goalhit.png");
	g_TextureGoalparticle = LoadTexture((char*)"data/TEXTURE/Goaleffect.png");


	g_Goal.playerhit = false;
	g_Goal.checkonetime = 0;


	if (pTitlecount->modechoise = 1)
	{
		switch (pTitlecount->choise)
		{
		case 1:

			g_Goal.pos.x = 64.0f * 191;
			g_Goal.pos.y = -32.0f + (64.0f * 21);
			break;
		case 2:
			g_Goal.pos.x = 64.0f * 209;
			g_Goal.pos.y = -32.0f + (64.0f * 73);
			break;
		case 3:
			g_Goal.pos.x = 64.0f * 144;
			g_Goal.pos.y = -32.0f + (64.0f * 150);
			break;
		case 4:
			g_Goal.pos.x = 64.0f * 296;
			g_Goal.pos.y = -32.0f + (64.0f * 26);
			break;
		case 5:
			g_Goal.pos.x = 64.0f * 163;
			g_Goal.pos.y = -32.0f + (64.0f * 23);
			break;
		}
	}
}

void UninitGoal()
{

}

void UpdateGoal()
{

	PLAYER* pPlayer = GetPlayer();
	if (HitCheckBox(g_Goal.pos, 128.0f, 96.0f, pPlayer->pos, 88.0f, 170.0f))
	{
		g_Goal.playerhit = true;
	}

	if (g_Goal.playerhit == true && g_Goal.checkonetime <= 30)
	{
		Setfadeout();
		g_Goal.checkonetime++;
	}

	if (fadeoutOK() && g_Goal.playerhit == true)
	{
		SetScene(SCENE_RESULT);
	}

	for (int n = 0; n < 100; n++)
	{
		if (g_Goalef[n].use == false && g_Goal.particlecount >= 4)
		{
			g_Goalef[n].pos.x = g_Goal.pos.x + (64.0f - (frand() * 128.0f));
			g_Goalef[n].pos.y = g_Goal.pos.y + (32.0f - (frand() * 64.0f));
			g_Goalef[n].size = 10.0f;
			g_Goal.particlecount = 0;
			g_Goalef[n].use = true;
		}

		if (g_Goalef[n].use == true)
		{
			g_Goalef[n].size -= 0.05f;
			g_Goalef[n].pos.y -= 0.5f;

			if (g_Goalef[n].size <= 0.0f)
			{
				g_Goalef[n].use = false;
			}
		}
	}
	g_Goal.particlecount++;

}

void DrawGoal()
{
	D3DXVECTOR2 basePos = GetBase();

	if (g_Goal.playerhit == true)
	{
		DrawSprite(g_TextureGoalhit, basePos.x + g_Goal.pos.x, basePos.y + g_Goal.pos.y, 256.0f, 128.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	else
	{
		DrawSprite(g_TextureGoal, basePos.x + g_Goal.pos.x, basePos.y + g_Goal.pos.y, 256.0f, 128.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	for (int n = 0; n < 100; n++)
	{
		if (g_Goalef[n].use == true)
		{
			DrawSprite(g_TextureGoalparticle, basePos.x + g_Goalef[n].pos.x, basePos.y + g_Goalef[n].pos.y, g_Goalef[n].size, g_Goalef[n].size, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
}

GOAL* GetGoal(void)
{
	return &g_Goal;
}