//=============================================================================
//
// ���͏��� [input.cpp]
// Author : 
//
//=============================================================================
#include "main.h"
#include "inputx.h"
#include "mouse.h"
#include "keyboard.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define DEADZONE			8800	// �e����25%�𖳌��]�[���Ƃ���
#define MAX_CONTROLLERS     4

struct CONTROLER_STATE
{
	XINPUT_STATE		lastState;
	XINPUT_STATE		state;
	XINPUT_STATE		trigger;
	XINPUT_VIBRATION	vibration;
};

struct KEYBOARD_STATE
{
	Keyboard_State	lastState;
	Keyboard_State	state;
	Keyboard_State	trigger;
	Keyboard_State	release;
};

struct MOUSE_STATE
{
	Mouse_State		lastState;
	Mouse_State		state;
	Mouse_State		trigger;
	Mouse_State		release;
};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
HRESULT InitializePad(void);			// �p�b�h������
void UpdatePad(void);
void UpdateKeyboard(void);
void UpdateMouse(void);
void UninitPad(void);

//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
CONTROLER_STATE g_Controllers[MAX_CONTROLLERS];
static float	g_LeftStickX[MAX_CONTROLLERS];
static float	g_LeftStickY[MAX_CONTROLLERS];
static float	g_RightStickX[MAX_CONTROLLERS];
static float	g_RightStickY[MAX_CONTROLLERS];
static float	g_LastLeftStickX[MAX_CONTROLLERS];
static float	g_LastLeftStickY[MAX_CONTROLLERS];
static float	g_LastRightStickX[MAX_CONTROLLERS];
static float	g_LastRightStickY[MAX_CONTROLLERS];

KEYBOARD_STATE	g_Keyboard;

MOUSE_STATE		g_Mouse;

//=============================================================================
// ���͏����̏�����
//=============================================================================
HRESULT InitInput(HINSTANCE hInst, HWND hWnd)
{	
	// �p�b�h�̏�����
	InitializePad();
	Mouse_Initialize(hWnd);
	Keyboard_Initialize();

	return S_OK;
}

//=============================================================================
// ���͏����̏I������
//=============================================================================
void UninitInput(void)
{
	// �p�b�h�̏I������
	Mouse_Finalize();
	UninitPad();
}

//=============================================================================
// ���͏����̍X�V����
//=============================================================================
void UpdateInput(void)
{
	// �p�b�h�̍X�V
	UpdatePad();
	UpdateMouse();
	UpdateKeyboard();
}

//=============================================================================
// �p�b�h�֘A
//=============================================================================
//---------------------------------------- ������
HRESULT InitializePad(void)			// �p�b�h������
{
	//������
	ZeroMemory(g_Controllers, sizeof(CONTROLER_STATE) * MAX_CONTROLLERS);

	XInputEnable(true);
		
	return true;

}

//------------------------------------------- �I������
void UninitPad(void)
{
	//�p�����[�^�̃��Z�b�g
	ZeroMemory(g_Controllers, sizeof(CONTROLER_STATE) * MAX_CONTROLLERS);

	//�o�C�u���[�V������~
	for (DWORD i = 0; i < MAX_CONTROLLERS; i++)
		XInputSetState(i, &g_Controllers[i].vibration);

	XInputEnable(false);
}

//------------------------------------------ �X�V
void UpdatePad(void)
{
	for (DWORD i = 0; i < MAX_CONTROLLERS; i++)
	{
		XInputSetState(i, &g_Controllers[i].vibration);

		g_Controllers[i].lastState = g_Controllers[i].state;

		//����FERROR_SUCCESS�@0
		//�ڑ������FERROR_DEVICE_NOT_CONNECTED 1167
		DWORD result;
		result = XInputGetState(i, &g_Controllers[i].state);

		//�g���K�[�쐬
		g_Controllers[i].trigger.Gamepad.wButtons = ((g_Controllers[i].lastState.Gamepad.wButtons ^ g_Controllers[i].state.Gamepad.wButtons) & g_Controllers[i].state.Gamepad.wButtons);

		//���X�e�B�b�N���̍쐬
		g_LastLeftStickX[i] = g_LeftStickX[i];
		g_LastLeftStickY[i] = g_LeftStickY[i];

		float LX = g_Controllers[i].state.Gamepad.sThumbLX;
		float LY = g_Controllers[i].state.Gamepad.sThumbLY;

		float magnitude = sqrtf((LX * LX) + (LY * LY));

		if (magnitude > 32767)
			magnitude = 32767;

		magnitude -= DEADZONE;

		if (magnitude <= 0)
		{
			g_Controllers[i].state.Gamepad.sThumbLX = 0;
			g_Controllers[i].state.Gamepad.sThumbLY = 0;
		}

		if(g_Controllers[i].state.Gamepad.sThumbLX >= 0)
			g_LeftStickX[i] = (float)g_Controllers[i].state.Gamepad.sThumbLX / 32767;
		else
			g_LeftStickX[i] = (float)g_Controllers[i].state.Gamepad.sThumbLX / 32768;

		if (g_Controllers[i].state.Gamepad.sThumbLY >= 0)
			g_LeftStickY[i] = (float)g_Controllers[i].state.Gamepad.sThumbLY / 32767;
		else
			g_LeftStickY[i] = (float)g_Controllers[i].state.Gamepad.sThumbLY / 32768;

		//�E�X�e�B�b�N���̍쐬
		g_LastRightStickX[i] = g_RightStickX[i];
		g_LastRightStickY[i] = g_RightStickY[i];

		float RX = g_Controllers[i].state.Gamepad.sThumbRX;
		float RY = g_Controllers[i].state.Gamepad.sThumbRY;

		magnitude = sqrtf((RX * RX) + (RY * RY));

		if (magnitude > 32767)
			magnitude = 32767;

		magnitude -= DEADZONE;

		if (magnitude <= 0)
		{
			g_Controllers[i].state.Gamepad.sThumbRX = 0;
			g_Controllers[i].state.Gamepad.sThumbRY = 0;
		}

		if (g_Controllers[i].state.Gamepad.sThumbRX >= 0)
			g_RightStickX[i] = (float)g_Controllers[i].state.Gamepad.sThumbRX / 32767;
		else
			g_RightStickX[i] = (float)g_Controllers[i].state.Gamepad.sThumbRX / 32768;

		if (g_Controllers[i].state.Gamepad.sThumbLY >= 0)
			g_RightStickY[i] = (float)g_Controllers[i].state.Gamepad.sThumbRY / 32767;
		else
			g_RightStickY[i] = (float)g_Controllers[i].state.Gamepad.sThumbRY / 32768;
	}
}

void UpdateKeyboard(void)
{
	g_Keyboard.lastState = g_Keyboard.state;

	g_Keyboard.state = *(Keyboard_GetState());
}

void UpdateMouse(void)
{
	g_Mouse.lastState = g_Mouse.state;

	Mouse_GetState(&g_Mouse.state);

	g_Mouse.trigger = ((g_Mouse.lastState ^ g_Mouse.state) & g_Mouse.state);

	if (g_Mouse.trigger.leftButton == true)
	{
		int a = 0;
	}

	g_Mouse.release = ((g_Mouse.lastState ^ g_Mouse.state) & ~g_Mouse.state);

	if (g_Mouse.release.leftButton == true)
	{
		int a = 0;
	}

}

//=============================================================================
// �p�b�h�֘A
//=============================================================================
//�X�e�B�b�N�͈̔�
// X ��-1.0�@�E 1.0
// Y �� 1.0�@��-1.0
float GetThumbLeftX(int padNo)
{
	return g_LeftStickX[padNo];
}

float GetThumbLeftY(int padNo)
{
	return g_LeftStickY[padNo];
}

float GetThumbRightX(int padNo)
{
	return g_RightStickX[padNo];
}

float GetThumbRightY(int padNo)
{
	return g_RightStickY[padNo];
}

bool GetThumbLeftXTriggered(int padNo, float range)
{
	if(range >= 0.0f) return (g_LeftStickX[padNo] >= range) && (g_LastLeftStickX[padNo] < range);
	else return (g_LeftStickX[padNo] <= range) && (g_LastLeftStickX[padNo] > range);
}

bool GetThumbLeftYTriggered(int padNo, float range)
{
	if (range >= 0.0f) return (g_LeftStickY[padNo] >= range) && (g_LastLeftStickY[padNo] < range);
	else return (g_LeftStickY[padNo] <= range) && (g_LastLeftStickY[padNo] > range);
}

bool GetThumbRightXTriggered(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickX[padNo] >= range) && (g_LastRightStickX[padNo] < range);
	else return (g_RightStickX[padNo] <= range) && (g_LastRightStickX[padNo] > range);
}

bool GetThumbRightYTriggered(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickY[padNo] >= range) && (g_LastRightStickY[padNo] < range);
	else return (g_RightStickY[padNo] <= range) && (g_LastRightStickY[padNo] > range);
}

bool GetThumbLeftXPressed(int padNo, float range)
{
	if (range >= 0.0f) return (g_LeftStickX[padNo] >= range) && (g_LastLeftStickX[padNo] >= range);
	else return (g_LeftStickX[padNo] <= range) && (g_LastLeftStickX[padNo] <= range);
}

bool GetThumbLeftYPressed(int padNo, float range)
{
	if (range >= 0.0f) return (g_LeftStickY[padNo] >= range) && (g_LastLeftStickY[padNo] >= range);
	else return (g_LeftStickY[padNo] <= range) && (g_LastLeftStickY[padNo] <= range);
}

bool GetThumbRightXPressed(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickX[padNo] >= range) && (g_LastRightStickX[padNo] >= range);
	else return (g_RightStickX[padNo] <= range) && (g_LastRightStickX[padNo] <= range);
}

bool GetThumbRightYPressed(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickY[padNo] >= range) && (g_LastRightStickY[padNo] >= range);
	else return(g_RightStickY[padNo] <= range) && (g_LastRightStickY[padNo] <= range);
}

bool GetThumbLeftXReleased(int padNo, float range)
{
	if (range >= 0.0f) return (g_LeftStickX[padNo] < range) && (g_LastLeftStickX[padNo] >= range);
	else return (g_LeftStickX[padNo] > range) && (g_LastLeftStickX[padNo] <= range);
}

bool GetThumbLeftYReleased(int padNo, float range)
{
	if (range >= 0.0f) return (g_LeftStickY[padNo] < range) && (g_LastLeftStickY[padNo] >= range);
	else return (g_LeftStickY[padNo] > range) && (g_LastLeftStickY[padNo] <= range);
}

bool GetThumbRightXReleased(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickX[padNo] < range) && (g_LastRightStickX[padNo] >= range);
	else return (g_RightStickX[padNo] > range) && (g_LastRightStickX[padNo] <= range);
}

bool GetThumbRightYReleased(int padNo, float range)
{
	if (range >= 0.0f) return (g_RightStickY[padNo] < range) && (g_LastRightStickY[padNo] >= range);
	else return (g_RightStickY[padNo] > range) && (g_LastRightStickY[padNo] <= range);
}

//�g���K�[�͈̔�
// 0 �` 255
int GetLeftTrigger(int padNo)
{
	return g_Controllers[padNo].state.Gamepad.bLeftTrigger;
}

int GetRightTrigger(int padNo)
{
	return g_Controllers[padNo].state.Gamepad.bRightTrigger;
}

// �o�C�u���[�V�����͈̔�
// 0 �` 255
void SetLeftVibration(int padNo, int speed)
{
	speed %= 256;
	g_Controllers[padNo].vibration.wLeftMotorSpeed = ((speed + 1) * 256) - 1;
}

void SetRightVibration(int padNo, int speed)
{
	speed %= 256;
	g_Controllers[padNo].vibration.wRightMotorSpeed = ((speed + 1) * 256) - 1;
}

void SetVibration(int padNo, int speed)
{
	speed %= 256;
	g_Controllers[padNo].vibration.wLeftMotorSpeed = ((speed + 1) * 256) - 1;
	g_Controllers[padNo].vibration.wRightMotorSpeed = ((speed + 1) * 256) - 1;
}

void StopVibration(int padNo)
{
	g_Controllers[padNo].vibration.wLeftMotorSpeed = 0;
	g_Controllers[padNo].vibration.wRightMotorSpeed = 0;
}

//�{�^��������Ԃ̎擾
BOOL IsButtonPressed(int padNo, DWORD button)
{
	return (button & g_Controllers[padNo].state.Gamepad.wButtons);
}

//�{�^���p���X��Ԃ̎擾
BOOL IsButtonTriggered(int padNo, DWORD button)
{
	return (button & g_Controllers[padNo].trigger.Gamepad.wButtons);
}

//=============================================================================
// �}�E�X�֘A
//=============================================================================
bool IsMouseLeftPressed(void)
{
	return g_Mouse.state.leftButton;
}
bool IsMouseRightPressed(void)
{
	return g_Mouse.state.rightButton;
}
bool IsMouseMiddlePressed(void)
{
	return g_Mouse.state.middleButton;
}
bool IsMouseButton1Pressed(void)
{
	return g_Mouse.state.xButton1;
}
bool IsMouseButton2Pressed(void)
{
	return g_Mouse.state.xButton2;
}

bool IsMouseLeftTriggered(void)
{
	return g_Mouse.trigger.leftButton;
}
bool IsMouseRightTriggered(void)
{
	return g_Mouse.trigger.rightButton;
}
bool IsMouseMiddleTriggered(void)
{
	return g_Mouse.trigger.middleButton;
}
bool IsMouseButton1Triggered(void)
{
	return g_Mouse.trigger.xButton1;
}
bool IsMouseButton2Triggered(void)
{
	return g_Mouse.trigger.xButton2;
}

bool IsMouseLeftReleased(void)
{
	return g_Mouse.release.leftButton;
}
bool IsMouseRightReleased(void)
{
	return g_Mouse.release.rightButton;
}
bool IsMouseMiddleReleased(void)
{
	return g_Mouse.release.middleButton;
}
bool IsMouseButton1Released(void)
{
	return g_Mouse.release.xButton1;
}
bool IsMouseButton2Released(void)
{
	return g_Mouse.release.xButton2;
}

D3DXVECTOR2 GetMousePos(void)
{
	return D3DXVECTOR2((float)g_Mouse.state.x, (float)g_Mouse.state.y);
}

int GetMouseWheelValue(void)
{
	return g_Mouse.state.scrollWheelValue;
}

//=============================================================================
// �L�[�{�[�h�֘A
//=============================================================================
bool Keyboard_IsKeyTriggered(Keyboard_Keys key)
{
	return (Keyboard_IsKeyDown(key, &g_Keyboard.state) && Keyboard_IsKeyUp(key, &g_Keyboard.lastState));
}

bool Keyboard_IsKeyReleased(Keyboard_Keys key)
{
	return (Keyboard_IsKeyUp(key, &g_Keyboard.state) && Keyboard_IsKeyDown(key, &g_Keyboard.lastState));
}

//bool Keyboard_IsKeyRepeat(Keyboard_Keys key)
//{
//	return (Keyboard_IsKeyDown(key, &g_Keyboard.state) && Keyboard_IsKeyUp(key, &g_Keyboard.lastState));
//}