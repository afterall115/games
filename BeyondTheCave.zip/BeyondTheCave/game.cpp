
/*==============================================================================

   �Q�[����� [game.cpp]
														 Author :
														 Date   :
--------------------------------------------------------------------------------

==============================================================================*/
#include "game.h"
#include "texture.h"
#include "sprite.h"
#include "sound.h"
#include "collision.h"
#include "camera.h"
#include "player.h"
#include "map.h"
#include "Itemspot.h"
#include "Itemstack.h"
#include "weapon.h"
#include "toge.h"
#include "inputx.h"
#include "icebox.h"
#include "stageeffect.h"
#include "fade.h"
#include "Title.h"
#include "Goal.h"
#include "result.h"
#include "bat.h"
#include "heal.h"
#include "icespike.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************


//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************


//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
static int g_BGMNo;
static GAME g_game;

static int g_Texturepause;
static int g_Texturepausearrow;
static int g_Texturepausebutton;
static int g_TexturepauseUI;
static int g_Texturemenu;

//=============================================================================
// ����������
//=============================================================================
void InitGame(void)
{

	g_Texturepause = LoadTexture((char*)"data/TEXTURE/pause.png");
	g_Texturepausearrow = LoadTexture((char*)"data/TEXTURE/hooklance.png");
	g_Texturepausebutton = LoadTexture((char*)"data/TEXTURE/UI_00.png");
	g_TexturepauseUI = LoadTexture((char*)"data/TEXTURE/pauseUI.png");
	g_Texturemenu = LoadTexture((char*)"data/TEXTURE/menu.png");

	g_game.pause = false;

	//�J�����̏�����
	InitCamera();

	Initfade();

	InitThorn();

	Initstageeffect();

	InitPlayer();

	Initice();

	Initbat();

	InitBG();

	InitItemspot();

	InitItem();

	Initheal();

	Initicespike();

	InitGoal();

	Initweapon();
	//�Q�[���pBGM�̓ǂݍ���
	//g_BGMNo = LoadSound((char*)"data/BGM/");

	//BGM�Đ�(��ڂ̈����̓��[�v�� ���̒l���w�肷��Ɩ������[�v)
	//PlaySound(g_BGMNo, -1);


}

void UninitGame(void)
{

	//�J�����̏I������
	UninitCamera();

	UninitPlayer();

	Uninitfade();

	Uninitstageeffect();

	UninitThorn();

	UninitBG();

	Uninitbat();

	Uninitice();

	Uninitheal();

	Uniniticespike();

	UninitItemspot();

	UninitGoal();

	Uninitweapon();

	//�e�N�X�`���̉��
	UninitTexture();
}

void UpdateGame(void)
{
	if (IsButtonTriggered(0, XINPUT_GAMEPAD_START)) //DIK_M
	{
		if (g_game.pause == false)
		{
			g_game.pause = true;
		}
		else
		{
			g_game.pause = false;
		}
	}

	if (g_game.pause == true)
	{
		if (GetThumbLeftYTriggered(0,0.9f)) //DIK_W
		{
				if (g_game.pausechoise == 0)
				{
					g_game.pausechoise = 2;
				}
				else
				{
					g_game.pausechoise--;
				}
		}
		if (GetThumbLeftYTriggered(0, -0.9f)) //DIK_S
		{
				if (g_game.pausechoise == 2)
				{
					g_game.pausechoise = 0;
				}
				else
				{
					g_game.pausechoise++;
				}
		}
		if (IsButtonPressed(0, XINPUT_GAMEPAD_B))
		{
			switch (g_game.pausechoise)
			{
			case 0:
				g_game.pause = false;
				break;
			case 1:
				g_game.config = true;
				break;
			case 2:
				Setfadeout();
				break;
			}
		}
		if (IsButtonTriggered(0, XINPUT_GAMEPAD_A))
		{
			if (g_game.pause == true && g_game.config == false)
			{
				g_game.pause = false;
			}
			if (g_game.config == true)
			{
				g_game.config = false;
			}
		}

		if (fadeoutOK())
		{
			SetScene(SCENE_TITLE);
		}
	}


	if (g_game.pause == false)
	{
		UpdatePlayer();

		Updatestageeffect();

		UpdateBG();

		Updateice();


		UpdateThorn();

		UpdateItemspot();

		UpdateItem();

		Updatebat();

		Updateicespike();

		Updateheal();

		Updateweapon();


		//�J�����̍X�V����
		UpdateCamera();
	}
	UpdateGoal();

	Updatefade();
}

void DrawGame(void)
{


	Drawstageeffect();

	DrawBG();

	Drawice();

	Drawicespike();

	DrawGoal();

	DrawPlayer();

	DrawThorn();
	
	Drawheal();

	Drawbat();

	Drawweapon();

	DrawItemspot();

	DrawItem();

	Drawhealth();

	if (g_game.pause == true)
	{
		DrawSprite(g_Texturepause, 960.0f, 540.0f, 600.0f, 800.0f, 0.0f, 0.0f, 1.0f, 1.0f);

		for (int i = 0; i < 3; i++)
		{
			DrawSprite(g_Texturepausebutton, 960.0f, 420.0f + (160.0f * i), 400.0f, 100.0f, 0.0f, 0.0f, 1.0f, 1.0f);
			DrawSprite(g_TexturepauseUI, 960.0f, 420.0f + (160.0f * i), 400.0f, 92.0f, 0.0f, 0.33333f * i, 1.0f, 0.3333f);
		}
		DrawSprite(g_Texturepausearrow, 740.0f, 420.0f + (160.0f * g_game.pausechoise), 64.0f, 32.0f, 0.0f, 0.0f, 1.0f, 1.0f);

		if (g_game.config == true)
		{
			DrawSprite(g_Texturemenu, 960.0f, 540.0f, 1280.0f, 720.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}

	// �J�����̕`�揈��
	DrawCamera();
	
	Drawfade();


}


void InitTitlemode(void)
{
	Initfade();

	InitTitle();
}

void UninitTitlemode(void)
{
	UninitTitle();

	Uninitfade();
}

void UpdateTitlemode(void)
{
	UpdateTitle();

	Updatefade();
}

void DrawTitlemode(void)
{
	DrawTitle();

	Drawfade();
}

void InitResultmode(void)
{
	Initfade();

	InitResult();
}

void UninitResultmode(void)
{
	UninitResult();

	Uninitfade();
}

void UpdateResultmode(void)
{
	UpdateResult();

	Updatefade();
}

void DrawResultmode(void)
{
	DrawResult();

	Drawfade();
}