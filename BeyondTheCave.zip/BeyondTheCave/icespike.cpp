

#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "weapon.h"
#include "map.h"
#include "icespike.h"

struct ICESPIKE g_spike[200];

static int g_Texturespike;


void Initicespike(void)
{
	for (int i = 0; i < 200; i++)
	{
		g_spike[i].use = true;
		g_spike[i].crack = false;
		g_spike[i].act = false;
		g_spike[i].size = 64.0f;
		g_spike[i].gravity = 0.0f;
	}

	g_Texturespike = LoadTexture((char*)"data/TEXTURE/icespike.png");
}

void Uniniticespike(void)
{

}
void Updateicespike(void)
{
	PLAYER* pPlayer = GetPlayer();
	WEAPON* pweapon = Getweapon();

	for (int i = 0; i < g_spike[1].usecount; i++)
	{
		if (HitCheckBox(g_spike[i].pos, 70.0f, 140.0f, pPlayer->pos, 120.0f, 1080.0f))
		{
			if (g_spike[i].pos.y < pPlayer->pos.y)
			{
				g_spike[i].act = true;
			}
		}
		if (g_spike[i].crack == false)
		{
			if (pPlayer->hitcool <= 0 && HitCheckBox(g_spike[i].pos, 64.0f, 128.0f, pPlayer->pos, 88.0f, 170.0f))
			{
				pPlayer->hit = true;
				pPlayer->hitcool = 100;
				pPlayer->moveinpulse -= 5.0f;
			}
		}
		if (g_spike[i].act == true && g_spike[i].crack == false)
		{
			g_spike[i].gravity += 0.25f;
			g_spike[i].pos.y += g_spike[i].gravity;
		}
		if (g_spike[i].crack == false)
		{
			if (HitCheckBox(pweapon->bulletpos, 55.0f, 55.0f, g_spike[i].pos, 64.0f, 128.0f))
			{
				if (pweapon->gunhit == true)
				{
					g_spike[i].crack = true;
				}
				if (HitCheckField(pweapon->bulletpos, 50.0f, 50.0f, g_spike[i].pos, 64.0f, 128.0f))
				{
					pweapon->bulletpos.y = g_spike[i].pos.y - 89.0f;
					pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
				}
				if (HitCheckwallleft(pweapon->bulletpos, 50.0f, 50.0f, g_spike[i].pos, 64.0f, 128.0f))
				{
					pweapon->bulletpos.x = g_spike[i].pos.x + 57.0f;
					pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;

				}
				if (HitCheckwallright(pweapon->bulletpos, 50.0f, 50.0f, g_spike[i].pos, 64.0f, 128.0f))
				{
					pweapon->bulletpos.x = g_spike[i].pos.x - 57.0f;
					pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;

				}
				if (HitCheckCelling(pweapon->bulletpos, 50.0f, 50.0f, g_spike[i].pos, 64.0f, 128.0f))
				{
					pweapon->bulletpos.y = g_spike[i].pos.y + 89.0f;
					pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
				}
			}
		}
		if (g_spike[i].act == true)
		{
			if (HitCheckBox(g_spike[i].pos, 2100.0f, 1600.0f, pPlayer->pos, 88.0f, 170.0f))
			{

			}
			else
			{
				g_spike[i].crack = true;

			}
		}

		if (g_spike[i].crack == true)
		{
			g_spike[i].size -= 1.0f;
		}
		if (g_spike[i].size <= 0)
		{
			g_spike[i].use = false;
		}
	}
}
void Drawicespike(void)
{
	D3DXVECTOR2 basePos = GetBase();
	PLAYER* pPlayer = GetPlayer();

	for (int i = 0; i < g_spike[1].usecount; i++)
	{
		if (g_spike[i].use == true)
		{
			DrawSprite(g_Texturespike, basePos.x + g_spike[i].pos.x, basePos.y + g_spike[i].pos.y, g_spike[i].size, g_spike[i].size + 64.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
}

ICESPIKE* Geticespike(void)
{
	return &g_spike[0];
}