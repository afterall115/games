/*==============================================================================

   ���_�Ǘ� [player.cpp]
														 Author :
														 Date   :
--------------------------------------------------------------------------------

==============================================================================*/
#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "weapon.h"
#include "Title.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define NUM_VERTEX 4	//�K�v�Ȓ��_�̐�

#define DIVIDE_X 10	//���̕�����
#define DIVIDE_Y 10	//�c�̕�����

#define PATTERN_WIDTH (1.0f / DIVIDE_X)
#define PATTERN_HEIGHT (1.0f / DIVIDE_Y)

#define PLAYER_DISP_X (SCREEN_WIDTH / 2)	//�v���C���[�̕\�����WX
#define PLAYER_DISP_Y (SCREEN_HEIGHT / 2)	//�v���C���[�̕\�����WY

#define PLAYER_MUKI_LEFT  3
#define PLAYER_MUKI_RIGHT  0


//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************


//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
static PLAYER g_Player;
static PLAYERBIRD g_Bird;

static int g_TexturePlayer = 0;//�v���C���[�p�e�N�X�`���̎��ʎq
static int g_TextureNoShadow = 0;//�v���C���[�p�e�̃e�N�X�`���̎��ʎq
static int g_TextureBird = 0;//�v���C���[�p�e�̃e�N�X�`���̎��ʎq
static int g_TextureHP = 0;//�v���C���[�̗͕̑\��

float color;


static float g_WidthTable[10] =
{
	0.0f,
	0.1f,
	0.2f,
	0.3f,
	0.4f,
	0.5f,
	0.6f,
	0.7f,
	0.8f,
	0.9f,

};

static float g_HeightTable[10] =
{
	0.0f,
	0.1f,
	0.2f,	//������
	0.3f,	//������
	0.4f,
	0.5f,
	0.6f,
	0.7f,
	0.8f,
	0.9f,
};

static float g_Birdmove[4] = 
{
	0.0f,
	0.25f,
	0.5f,
	0.75f
};
//=============================================================================
// ����������
//=============================================================================
HRESULT InitPlayer(void)
{
	TITLECOUNT* pTitlecount = GetTitlecount();


	//�e�N�X�`���̓ǂݍ���
	g_TexturePlayer = LoadTexture((char*)"data/TEXTURE/player.png");
	g_TextureBird = LoadTexture((char*)"data/TEXTURE/Birdanim.png");
	g_TextureHP = LoadTexture((char*)"data/TEXTURE/health.png");


	if (pTitlecount->modechoise = 1)
	{
		switch (pTitlecount->choise)
		{
		case 1:
			g_Player.pos = D3DXVECTOR2(400.0f, 1800.0f);
			break;
		case 2:
			g_Player.pos = D3DXVECTOR2(400.0f, 300.0f);
			break;
		case 3:
			g_Player.pos = D3DXVECTOR2(200.0f, 200.0f);
			break;
		case 4:
			g_Player.pos = D3DXVECTOR2(200.0f, 600.0f);
			break;
		case 5:
			g_Player.pos = D3DXVECTOR2(300.0f, 850.0f);
			break;
		case 6:
			g_Player.pos = D3DXVECTOR2(400.0f, 1100.0f);
			break;
		}
	}

	//�f�[�^�̏�����
	g_Player.vel = D3DXVECTOR2(0.0f, 0.0f);
	g_Player.muki = 0;
	g_Player.animePtn = 0;
	g_Player.animeCounter = 0;
	g_Player.animecont = 0;
	g_Player.fieldstand = false;
	g_Player.HP = 3;

	color = 1.0f;
	cooltime = 0;

	return S_OK;
}

//=============================================================================
// �I������
//=============================================================================
void UninitPlayer(void)
{
	

}
//=============================================================================
// �X�V����
//=============================================================================
void UpdatePlayer(void)
{
	CAMERA_2D* pCamera = GetCamera();
	WEAPON* pweapon = Getweapon();

	if (GetThumbLeftXPressed(0, -0.9f) && g_Bird.actstyle == false && g_Player.aimmode == false ) //DIK_A
	{
		if (g_Player.pos.x <= 50.0f)
		{
			if (g_Player.moveinpulse <= 0.0f)
			{
				g_Player.moveinpulse = 0.0f;
			}

		}
		else
		{
			if (g_Player.moveinpulse >= -10.0f && g_Player.wallhitright == false)
			{
				if (g_Player.icework == true)
				{
					g_Player.moveinpulse -= 0.2f;
				}
				else
				{
					g_Player.moveinpulse -= 2.0f;
				}
			}

		}
		g_Player.animemove = 5;
		g_Player.muki = 0;
		if (g_Player.wallhitleft == true)
		{
			g_Player.wallhitleft = false;
		}
	}
	else if (GetThumbLeftXPressed(0, 0.9f) && g_Bird.actstyle == false && g_Player.aimmode == false) //DIK_D
	{
			if (g_Player.moveinpulse <= 10.0f && g_Player.wallhitleft == false)
			{
				if (g_Player.icework == true)
				{
					g_Player.moveinpulse += 0.2f;
				}
				else
				{
					g_Player.moveinpulse += 2.0f;
				}
			}
			g_Player.animemove = 2;
			g_Player.muki = 1;
		if (g_Player.wallhitright == true)
		{
			g_Player.wallhitright = false;
		}
	}

	g_Player.pos.x += g_Player.moveinpulse;


	if (GetThumbLeftXPressed(0, 0.9f) || GetThumbLeftXPressed(0, -0.9f)) //DIK_A DIK_D
	{

    }
	else
	{

		if (g_Player.animemove == 5)
		{
			g_Player.animemove = 3;
		}
		if (g_Player.animemove == 2)
		{
			g_Player.animemove = 0;
		}
		if (g_Player.icework == true)
		{
			if (g_Player.moveinpulse > 0.0f || g_Player.moveinpulse < 0.0f)
			{
				g_Player.moveinpulse = g_Player.moveinpulse * 0.955f;
			}
		}
		else
		{
			if (g_Player.moveinpulse <= 1.0f && g_Player.moveinpulse >= -1.0f)
			{
				g_Player.moveinpulse = 0.0f;
			}
			if (g_Player.moveinpulse >= 0.0f)
			{
				g_Player.moveinpulse -= 1.0f;
			}
			if (g_Player.moveinpulse <= 0.0f)
			{
				g_Player.moveinpulse += 1.0f;
			}
		}
	}
	//�X�y�[�X�������Ƃ�
	if (IsButtonTriggered(0, XINPUT_GAMEPAD_A) && g_Player.jumpFlag == false && g_Bird.actstyle == false && g_Player.aimmode == false) //DIK_SPACE
	{
		g_Player.jumpPower = 14.0f;
		g_Player.jumpFlag = true;
	}
	//��񂾎�
	if (g_Player.jumpFlag == true)
	{
		g_Player.pos.y -= g_Player.jumpPower;
		if (g_Player.jumpPower >= 0)
		{
			g_Player.jumpPower -= 0.5f;
		}
	}
	//�t�B�[���h��Ȃ�
		g_Player.pos.y += g_Player.gravityscale;
		if (g_Player.gravityscale <= 30.0f)
		{
			g_Player.gravityscale += 0.5f;
		}

		if (g_Player.hit == true)
		{
			g_Player.HP -= 1;
			g_Player.hit = false;
		}

		if (g_Player.hitcool >= 0)
		{
			if (color > 1)
			{
				color = 0;
			}
			color += 0.05f;
			g_Player.hitcool -= 1;
		}
		else
		{
			color = 1;
		}
		
		if (g_Player.HP <= 0)
		{
			SetScene(SCENE_FAILED);
		}




		//�A�j���[�V�����֘A
	//�A�j���[�V�����J�E���^�[���J�E���g�A�b�v���āA�E�G�C�g�l�𒴂�����
	if (g_Player.animeCounter > 3)
	{

		//�Ō�̃A�j���[�V�����p�^�[����\�������烊�Z�b�g����
		if (g_Player.animemove == 0 || g_Player.animemove == 3)
		{
			if (g_Player.animePtn >= 6)
			{
				g_Player.animePtn = 0;
				g_Player.animemove++;

			}
		}
		if (g_Player.animemove == 1 || g_Player.animemove == 4)
		{
			if (g_Player.animePtn >= 6)
			{
				g_Player.animePtn = 0;
				g_Player.animemove--;

			}
		}
		if (g_Player.animemove == 2 || g_Player.animemove == 5)
		{
			if (g_Player.animePtn >= 5)
			{
				g_Player.animePtn = 0;

			}
		}


		//�A�j���[�V�����p�^�[����؂�ւ���
		g_Player.animePtn++;
		//�A�j���[�V�����J�E���^�[�̃��Z�b�g
		g_Player.animeCounter = 0;
	}
	g_Player.animeCounter++;




	////////////////////////////////////

	//���̏���

	if (IsButtonPressed(0, XINPUT_GAMEPAD_Y))
	{
		g_Bird.actstyle = true;
	}
	else
	{
		g_Bird.actstyle = false;
	}


	if (g_Bird.actstyle == true)
	{
		if (GetThumbLeftXPressed(0, -0.6f) && g_Player.pos.x - 1200.0f < g_Bird.pos.x) //DIK_A
		{
			g_Bird.pos.x -= 10.0f;
			g_Bird.muki = 0;
		}

		if (GetThumbLeftXPressed(0, 0.6f) && g_Player.pos.x + 1200.0f > g_Bird.pos.x) //DIK_D
		{
			g_Bird.pos.x += 10.0f;
			g_Bird.muki = 1;
		}

		if (GetThumbLeftYPressed(0, 0.6f) && g_Player.pos.y - 1200.0f < g_Bird.pos.y) //DIK_W
		{
			g_Bird.pos.y -= 10.0f;
		}
		if (GetThumbLeftYPressed(0, -0.6f) && g_Player.pos.y + 1200.0f > g_Bird.pos.y) //DIK_S
		{
			g_Bird.pos.y += 10.0f;
		}
	}
	else
	{
		g_Bird.pos.y -=( g_Bird.pos.y - (g_Player.pos.y - 28.0f)) * 0.1f;
		g_Bird.pos.x -=( g_Bird.pos.x - (g_Player.pos.x - 80.0f)) * 0.1f;
		g_Bird.muki = g_Player.muki;
	}


		if (g_Bird.count >= 8)
		{
			if (g_Bird.animecount < 4)
			{
				g_Bird.animecount += 1;
			}
			else
			{
				g_Bird.animecount = 1;
			}
			g_Bird.count = 0;
		}
		g_Bird.count++;
		
		//////////////////////////////////////


	//�J�����R���g���[��

	D3DXVECTOR2 basePos = GetBase();
	//�J�����n��

	if (g_Bird.actstyle == false)
	{
		pCamera->pos.x = g_Player.pos.x - PLAYER_DISP_X;
		pCamera->pos.y = g_Player.pos.y - PLAYER_DISP_Y;

	}
	if (g_Bird.actstyle == true)
	{
		pCamera->pos.x = g_Bird.pos.x - PLAYER_DISP_X;
		pCamera->pos.y = g_Bird.pos.y - PLAYER_DISP_Y;

	}
}


//=============================================================================
// �`�揈��
//=============================================================================
void DrawPlayer(void)
{
	//�x�[�X���W���󂯎��
	D3DXVECTOR2 basePos = GetBase();


	//�L�����N�^�[�̕`��
	DrawSpriteColorRotate(g_TexturePlayer,
		basePos.x + g_Player.pos.x,
		basePos.y + g_Player.pos.y,
		172.0f, 172.0f,
		g_WidthTable[g_Player.animePtn],
		g_HeightTable[g_Player.animemove],
		PATTERN_WIDTH,
		PATTERN_HEIGHT,
		D3DXCOLOR(1.0f, 1.0f, 1.0f, color),
		0.0f);

	//���̕`��
	DrawSpriteColorRotate(g_TextureBird,
		basePos.x + g_Bird.pos.x,
		basePos.y + g_Bird.pos.y,
		64.0f, 64.0f,
		g_Birdmove[g_Bird.animecount],
		g_Bird.muki * 0.5f,
		0.25f,
		0.5f,
		D3DXCOLOR(1.0f, 1.0f, 1.0f, color),
		0.0f);

}

void Drawhealth()
{
	for (int i = 0; i < g_Player.HP; i++)
	{
		DrawSprite(g_TextureHP, 80.0f + (80.0f * i), 80.0f, 80.0f, 80.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
}


PLAYER* GetPlayer(void)
{
	return &g_Player;
}

PLAYERBIRD* GetBird(void)
{
	return &g_Bird;
}