#pragma once


#include "main.h"
#include "renderer.h"

struct ITEMSTACK
{
	int gun;
	int staff;
	int chain;

	int choise;
	int stack;
	float wheel;
	float arrotate;

	int particlecount;
	int cell;
};


struct ITEMSTACKPARTICLE
{
	D3DXVECTOR2 pos;

	int useframe;

	bool use;


};


void InitItem(void);
void UpdateItem(void);
void DrawItem(void);

ITEMSTACK* GetItemStack(void);


void Switchgun(void);

void Switchchain(void);

void Switchlance(void);