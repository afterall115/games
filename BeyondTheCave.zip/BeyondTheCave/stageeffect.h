#pragma once


#include "main.h"
#include "renderer.h"

struct STAGEEFFECT
{
	D3DXVECTOR2 pillerpos1;
	D3DXVECTOR2 pillerpos2;
	D3DXVECTOR2 pillerpos3;

	D3DXVECTOR2 particlepos;
	D3DXVECTOR2 particlerand;
};


void Initstageeffect(void);
void Uninitstageeffect(void);
void Updatestageeffect(void);
void Drawstageeffect(void);