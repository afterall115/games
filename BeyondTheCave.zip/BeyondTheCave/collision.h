#pragma once

#include "main.h"

bool HitCheckBox(D3DXVECTOR2 box1pos, float box1width, float box1height,
	D3DXVECTOR2 box2pos, float box2width, float box2height);

bool HitCheck(D3DXVECTOR2 box1pos, int box1width, int box1height,
	D3DXVECTOR2 box2pos, int box2width, int box2height);