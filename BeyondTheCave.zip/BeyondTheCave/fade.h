#pragma once

#include "main.h"
#include "renderer.h"


struct FADE
{
	float ypos;
	float fademove;
};

struct FADECENTER
{
	bool fadeON;
	bool fadeOFF;
	float colorfade;

};


void Initfade();
void Uninitfade();
void Updatefade();
void Drawfade();

void Setfadeout();
void Setfadein();

bool fadeoutOK();


FADE* Getfade();
FADECENTER* Getfadec();