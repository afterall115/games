#pragma once

#include "main.h"
#include "renderer.h"

struct HEAL
{
	D3DXVECTOR2 pos;

	bool use;
	int usecount;

	bool fall;
	float ymove;
};

void Initheal(void);
void Uninitheal(void);
void Updateheal(void);
void Drawheal(void);

HEAL* Getheal(void);