#pragma once


#include "main.h"
#include "renderer.h"
#include "map.h"


struct STONE
{
	D3DXVECTOR2 pos;

	int mesh[MAX_YMAP][MAX_XMAP];
	bool use;
	int spotcount;
	bool stonesound;

	int usecount;
};


void InitStone(void);
void UninitStone(void);
void UpdateStone(void);
void DrawStone(void);

STONE* GetStone(void);