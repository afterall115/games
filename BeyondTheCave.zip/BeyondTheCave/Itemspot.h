#pragma once


#include "main.h"
#include "renderer.h"
#include "map.h"

struct ITEMSPOT
{
	D3DXVECTOR2 pos;

	int mesh[MAX_YMAP][MAX_XMAP];
	int spotcount;

	float ymove;

	bool fall;

	int animcount;
	int animcool;
};

struct ITEMSPOTWIND
{
	D3DXVECTOR2 pos;

	bool use;
	int repopcool;
	int usecount;
};
struct ITEMSPOTHOOK
{
	D3DXVECTOR2 pos;

	bool use;
	int repopcool;
	int usecount;
};

struct ITEMSPOTFIRE
{
	D3DXVECTOR2 pos;

	bool use;
	int repopcool;
	int usecount;
};

void InitItemspot(void);
void UninitItemspot(void);
void UpdateItemspot(void);
void DrawItemspot(void);

ITEMSPOTWIND* GetSpotwind(void);
ITEMSPOTHOOK* GetSpotHook(void);
ITEMSPOTFIRE* GetSpotfire(void);

