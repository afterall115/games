#pragma once

#include "main.h"
#include "renderer.h"


struct RESULT
{
	int times;
	int timem;
	int timems;
	int time;

	int rank;

	int uitime;

	int choise;

	bool resultfinish;
};

struct RESULTEFFECT
{
	D3DXVECTOR2 pos;

	float color;
};



void InitResult(void);
void UninitResult(void);
void UpdateResult(void);
void DrawResult(void);