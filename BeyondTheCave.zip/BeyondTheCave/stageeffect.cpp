#include "player.h"
#include "camera.h"
#include "texture.h"
#include "sprite.h"
#include "map.h"
#include "stageeffect.h"
#include "map.h"
#include "Title.h"

static int g_TextureBG = 0;
static int g_TexturefullBG = 0;
static int g_Textureblack = 0;
static int g_Textureblue = 0;
static int g_Texturedart = 0;

static STAGEEFFECT g_stageeffect[50];

void Initstageeffect()
{
	g_TextureBG = LoadTexture((char*)"data/TEXTURE/BG.png");
	g_TexturefullBG = LoadTexture((char*)"data/TEXTURE/fullBG.png");
	g_Textureblack = LoadTexture((char*)"data/TEXTURE/layer.png");
	g_Textureblue = LoadTexture((char*)"data/TEXTURE/layer2.png");
	g_Texturedart = LoadTexture((char*)"data/TEXTURE/dartparticle.png");

	for (int i = 0; i < 50; i++)
	{
		g_stageeffect[i].pillerpos1.y = 540.0f;
		g_stageeffect[i].pillerpos2.y = 540.0f;
		g_stageeffect[i].pillerpos3.y = 540.0f;
		g_stageeffect[i].particlepos.x = frand() * 1920.0f;
		g_stageeffect[i].particlepos.y = frand() * 1080.0f;
	}




}
void Uninitstageeffect()
{

}
void Updatestageeffect()
{
	D3DXVECTOR2 basePos = GetBase();
	for (int i = 0; i < 50; i++)
	{
		g_stageeffect[i].pillerpos1.x = (basePos.x * 1.1f) + (2140.0f * i);
		g_stageeffect[i].pillerpos2.x = (basePos.x * 0.5f) + (1660.0f * i);
		g_stageeffect[i].pillerpos3.x = (basePos.x * 0.2f)+ (1100.0f * i);
		if (g_stageeffect[i].particlerand.x >= 3.0f)
		{
			g_stageeffect[i].particlerand.x -= 2.0f;
		}
		if (g_stageeffect[i].particlerand.x <= -3.0f)
		{
			g_stageeffect[i].particlerand.x += 2.0f;
		}
		g_stageeffect[i].particlerand.x += (frand() * 1.0f)  - (frand() * 1.0f);
		g_stageeffect[i].particlerand.y = frand() * 4.0f;

		g_stageeffect[i].particlepos.x += g_stageeffect[i].particlerand.x;
		g_stageeffect[i].particlepos.y += g_stageeffect[i].particlerand.y;

		if (g_stageeffect[i].particlepos.x >= 1920.0f)
		{
			g_stageeffect[i].particlepos.x = 0.0f;
		}
		if (g_stageeffect[i].particlepos.x <= -40.0f)
		{
			g_stageeffect[i].particlepos.x = 1920.0f;
		}
		if (g_stageeffect[i].particlepos.y >= 1220.0f)
		{
			g_stageeffect[i].particlepos.y = 0.0f;
		}


	}

}
void Drawstageeffect()
{
	D3DXVECTOR2 basePos = GetBase();
	TITLECOUNT* pTitlecount = GetTitlecount();

	for (int i = 0; i < 50; i++)
	{
		DrawSprite(g_TextureBG, g_stageeffect[i].pillerpos3.x, g_stageeffect[i].pillerpos3.y, 600.0f, 1280.0f, 0.6666667f, 0.0f, 0.33333f, 1.0f);
	}
	for (int i = 0; i < 50; i++)
	{
		DrawSprite(g_TextureBG, g_stageeffect[i].pillerpos2.x, g_stageeffect[i].pillerpos2.y, 400.0f, 1600.0f, 0.3333333f, 0.0f, 0.33333f, 1.0f);

	}
	for (int i = 0; i < 50; i++)
	{
		DrawSprite(g_TextureBG, g_stageeffect[i].pillerpos1.x, g_stageeffect[i].pillerpos1.y, 600.0f, 1800.0f, 0.0f, 0.0f, 0.33333f, 1.0f);

	}
	for (int i = 0; i < 5; i++)
	{
			DrawSprite(g_TexturefullBG, (basePos.x * 0.4f) + (960.0f + (1920.0f * i)), 540.0f, 1920.0f,1080.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	for (int i = 0; i < 40; i++)
	{
		DrawSprite(g_Texturedart, g_stageeffect[i].particlepos.x, g_stageeffect[i].particlepos.y, 10.0f, 10.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	if (pTitlecount->choise == 4 || pTitlecount->choise == 5)
	{
		DrawSprite(g_Textureblue, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
	else
	{
		DrawSprite(g_Textureblack, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
}