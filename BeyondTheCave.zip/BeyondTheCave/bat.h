#pragma once

#include "main.h"
#include "renderer.h"

struct BAT
{
	D3DXVECTOR2 pos;

	float yimpulse;
	int usecount;
	bool use;
	bool windowhit;

	int animmode;
};

struct BATANIM
{
	int animcount;
	int animcool;
};

void Initbat(void);
void Uninitbat(void);
void Updatebat(void);
void Drawbat(void);

BAT* Getbat(void);