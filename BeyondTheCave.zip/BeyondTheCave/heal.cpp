#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "weapon.h"
#include "map.h"
#include "heal.h"

struct HEAL g_heal[100];

static int g_Textureheal;

void Initheal(void)
{
	g_Textureheal = LoadTexture((char*)"data/TEXTURE/heal.png");

	for (int i = 0; i < 100; i++)
	{
		g_heal[i].use = true;
		g_heal[i].fall = false;
	}
}

void Uninitheal(void)
{

}
void Updateheal(void)
{
	PLAYER* pPlayer = GetPlayer();


	for (int i = 0; i < g_heal[1].usecount; i++)
	{
		if (g_heal[i].use == true)
		{

			if (g_heal[i].fall == true)
			{
				g_heal[i].ymove -= 0.01f;
			}
			if (g_heal[i].fall == false)
			{
				g_heal[i].ymove += 0.01f;
			}

			if (g_heal[i].ymove >= 0.5f)
			{
				g_heal[i].fall = true;
			}
			if (g_heal[i].ymove <= -0.5f)
			{
				g_heal[i].fall = false;
			}

			if (HitCheckBox(g_heal[i].pos, 64.0f, 64.0f, pPlayer->pos, 88.0f, 170.0f))
			{
				g_heal[i].use = false;
				if (pPlayer->HP < 3)
				{
					pPlayer->HP++;
				}
			}
		}
		g_heal[i].pos.y += g_heal[i].ymove;
	}
}
void Drawheal(void)
{
	PLAYER* pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();

	for (int i = 0; i < g_heal[1].usecount; i++)
	{
		if (g_heal[i].use == true)
		{
			DrawSprite(g_Textureheal, basePos.x + g_heal[i].pos.x, basePos.y + g_heal[i].pos.y, 64.0f, 64.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
}

HEAL* Getheal(void)
{
	return &g_heal[0];
}