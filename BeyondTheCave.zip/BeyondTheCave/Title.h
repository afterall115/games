#pragma once

#include "main.h"
#include "renderer.h"
#include "inputx.h"


#define STAGE_NUMBER 6

struct TITLE
{

	D3DXVECTOR2 pos;
	D3DXVECTOR2 purpos;
	int stages;

	D3DXVECTOR2 UIcontroll;

};
struct TITLECOUNT
{
	int choise;
	float fade;
	int modechoise;

	bool stagechoise;

	float titlecolor;

	bool titlecolorcon;

	int particlecount;

	bool config;

	bool start;
};

struct MODEUI
{
	D3DXVECTOR2 pos;
	D3DXVECTOR2 purpos;

};

struct TITLEEFFECT
{
	D3DXVECTOR2 pos;
	float size;

	float xrand;
	bool use;
};

void InitTitle(void);
void UninitTitle(void);
void UpdateTitle(void);
void DrawTitle(void);

TITLECOUNT* GetTitlecount(void);