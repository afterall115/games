#include "Fieldcollision.h"
#include "player.h"
#include "hitcheck.h"
#include "collision.h"


void CheckHitSomething(D3DXVECTOR2 mappos , float width , float height)
{
	PLAYER* pPlayer = GetPlayer();

	if (HitCheckBox(pPlayer->pos, 128.0f, 128.0f, mappos, width, height))
	{
		if (HitCheckField(pPlayer->pos, 128.0f, 128.0f, mappos, width, height))
		{
			pPlayer->pos.y = mappos.y - (height/2) - 64.0f;
			pPlayer->gravityscale = 0.0f;
		}
			if (HitCheckwallleft(pPlayer->pos, 128.0f, 128.0f, mappos, width, height))
			{
				pPlayer->wallhitright = true;
			}
			if (HitCheckwallright(pPlayer->pos, 128.0f, 128.0f, mappos, width, height))
			{
				pPlayer->wallhitleft = true;
			}
			if (HitCheckCelling(pPlayer->pos, 128.0f, 128.0f, mappos, width, height))
			{
				pPlayer->jumpPower = 0.0f;
			}
	}


}