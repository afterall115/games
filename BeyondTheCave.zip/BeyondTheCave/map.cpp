/*==============================================================================

   ���_�Ǘ� [bg.cpp]
														 Author :
														 Date   :
--------------------------------------------------------------------------------

==============================================================================*/
#include "map.h"
#include "camera.h"
#include "collision.h"
#include "Fieldcollision.h"
#include "player.h"
#include "sprite.h"
#include "texture.h"
#include "Itemspot.h"
#include "inputx.h"
#include "toge.h"
#include "weapon.h"
#include "Title.h"
#include "breakstone.h"
#include "icebox.h"
#include "sound.h"
#include "fade.h"
#include "Goal.h"
#include "bat.h"
#include "icespike.h"
#include "heal.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************

#define DIVIDE_X 10	//���̕�����
#define DIVIDE_Y 1	//�c�̕�����

#define PATTERN_WIDTH (1.0f / DIVIDE_X)
#define PATTERN_HEIGHT (1.0f / DIVIDE_Y)


//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
static int   g_TextureName = 0;

static int titlename = 0;
FILE  *fpMapdate00;

static int g_BGMgame;


//static MAP  g_Mesh[MAX_MAPNUMBER];

static MAP  g_Mesh;
static TIME  g_time;

static float g_MapBaseType[10] = {
	0.0f,	//�n�㍶
	0.1f,	//�n�㒆��
	0.2f,	//�n��E
	0.3f,	//�n����
	0.4f,	//�n������
	0.5f,	//�n���E
	0.6f,	
	0.7f,
	0.8f,
	0.9f,
};


//=============================================================================
// ����������
//=============================================================================
void InitBG(void)
{
	D3DXVECTOR2 basePos = GetBase();
	ITEMSPOTWIND* pItemspotwind = GetSpotwind();
	ITEMSPOTHOOK* pItemspothook = GetSpotHook();
	ITEMSPOTFIRE* pItemspotfire = GetSpotfire();
	TITLECOUNT* pTitlecount = GetTitlecount();
	THORN* pThorn = GetThorn();
	STONE*pstone = GetStone();
	ICEBOX* picebox = Getice();
	GOAL* pgoal = GetGoal();
	BAT* pbat = Getbat();
	HEAL* pheal = Getheal();
	ICESPIKE* pspike = Geticespike();

	const char* fname = 0;
	
	for (int y = 0; y < MAX_YMAP; y++)
	{
		for (int x = 0; x < MAX_XMAP; x++)
		{
			g_Mesh.mesh[y][x] = NULL;
		}
	}

	pItemspotwind[1].usecount = 0;
	pItemspothook[1].usecount = 0;
	pItemspotfire[1].usecount = 0;
	pThorn[1].usecount = 0;
	pstone[1].usecount = 0;
	picebox[1].usecount = 0;
	pbat[1].usecount = 0;
	pheal[1].usecount = 0;
	pspike[1].usecount = 0;

	g_time.time = 0;


	if (pTitlecount->modechoise = 1)
	{
		switch (pTitlecount->choise)
		{
		case 1:
			fname = NULL;
			fname = "data/mapdata/map01.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-1.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field.png");
			break;
		case 2:
			fname = NULL;
			fname = "data/mapdata/map02.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-2.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field.png");
			break;
		case 3:
			fname = NULL;
			fname = "data/mapdata/map03.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-3.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field.png");
			break;
		case 4:
			fname = NULL;
			fname = "data/mapdata/map04.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-4.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field02.png");
			break;
		case 5:
			fname = NULL;
			fname = "data/mapdata/map05.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-5.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field02.png");
			break;
		case 6:
			fname = NULL;
			fname = "data/mapdata/practicemap.txt";
			g_BGMgame = LoadSound((char*)"data/BGM/1-1.wav");
			g_TextureName = LoadTexture((char*)"data/TEXTURE/field.png");
			break;
		}
	}

	Setfadein();
	PlaySound(g_BGMgame, -1);

		//char	buf[20][50];

		int		col = 0;
		int		row = 0;
		fpMapdate00 = fopen(fname, "r");
		if (fpMapdate00 != NULL)
		{
			//g_Mesh[i].use = true;

			while (!feof(fpMapdate00))
			{
				char ch;
				ch = fgetc(fpMapdate00);
				if (ch == -1)
					break;
				if (ch == '\n')
				{
					row++;
					col = 0;
				}
				else if (ch != ',')
				{
					g_Mesh.mesh[row][col++] = atoi(&ch);/////////////////////////////////////ASCIIintonumber

				}
				//memcpy
			}
			//fscanf(fpMapdate00, "%s", buf);
			fclose(fpMapdate00);
			//	g_Mesh[0]= row
		}
		else {
			printf("txtlosed\n");
		}


		for (int y = 0; y < MAX_YMAP; y++)
		{
			for (int x = 0; x < MAX_XMAP; x++)
			{
				switch (g_Mesh.mesh[y][x])
				{
				case 0:

					break;

				case 1:
					g_Mesh.collipos[y][x].x = 64.0f * x;
					g_Mesh.collipos[y][x].y = 64.0f * y;
					break;

					//�A�C�e���X�|�b�g��
				case 2:
					pItemspotwind[pItemspotwind[1].usecount].pos.x = 64.0f * x;
					pItemspotwind[pItemspotwind[1].usecount].pos.y = 64.0f * y;

					pItemspotwind[1].usecount++;
					break;
					//�A�C�e���X�|�b�g�t�b�N
				case 3:
					pItemspothook[pItemspothook[1].usecount].pos.x = 64.0f * x;
					pItemspothook[pItemspothook[1].usecount].pos.y = 64.0f * y;

					pItemspothook[1].usecount++;
					break;
					//�A�C�e���X�|�b�g�}�b�`
				case 4:
					pItemspotfire[pItemspotfire[1].usecount].pos.x = 64.0f * x;
					pItemspotfire[pItemspotfire[1].usecount].pos.y = 64.0f * y;

					pItemspotfire[1].usecount++;
					break;
					//�Ƃ��M�~�b�N
				case 5:
					g_Mesh.collipos[y][x].x = 64.0f * x;
					g_Mesh.collipos[y][x].y = 64.0f * y;
					pThorn[pThorn[1].usecount].pos.x = 64.0f * x;
					pThorn[pThorn[1].usecount].pos.y = 64.0f * y;
					if (g_Mesh.mesh[y - 1][x] == 1)
					{
						pThorn[pThorn[1].usecount].muki = 2;
					}
					else if (g_Mesh.mesh[y][x + 1] == 1)
					{
						pThorn[pThorn[1].usecount].muki = 3;
					}
					else if (g_Mesh.mesh[y][x - 1] == 1)
					{
						pThorn[pThorn[1].usecount].muki = 1;
					}
					if (g_Mesh.mesh[y + 1][x] == 1)
					{
						pThorn[pThorn[1].usecount].muki = 0;
					}
					pThorn[1].usecount++;
					break;
					//�X�̏�
				case 6:
					g_Mesh.collipos[y][x].x = 64.0f * x;
					g_Mesh.collipos[y][x].y = 64.0f * y;
					picebox[picebox[1].usecount].pos.x = 64.0f * x;
					picebox[picebox[1].usecount].pos.y = 64.0f * y;
					picebox[1].usecount++;
					break;
					//�S�[��
				case 7:
					//���
					pspike[pspike[1].usecount].pos.x = 64.0f * x;
					pspike[pspike[1].usecount].pos.y = 32.0f + (64.0f * y);
					pspike[1].usecount++;
					break;
					//�R�E����
				case 8:
					pbat[pbat[1].usecount].pos.x = 64.0f * x;
					pbat[pbat[1].usecount].pos.y = 14.0f + (64.0f * y);
					pbat[1].usecount++;
					break;
					//�q�[���A�C�e��
				case 9:
					pheal[pheal[1].usecount].pos.x = 64.0f * x;
					pheal[pheal[1].usecount].pos.y = 64.0f * y;
					pheal[1].usecount++;
					break;
				}
			}
		}
}

//=============================================================================
// �I������
//=============================================================================
void UninitBG(void)
{
	StopSound(g_BGMgame);
}

//=============================================================================
// �X�V����
//=============================================================================
void UpdateBG(void)
{

	D3DXVECTOR2 basePos = GetBase();
	PLAYER* pPlayer = GetPlayer();
	PLAYERBIRD* pBird = GetBird();
	WEAPON* pweapon = Getweapon();


	MAP*  pMesh = GetMap();
	

	g_time.time++;

	for (int y = 0; y < MAX_YMAP; y++)
	{
		for (int x = 0; x < MAX_XMAP; x++)
		{
			if (g_Mesh.mesh[y][x] == 1 || g_Mesh.mesh[y][x] == 5)
			{//���̓����蔻��
				if (IsButtonPressed(0, XINPUT_GAMEPAD_Y))
				{
					if (HitCheckBox(pBird->pos, 60.0f, 60.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						if (HitCheckField(pBird->pos, 52.0f, 52.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
						{
							pBird->pos.y = g_Mesh.collipos[y][x].y - 58.0f;
						}
						if (HitCheckwallleft(pBird->pos, 52.0f, 52.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
						{
							pBird->pos.x = g_Mesh.collipos[y][x].x + 58.0f;
						}
						if (HitCheckwallright(pBird->pos, 52.0f, 52.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
						{
							pBird->pos.x = g_Mesh.collipos[y][x].x - 58.0f;

						}
						if (HitCheckCelling(pBird->pos, 52.0f, 52.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
						{
							pBird->pos.y = g_Mesh.collipos[y][x].y + 58.0f;

						}
					}
				}
			}

			if (g_Mesh.mesh[y][x] == 1)
			{
				if (HitCheckBox(pPlayer->pos, 120.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
				{
					if (HitCheckField(pPlayer->pos, 88.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pPlayer->pos.y = g_Mesh.collipos[y][x].y - 112.0f;
						pPlayer->gravityscale = 0.0f;
						pPlayer->jumpFlag = false;
						pPlayer->icework = false;
					}
					if (HitCheckwallleft(pPlayer->pos, 88.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pPlayer->pos.x = g_Mesh.collipos[y][x].x + 76.0f;
						pPlayer->moveinpulse = 0.0f;
					}
					if (HitCheckwallright(pPlayer->pos, 88.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pPlayer->pos.x = g_Mesh.collipos[y][x].x - 76.0f;
						pPlayer->moveinpulse = 0.0f;
					}
					if (HitCheckCelling(pPlayer->pos, 88.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pPlayer->jumpPower = 0.0f;
						pPlayer->pos.y = g_Mesh.collipos[y][x].y + 116.0f;

					}
				}
			}
			if (g_Mesh.mesh[y][x] == 1 || g_Mesh.mesh[y][x] == 5)
			{
				if (HitCheckBox(pweapon->bulletpos, 55.0f, 55.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
				{
					pweapon->gunhit = true;

					if (HitCheckField(pweapon->bulletpos, 50.0f, 50.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pweapon->bulletpos.y = g_Mesh.collipos[y][x].y - 57.0f;
						pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
						pweapon->bulletcount++;
					}
					if (HitCheckwallleft(pweapon->bulletpos, 50.0f, 50.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pweapon->bulletpos.x = g_Mesh.collipos[y][x].x + 57.0f;
						pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;
						pweapon->bulletcount++;

					}
					if (HitCheckwallright(pweapon->bulletpos, 50.0f, 50.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pweapon->bulletpos.x = g_Mesh.collipos[y][x].x - 57.0f;
						pweapon->gunweaponspeedx = pweapon->gunweaponspeedx * -1;
						pweapon->bulletcount++;

					}
					if (HitCheckCelling(pweapon->bulletpos, 50.0f, 50.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
					{
						pweapon->bulletpos.y = g_Mesh.collipos[y][x].y + 57.0f;
						pweapon->gunweaponspeedy = pweapon->gunweaponspeedy * -1;
						pweapon->bulletcount++;
					}
				}

				if (HitCheckBox(pweapon->hooklancepos, 86.0f, 32.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
				{
					pweapon->lancehit = true;
				}

				if (HitCheckBox(pweapon->hookchainpos, 32.0f, 32.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
				{
					if (pweapon->chainhit == false)
					{
						pweapon->chainhit = true;
					}
					if (pweapon->chainhit == true)
					{
						if (HitCheckField(pPlayer->pos, 88.0f, 160.0f, g_Mesh.collipos[y][x], 64.0f, 64.0f))
						{
							pPlayer->gravityscale = 0.0f;

						}
					}
				}
			}
		}
	}
	
}


//=============================================================================
// �`�揈��
//=============================================================================
void DrawBG(void)
{
	
	//�x�[�X���W���󂯎��
	D3DXVECTOR2 basePos = GetBase();
	PLAYER* pPlayer = GetPlayer();

	////�x�[�X���C���[�̕`��
	for (int y = 0; y < MAX_YMAP; y++)
	{
		for (int x = 0; x < MAX_XMAP; x++)
		{
			if (g_Mesh.mesh[y][x] == 1)
			{

				g_Mesh.pos[y][x].y = basePos.y + (64.0f * y);
				g_Mesh.pos[y][x].x = basePos.x + (64.0f * x);
				if (g_Mesh.mesh[y - 1][x] != 1)
				{
					g_Mesh.meshcontroll = 1;
					if (g_Mesh.mesh[y][x - 1] != 1)
					{
						g_Mesh.meshcontroll = 0;
					}
					if (g_Mesh.mesh[y][x + 1] != 1)
					{
						g_Mesh.meshcontroll = 2;
					}
				}
				else if (g_Mesh.mesh[y + 1][x] != 1)
				{
					g_Mesh.meshcontroll = 7;
					if (g_Mesh.mesh[y][x - 1] != 1)
					{
						g_Mesh.meshcontroll = 6;
					}
					if (g_Mesh.mesh[y][x + 1] != 1)
					{
						g_Mesh.meshcontroll = 8;
					}
				}
				else
				{
					g_Mesh.meshcontroll = 4;

					if (g_Mesh.mesh[y][x - 1] != 1)
					{
						g_Mesh.meshcontroll = 3;
					}
					if (g_Mesh.mesh[y][x + 1] != 1)
					{
						g_Mesh.meshcontroll = 5;
					}
				}




				DrawSprite(g_TextureName, basePos.x + g_Mesh.collipos[y][x].x, basePos.y +  g_Mesh.collipos[y][x].y, 64.0f, 64.0f,
					g_MapBaseType[g_Mesh.meshcontroll],
					0.0f,
					PATTERN_WIDTH,
					PATTERN_HEIGHT);
			}
		}
	}
	

}

MAP* GetMap(void)
{
	return &g_Mesh;
}

TIME* Gettime(void)
{
	return &g_time;
}
