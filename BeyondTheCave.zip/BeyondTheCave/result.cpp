#include "Texture.h"
#include "Sprite.h"
#include "goal.h"
#include "player.h"
#include "main.h"
#include "game.h"
#include "Fieldcollision.h"
#include "collision.h"
#include "main.h"
#include "fade.h"
#include "camera.h"
#include "result.h"
#include "map.h"
#include "sound.h"
#include "inputx.h"
#include "title.h"

static int g_Textureresult;
static int g_Textureparticle;
static int g_Texturetime;
static int g_TextureUI;
static int g_TextureUIarrow;
static int g_Texturetimeground;
static int g_Textureten;
static int g_Texturefont;

static int g_resultBGM;
static int g_resultSE;
static int g_uise;

struct RESULT g_result;
struct RESULTEFFECT g_resuleeff[200];


void InitResult()
{
	TIME* ptime = Gettime();


	g_Textureresult = LoadTexture((char*)"data/TEXTURE/fullBG.png");
	g_Textureparticle = LoadTexture((char*)"data/TEXTURE/Goaleffect.png");
	g_Texturetime = LoadTexture((char*)"data/TEXTURE/number.png");
	g_TextureUI = LoadTexture((char*)"data/TEXTURE/UI_00.png");
	g_TextureUIarrow = LoadTexture((char*)"data/TEXTURE/hooklance.png");
	g_Texturetimeground = LoadTexture((char*)"data/TEXTURE/timeground.png");
	g_Texturefont = LoadTexture((char*)"data/TEXTURE/resultui.png");
	g_Textureten = LoadTexture((char*)"data/TEXTURE/ten.png");


	g_resultBGM = LoadSound((char*)"data/BGM/resultbgm.wav");
	g_resultSE = LoadSound((char*)"data/SE/resultse.wav");

	Setfadein();
	PlaySound(g_resultBGM, -1);

	g_result.time = ptime->time;

	g_result.times = g_result.time / 60;
	g_result.timem = g_result.times / 60;
	g_result.timems = g_result.time % 60;
	g_result.times = g_result.timem % 60;

	g_result.uitime = 0;

	g_result.resultfinish = false;

}

void UninitResult()
{

}

void UpdateResult()
{
	TIME* ptime = Gettime();
	TITLECOUNT* ptitle = GetTitlecount();

	g_result.time = ptime->time;

	g_result.times = g_result.time / 60;
	g_result.timem = g_result.times / 60;
	g_result.timems = g_result.time % 60;
	g_result.times %= 60;


	g_result.uitime++;

	if (g_result.uitime == 50 || g_result.uitime == 100 || g_result.uitime == 150)
	{
		PlaySound(g_resultSE, 0);
	}

	if (GetThumbLeftXTriggered(0, -0.9f)) //DIK_A
	{
		if (g_result.choise <= 0)
		{
			g_result.choise = 2;
		}
		else
		{
			g_result.choise--;
		}
	}
	if (GetThumbLeftXTriggered(0, 0.9f)) //DIK_D
	{
		if (g_result.choise >= 2)
		{
			g_result.choise = 0;
		}
		else
		{
			g_result.choise++;
		}
	}

	if (IsButtonTriggered(0, XINPUT_GAMEPAD_B)) //DIK_SPACE
	{
		if (g_result.uitime >= 200)
		{
			Setfadeout();
			g_result.resultfinish = true;
		}
	}

	if (fadeoutOK() && g_result.resultfinish == true)
	{
		if (g_result.choise == 0)
		{
			g_result.resultfinish = false;
			SetScene(SCENE_GAME);
		}
		if (g_result.choise == 1)
		{
			ptitle->choise += 1;
			g_result.resultfinish = false;
			SetScene(SCENE_GAME);
		}
		if (g_result.choise == 2)
		{
			g_result.resultfinish = false;
			SetScene(SCENE_TITLE);
		}
		g_result.resultfinish = false;

	}
}

void DrawResult()
{
	DrawSprite(g_Textureresult, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f);

	DrawSprite(g_Texturetimeground, 700.0f, 350.0f, 1080.0f, 360.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	if (g_result.uitime >= 200)
	{
		DrawSprite(g_TextureUIarrow, 100.0f + (580.0f * g_result.choise), 830.0f, 100.0f, 140.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}

	for (int i = 0; i < 3; i++)
	{
		if (g_result.uitime >= 200)
		{
			DrawSprite(g_TextureUI, 380.0f + (580.0f * i), 830.0f, 500.0f, 140.0f, 0.0f, 0.0f, 1.0f, 1.0f);
			DrawSprite(g_Texturefont, 380.0f + (580.0f * i), 830.0f, 400.0f, 100.0f, 0.0f, 0.333333f * i, 1.0f, 0.333333f);
		}
	}

	for (int i = 0; i < 2; i++)
	{
		if (g_result.uitime >= 150)
		{
			DrawSprite(g_Textureten, 730.0f - (250 * i), 350.0f, 120.0f, 180.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		}

		if (g_result.uitime >= 50)
		{
			int suuzi = g_result.timems % 10;

			DrawSprite(g_Texturetime, 900.0f - (100.0f * i), 350.0f, 120.0f, 180.0f, 0.1f * suuzi, 0.0f, 0.1f, 1.0f);
			g_result.timems /= 10;
		}
		if (g_result.uitime >= 100)
		{

			int suuji = g_result.times % 10;

			DrawSprite(g_Texturetime, 650.0f - (100.0f * i), 350.0f, 120.0f, 180.0f, 0.1f * suuji, 0.0f, 0.1f, 1.0f);

			g_result.times /= 10;

		}
		if (g_result.uitime >= 150)
		{
			int suujii = g_result.timem % 10;

			DrawSprite(g_Texturetime, 400.0f - (100.0f * i), 350.0f, 120.0f, 180.0f, 0.1f * suujii, 0.0f, 0.1f, 1.0f);

			g_result.timem /= 10;
		}
	}
}