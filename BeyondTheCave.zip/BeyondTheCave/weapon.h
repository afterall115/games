#pragma once


#include "main.h"
#include "renderer.h"


struct WEAPON
{
	bool	windgun;
	bool	windchain;
	bool	windlance;
	bool	hookgun;
	bool	hookchain;
	bool	hooklance;
	bool	firegun;
	bool	firechain;
	bool	firelance;

	bool  gunhit;
	bool  lancehit;
	bool  chainhit;
	bool  fireon;
	float chainlong;

	D3DXVECTOR2 bulletpos;
	D3DXVECTOR2 firechainbulletpos;
	D3DXVECTOR2 windlancepos;
	D3DXVECTOR2 hooklancepos;
	D3DXVECTOR2 hookchainpos;
	D3DXVECTOR2 hookchainvel;
	D3DXVECTOR2 bulleteffect;
	D3DXVECTOR2 firelancepos;

	float lanceweaponspeed;
	float chainweaponspeed;
	float gunweaponspeed;
	float gunweaponspeedx;
	float gunweaponspeedy;
	float bulletrotate;
	float impulse;
	float lancegravity;
	float chaingravity;
	float fireparticlefade;

	float hookchainwave;
	float hookgunroapspeed;

	int lancerotate;
	int windchainuseframe;
	int windchainani;
	int windlanceuseframe;
	int hooklanceuseframe;
	int bulletcount;
	int bulleteffectcount;
	int bulleteffectcool;
	int firelancecool;
	int firelanceuseframe;

	int onetimewindgun;
	int onetimehookgun;
	int onetimefiregun;
	int onetimewindchain;
	int onetimehookchain;
	int onetimefirechain;
	int onetimewindlance;
	int onetimehooklance;
	int onetimefirelance;


	int windeffecount;
	int usewindcount;
};

struct WEAPONEFFECT
{
	D3DXVECTOR2 bulleteffect;
	D3DXVECTOR2 chaineffect;
	D3DXVECTOR2 lanceeffect;
	bool use;
	float useframe;

	float randmove;
	int roaprand;

	float gravity;

};

struct WINDEFFECT
{
	D3DXVECTOR2 windeffect;
	D3DXVECTOR2 windrand;
	float windcolor;

	bool use;
};

struct WEAPONROAP
{
	D3DXVECTOR2 pos;
};

void Initweapon(void);
void Uninitweapon(void);
void Updateweapon(void);
void Drawweapon(void);

WEAPON* Getweapon(void);

void windgun(void);
void windchain(void);
void windlance(void);
void hookgun(void);
void hookchain(void);
void hooklance(void);
void firegun(void);
void firechain(void);
void firelance(void);