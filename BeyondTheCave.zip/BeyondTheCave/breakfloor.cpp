
#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "breakfloor.h"

//===================================================

static int   g_TextureFloor = 0;

static BREAKFLOOR g_Breakfloor[10];

static int count = 0;

void InitBreakfloor(void)
{

	g_TextureFloor = LoadTexture((char*)"data/TEXTURE/woodbox.png");

}

void UninitBreakfloor(void)
{

}

void UpdateBreakfloor(void)
{

	PLAYER* pPlayer = GetPlayer();

	for (int x = 0; x < 10; x++)
	{
		if (g_Breakfloor[x].use == true)
		{
			if (HitCheckField(pPlayer->pos, 70.0f, 70.0f, g_Breakfloor[x].pos, 64.0f, 64.0f))
			{
				if (pPlayer->pos.y >= g_Breakfloor[x].pos.y-64.0f)
				{
					count++;

					pPlayer->gravityscale = 0.0f;

					if (count >= 30)
					{
						g_Breakfloor[x].use = false;
						count = 0;
					}
				}
			}
			if (HitCheckwallleft(pPlayer->pos, 64.0f, 64.0f, g_Breakfloor[x].pos, 32.0f, 32.0f))
			{
				pPlayer->pos.x = g_Breakfloor[x].pos.x + 50.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckwallright(pPlayer->pos, 64.0f, 64.0f, g_Breakfloor[x].pos, 32.0f, 32.0f))
			{
				pPlayer->pos.x = g_Breakfloor[x].pos.x - 50.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckCelling(pPlayer->pos, 64.0f, 64.0f, g_Breakfloor[x].pos, 32.0f, 32.0f))
			{
				pPlayer->jumpPower = 0.0f;
				pPlayer->pos.y = g_Breakfloor[x].pos.y + 50.0f;

			}
		}

		if (g_Breakfloor[x].use == false)
		{
			if (g_Breakfloor[x].repopcool >= 300)
			{
				g_Breakfloor[x].use = true;
				g_Breakfloor[x].repopcool = 0;


			}

			g_Breakfloor[x].repopcool += 1;
		}
	}


}

void DrawBreakfloor(void)
{

	D3DXVECTOR2 basePos = GetBase();

	for (int x = 0; x < 10; x++)
	{
		if (g_Breakfloor[x].use == true)
		{
			DrawSprite(g_TextureFloor, basePos.x + g_Breakfloor[x].pos.x, basePos.y + g_Breakfloor[x].pos.y, 64.0f, 64.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
}

BREAKFLOOR* GetBreakFloor(void)
{
	return &g_Breakfloor[0];
		
}
