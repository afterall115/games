#pragma once


#include "main.h"
#include "renderer.h"

struct THORN
{
	D3DXVECTOR2 pos;

	int mesh[MAX_YMAP][MAX_XMAP];
	int spotcount;

	bool use;
	int repopcool;
	int muki;
	int usecount;
};

void InitThorn(void);
void UninitThorn(void);
void UpdateThorn(void);
void DrawThorn(void);


THORN* GetThorn(void);