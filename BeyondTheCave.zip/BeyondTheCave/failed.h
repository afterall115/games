#pragma once

#include "main.h"
#include "renderer.h"

struct FAIL
{
	D3DXVECTOR2 pos;

	int choise;

	int animtime;

	float gravity;
	float uicolor;
	float rotate;
	float fade;

	bool revenge;
};

void Initfail(void);
void Uninitfail(void);
void Updatefail(void);
void Drawfail(void);