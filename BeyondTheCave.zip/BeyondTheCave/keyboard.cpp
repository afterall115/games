//--------------------------------------------------------------------------------------
// File: Keyboard.cpp
//
// �L�[�{�[�h���W���[��
//
//--------------------------------------------------------------------------------------
// 2020/06/07
//     DirectXTK���A�Ȃ񂿂����C����p�ɃV�F�C�v�A�b�v����
//
// Licensed under the MIT License.
//
// http://go.microsoft.com/fwlink/?LinkId=248929
// http://go.microsoft.com/fwlink/?LinkID=615561
//--------------------------------------------------------------------------------------
#include "keyboard.h"

#include <assert.h>


static_assert(sizeof(Keyboard_State) == 256 / 8, "�L�[�{�[�h��ԍ\���̂̃T�C�Y�s��v");


static Keyboard_State gState = {};


static void keyDown(int key)
{
    if (key < 0 || key > 0xfe) { return;  }

    unsigned int* p = (unsigned int*)&gState;
    unsigned int bf = 1u << (key & 0x1f);
    p[(key >> 5)] |= bf;
}


static void keyUp(int key)
{
    if (key < 0 || key > 0xfe) { return; }

    unsigned int* p = (unsigned int*)&gState;
    unsigned int bf = 1u << (key & 0x1f);
    p[(key >> 5)] &= ~bf;
}


void Keyboard_Initialize(void)
{
    Keyboard_Reset();
}


bool Keyboard_IsKeyDown(Keyboard_Keys key, const Keyboard_State* pState)
{
    if (key <= 0xfe)
    {
        unsigned int* p = (unsigned int*)pState;
        unsigned int bf = 1u << (key & 0x1f);
        return (p[(key >> 5)] & bf) != 0;
    }
    return false;
}


bool Keyboard_IsKeyUp(Keyboard_Keys key, const Keyboard_State* pState)
{
    if (key <= 0xfe)
    {
        unsigned int* p = (unsigned int*)pState;
        unsigned int bf = 1u << (key & 0x1f);
        return (p[(key >> 5)] & bf) == 0;
    }
    return false;
}


bool Keyboard_IsKeyDown(Keyboard_Keys key)
{
    return Keyboard_IsKeyDown(key, &gState);
}


bool Keyboard_IsKeyUp(Keyboard_Keys key)
{
    return Keyboard_IsKeyUp(key, &gState);
}


// �L�[�{�[�h�̌��݂̏�Ԃ��擾����
const Keyboard_State* Keyboard_GetState(void)
{
    return &gState;
}


void Keyboard_Reset(void)
{
    ZeroMemory(&gState, sizeof(Keyboard_State));
}


// �L�[�{�[�h����̂��߂̃E�H���ǂ����b�Z�[�W�v���V�[�W���t�b�N�֐�
void Keyboard_ProcessMessage(UINT message, WPARAM wParam, LPARAM lParam)
{
    bool down = false;

    switch (message)
    {
    case WM_ACTIVATEAPP:
        Keyboard_Reset();
        return;

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        down = true;
        break;

    case WM_KEYUP:
    case WM_SYSKEYUP:
        break;

    default:
        return;
    }

    int vk = (int)wParam;
    switch (vk)
    {
    case VK_SHIFT:
        vk = (int)MapVirtualKey(((unsigned int)lParam & 0x00ff0000) >> 16u, MAPVK_VSC_TO_VK_EX);
        if (!down)
        {
            // ���V�t�g�ƉE�V�t�g�̗����������ɉ����ꂽ�ꍇ�ɃN���A�����悤�ɂ��邽�߂̉����
            keyUp(VK_LSHIFT);
            keyUp(VK_RSHIFT);
        }
        break;

    case VK_CONTROL:
        vk = ((UINT)lParam & 0x01000000) ? VK_RCONTROL : VK_LCONTROL;
        break;

    case VK_MENU:
        vk = ((UINT)lParam & 0x01000000) ? VK_RMENU : VK_LMENU;
        break;
    }

    if (down)
    {
        keyDown(vk);
    }
    else
    {
        keyUp(vk);
    }
}

Keyboard_State* KeyboardStateXOR(const Keyboard_State* State1, const Keyboard_State* State2)
{
	Keyboard_State* work;
	ZeroMemory(&work, sizeof(Keyboard_State));

	work->A = State1->A ^ State2->A;
	work->B = State1->B ^ State2->B;
	work->C = State1->C ^ State2->C;
	work->D = State1->D ^ State2->D;
	work->E = State1->E ^ State2->E;
	work->F = State1->F ^ State2->F;
	work->G = State1->G ^ State2->G;
	work->H = State1->H ^ State2->H;
	work->I = State1->I ^ State2->I;
	work->J = State1->J ^ State2->J;
	work->K = State1->K ^ State2->K;
	work->L = State1->L ^ State2->L;
	work->M = State1->M ^ State2->M;
	work->N = State1->N ^ State2->N;
	work->O = State1->O ^ State2->O;
	work->P = State1->P ^ State2->P;
	work->Q = State1->Q ^ State2->Q;
	work->R = State1->R ^ State2->R;
	work->S = State1->S ^ State2->S;
	work->T = State1->T ^ State2->T;
	work->U = State1->U ^ State2->U;
	work->V = State1->V ^ State2->V;
	work->W = State1->W ^ State2->W;
	work->X = State1->X ^ State2->X;
	work->Y = State1->Y ^ State2->Y;
	work->Z = State1->Z ^ State2->Z;
	work->Enter = State1->Enter ^ State2->Enter;
	work->Escape = State1->Escape ^ State2->Escape;
	work->Space = State1->Space ^ State2->Space;
	work->Left = State1->Left ^ State2->Left;
	work->Up = State1->Up ^ State2->Up;
	work->Right = State1->Right ^ State2->Right;
	work->Down = State1->Down ^ State2->Down;
	work->LeftShift = State1->LeftShift ^ State2->LeftShift;
	work->RightShift = State1->RightShift ^ State2->RightShift;
	work->LeftControl = State1->LeftControl ^ State2->LeftControl;
	work->RightControl = State1->RightControl ^ State2->RightControl;
	work->LeftAlt = State1->LeftAlt ^ State2->LeftAlt;
	work->RightAlt = State1->RightAlt ^ State2->RightAlt;
	work->Back = State1->Back ^ State2->Back;
	work->Tab = State1->Tab ^ State2->Tab;

	return work;
}

Keyboard_State* KeyboardStateAND(const Keyboard_State* State1, const Keyboard_State* State2)
{
	Keyboard_State* work;
	ZeroMemory(&work, sizeof(Keyboard_State));

	work->A = State1->A & State2->A;
	work->B = State1->B & State2->B;
	work->C = State1->C & State2->C;
	work->D = State1->D & State2->D;
	work->E = State1->E & State2->E;
	work->F = State1->F & State2->F;
	work->G = State1->G & State2->G;
	work->H = State1->H & State2->H;
	work->I = State1->I & State2->I;
	work->J = State1->J & State2->J;
	work->K = State1->K & State2->K;
	work->L = State1->L & State2->L;
	work->M = State1->M & State2->M;
	work->N = State1->N & State2->N;
	work->O = State1->O & State2->O;
	work->P = State1->P & State2->P;
	work->Q = State1->Q & State2->Q;
	work->R = State1->R & State2->R;
	work->S = State1->S & State2->S;
	work->T = State1->T & State2->T;
	work->U = State1->U & State2->U;
	work->V = State1->V & State2->V;
	work->W = State1->W & State2->W;
	work->X = State1->X & State2->X;
	work->Y = State1->Y & State2->Y;
	work->Z = State1->Z & State2->Z;
	work->Enter = State1->Enter & State2->Enter;
	work->Escape = State1->Escape & State2->Escape;
	work->Space = State1->Space & State2->Space;
	work->Left = State1->Left & State2->Left;
	work->Up = State1->Up & State2->Up;
	work->Right = State1->Right & State2->Right;
	work->Down = State1->Down & State2->Down;
	work->LeftShift = State1->LeftShift & State2->LeftShift;
	work->RightShift = State1->RightShift & State2->RightShift;
	work->LeftControl = State1->LeftControl & State2->LeftControl;
	work->RightControl = State1->RightControl & State2->RightControl;
	work->LeftAlt = State1->LeftAlt & State2->LeftAlt;
	work->RightAlt = State1->RightAlt & State2->RightAlt;
	work->Back = State1->Back & State2->Back;
	work->Tab = State1->Tab & State2->Tab;

	return work;
}