#pragma once

#include "main.h"
#include "renderer.h"


struct ICESPIKE
{
	D3DXVECTOR2 pos;

	bool act;
	float gravity;

	bool crack;
	bool use;

	int usecount;

	float size;
};

void Initicespike(void);
void Uniniticespike(void);
void Updateicespike(void);
void Drawicespike(void);

ICESPIKE* Geticespike(void);

