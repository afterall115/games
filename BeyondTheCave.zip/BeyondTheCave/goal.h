#pragma once

#include "main.h"
#include "renderer.h"

struct GOAL
{
	D3DXVECTOR2 pos;

	bool playerhit;

	int checkonetime;
	int particlecount;
};

struct GOALEFFECT
{
	D3DXVECTOR2 pos;

	float size;
	bool use;
};


void InitGoal(void);
void UninitGoal(void);
void UpdateGoal(void);
void DrawGoal(void);

GOAL* GetGoal(void);