#pragma once

#include "main.h"
#include "renderer.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************

#define MAX_MAPNUMBER   10

#define MAX_YMAP 500
#define MAX_XMAP 600


struct MAP
{
	D3DXVECTOR2 pos[MAX_YMAP][MAX_XMAP];
	D3DXVECTOR2 collipos[MAX_YMAP][MAX_XMAP];

	int  mesh[MAX_YMAP][MAX_XMAP];
	int actmesh[MAX_YMAP][MAX_XMAP];
	int use[MAX_YMAP][MAX_XMAP];
	int i = 0;

	int meshcontroll;

	//MAP() { for (int y = 0; y < MAX_YMAP; y++) { for (int x = 0; x < MAX_XMAP; x++) { mesh[y][x] = 0; } } }
};

struct TIME
{
	int time;
};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
void InitBG(void);
void UninitBG(void);
void UpdateBG(void);
void DrawBG(void);

MAP* GetMap(void);
TIME* Gettime(void);