

#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "Itemstack.h"
#include "weapon.h"

static int g_Textureweapongun;
static int g_Textureweaponchain;
static int g_Textureweaponlance;
static int g_Textureweaponchoise;
static int g_Textureaim;
static int g_Textureweaponparticle;




//static D3DXVECTOR2 g_Mousepos;

static ITEMSTACK g_Itemstack;
static ITEMSTACKPARTICLE g_Itemparticle[400];


void InitItem()
{
	WEAPON*pweapon = Getweapon();

	g_Textureweapongun = LoadTexture((char*)"data/TEXTURE/gunchoise.png");
	g_Textureweaponchain = LoadTexture((char*)"data/TEXTURE/chainchoise.png");
	g_Textureweaponlance = LoadTexture((char*)"data/TEXTURE/lancechoise.png");
	g_Textureweaponchoise = LoadTexture((char*)"data/TEXTURE/weaponchoise.png");
	g_Textureaim = LoadTexture((char*)"data/TEXTURE/aimarrow.png");
	g_Textureweaponparticle = LoadTexture((char*)"data/TEXTURE/particletable.png");


	//g_Mousepos = GetMouseLocalPos();
	pweapon->windgun = false;
	pweapon->windchain = false;
	pweapon->windlance = false;
	pweapon->hookgun = false;
	pweapon->hookchain = false;
	pweapon->hooklance = false;
	pweapon->firegun = false;
	pweapon->firechain = false;
	pweapon->firelance = false;
	g_Itemstack.choise = 0;

	g_Itemstack.gun = 0;
	g_Itemstack.chain = 0;
	g_Itemstack.staff = 0;

}

void UpdateItem()
{
	PLAYERBIRD* pBird = GetBird();
	PLAYER*pPlayer = GetPlayer();
	WEAPON*pweapon = Getweapon();


	if (IsButtonTriggered(0 , XINPUT_GAMEPAD_RIGHT_SHOULDER) && pBird->actstyle == false)
	{
		if (g_Itemstack.choise == 2)
		{
			g_Itemstack.choise = 0;
		}
		else
		{
			g_Itemstack.choise += 1;
		}
		g_Itemstack.wheel = 0;
	}

	if (IsButtonTriggered(0, XINPUT_GAMEPAD_LEFT_SHOULDER) && pBird->actstyle == false)
	{
		if (g_Itemstack.choise == 0)
		{
			g_Itemstack.choise = 2;
		}
		else
		{
			g_Itemstack.choise -= 1;
		}
		g_Itemstack.wheel = 0;

	}

	if (g_Itemstack.stack >= 1)
	{
		if (g_Itemstack.choise == 0)
		{
			g_Itemstack.gun = g_Itemstack.stack;
		}
		if (g_Itemstack.choise == 1)
		{
			g_Itemstack.chain = g_Itemstack.stack;
		}
		if (g_Itemstack.choise == 2)
		{
			g_Itemstack.staff = g_Itemstack.stack;
		}
		g_Itemstack.stack = 0;
	}

	if (IsButtonTriggered(0, XINPUT_GAMEPAD_B)) //LeftMouseTriggered
	{
		pPlayer->aimmode = true;
	}
	else if (GetRightTrigger(0) > 200) //DIK_S
	{
		pPlayer->aimmode = false;
	}
	else if (IsButtonPressed(0, XINPUT_GAMEPAD_B))  //LeftMousePressed
	{
		
	}
	else
	{
		if (pPlayer->aimmode == true)
		{
			switch (g_Itemstack.choise)
			{
			case 0:
				Switchgun();
				break;

			case 1:
				Switchchain();
				break;

			case 2:
				Switchlance();
				break;

			}

			pPlayer->aimmode = false;
		}
	}


	if (g_Itemstack.particlecount >= 2)
	{
		if (g_Itemstack.gun >= 1)
		{
			if (g_Itemparticle[g_Itemstack.cell].use == false)
			{
				g_Itemparticle[g_Itemstack.cell].pos.x = 80.0f + (78.0f - (frand() * 156.0f));
				g_Itemparticle[g_Itemstack.cell].pos.y = 1058.0f;
				g_Itemparticle[g_Itemstack.cell].use = true;
			}
		}
		if (g_Itemstack.chain >= 1)
		{
			if (g_Itemparticle[g_Itemstack.cell + 100].use == false)
			{
				g_Itemparticle[g_Itemstack.cell + 100].pos.x = 236.0f + (78.0f - (frand() * 156.0f));
				g_Itemparticle[g_Itemstack.cell + 100].pos.y = 1058.0f;
				g_Itemparticle[g_Itemstack.cell + 100].use = true;
			}
		}
		if (g_Itemstack.staff >= 1)
		{
			if (g_Itemparticle[g_Itemstack.cell + 200].use == false)
			{
				g_Itemparticle[g_Itemstack.cell + 200].pos.x = 392.0f + (78.0f - (frand() * 156.0f));
				g_Itemparticle[g_Itemstack.cell + 200].pos.y = 1058.0f;
				g_Itemparticle[g_Itemstack.cell + 200].use = true;
			}
		}
		g_Itemstack.particlecount = 0;
		g_Itemstack.cell++;
	}
	if (g_Itemstack.cell >= 100)
	{
		g_Itemstack.cell = 0;
	}
	g_Itemstack.particlecount++;
	for (int i = 0; i < 300; i++)
	{
		if (g_Itemparticle[i].use == true)
		{
			g_Itemparticle[i].pos.y -= 1.0f;
			g_Itemparticle[i].useframe++;
			if (g_Itemparticle[i].useframe >= 200)
			{
				g_Itemparticle[i].use = false;
				g_Itemparticle[i].useframe = 0;
			}
		}
	}


}

void DrawItem()
{
	PLAYER*pPlayer = GetPlayer();
	D3DXVECTOR2 basePos = GetBase();

	for (int i = 0; i < 100; i++)
	{
		if (g_Itemparticle[i].use == true)
		{
			DrawSprite(g_Textureweaponparticle, g_Itemparticle[i].pos.x, g_Itemparticle[i].pos.y, 5.0f, 5.0f, 0.25f * g_Itemstack.gun, 0.0f, 0.25f, 1.0f);
		}
	}
	for (int i = 100; i < 200; i++)
	{
		if (g_Itemparticle[i].use == true)
		{
			DrawSprite(g_Textureweaponparticle, g_Itemparticle[i].pos.x, g_Itemparticle[i].pos.y, 5.0f, 5.0f, 0.25f * g_Itemstack.chain, 0.0f, 0.25f, 1.0f);
		}
	}
	for (int i = 200; i < 300; i++)
	{
		if (g_Itemparticle[i].use == true)
		{
			DrawSprite(g_Textureweaponparticle, g_Itemparticle[i].pos.x, g_Itemparticle[i].pos.y, 5.0f, 5.0f, 0.25f * g_Itemstack.staff, 0.0f, 0.25f, 1.0f);
		}
	}

	DrawSprite(g_Textureweapongun, 80.0f, 960.0f, 156.0f, 156.0f, 0.0f + 0.25f * g_Itemstack.gun, 0.0f, 1.0f / 4, 1.0f);
	DrawSprite(g_Textureweaponchain, 236.0f, 960.0f, 156.0f, 156.0f, 0.0f + 0.25f * g_Itemstack.chain, 0.0f, 1.0f / 4, 1.0f);
	DrawSprite(g_Textureweaponlance, 392.0f, 960.0f, 156.0f, 156.0f, 0.0f + 0.25f * g_Itemstack.staff, 0.0f, 1.0f / 4, 1.0f);
	DrawSprite(g_Textureweaponchoise, 80.0f + (156.0f * g_Itemstack.choise), 960.0f, 156.0f, 156.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	
	
	if (pPlayer->aimmode == true)
	{
		D3DXVECTOR2 vel(GetThumbLeftX(0) * -1.0f, GetThumbLeftY(0));
		D3DXVec2Normalize(&vel, &vel);

		if (g_Itemstack.choise == 0 && g_Itemstack.gun == 1)
		{
			g_Itemstack.arrotate = atan2f(vel.y, vel.x) + 1.54f;

			DrawSpriteColorRotate(g_Textureaim, basePos.x + pPlayer->pos.x, basePos.y + pPlayer->pos.y, 64.0f, 640.0f,
				0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_Itemstack.arrotate);

		}
		else if (g_Itemstack.choise == 1 && g_Itemstack.chain == 2)
		{
			g_Itemstack.arrotate = atan2f(vel.y + 2.5f, vel.x) - 1.54f;

			DrawSpriteColorRotate(g_Textureaim, basePos.x + pPlayer->pos.x, basePos.y + pPlayer->pos.y, 64.0f, 640.0f,
				0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_Itemstack.arrotate);

		}
		else if ((g_Itemstack.choise == 1 && g_Itemstack.chain == 1) || (g_Itemstack.choise == 2 && g_Itemstack.staff == 1))
		{

		}
		else
		{
			g_Itemstack.arrotate = atan2f(vel.y, vel.x) - 1.54f;
			DrawSpriteColorRotate(g_Textureaim, basePos.x + pPlayer->pos.x, basePos.y + pPlayer->pos.y, 64.0f, 640.0f,
				0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), g_Itemstack.arrotate);

		}
	}
}



ITEMSTACK* GetItemStack(void)
{
	return &g_Itemstack;
}


void Switchgun()
{

	WEAPON* pWeapon = Getweapon();

	switch (g_Itemstack.gun)
	{
		case 1:
			pWeapon->onetimewindgun = 0;
			pWeapon->windgun = true;
			break;
		case 2:
			pWeapon->onetimehookgun = 0;
			pWeapon->hookgun = true;
			break;

		case 3:
			pWeapon->onetimefiregun = 0;
			pWeapon->firegun = true;
			break;
	}


	g_Itemstack.gun = 0;

}

void Switchchain()
{
	WEAPON* pWeapon = Getweapon();

	switch (g_Itemstack.chain)
	{
	case 1:
		pWeapon->onetimewindchain = 0;
		pWeapon->windchain = true;
		break;
	case 2:
		pWeapon->onetimehookchain = 0;
		pWeapon->hookchain = true;
		break;
	case 3:
		pWeapon->onetimefirechain = 0;
		pWeapon->firechain = true;
		break;
	}

	g_Itemstack.chain = 0;

}

void Switchlance()
{

	WEAPON* pWeapon = Getweapon();

	switch (g_Itemstack.staff)
	{
	case 1:
		pWeapon->onetimewindlance = 0;
		pWeapon->windlance = true;
		break;
	case 2:
		pWeapon->onetimehooklance = 0;
		pWeapon->hooklance = true;
		break;
	case 3:
		pWeapon->onetimefirelance = 0;
		pWeapon->firelance = true;
		break;
	}

	g_Itemstack.staff = 0;

}