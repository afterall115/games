#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "map.h"
#include "Itemspot.h"
#include "Itemstack.h"
#include "breakstone.h"

static STONE g_stone[50];
static int   g_TextureStone = 0;
void InitStone(void)
{
	D3DXVECTOR2 basePos = GetBase();
	for (int i = 0; i < g_stone[1].usecount; i++)
	{
		g_stone[i].use = true;
		g_stone[i].stonesound = true;
	}
	g_TextureStone = LoadTexture((char*)"data/TEXTURE/BreakableStone.png");
	//basePos.x + pStone->pos.x, basePos.y + pStone->pos.y - 45
}
void UninitStone(void)
{

}
void UpdateStone(void)
{
	PLAYER* pPlayer = GetPlayer();
	for (int i = 0; i < g_stone[1].usecount; i++)
	{
		if (HitCheckBox(pPlayer->pos, 64.0f, 60.0f, g_stone[i].pos, 98.0f, 98.0f))
		{
			if (HitCheckField(pPlayer->pos, 44.0f, 80.0f, g_stone[i].pos, 96.0f, 96.0f))
			{
				pPlayer->pos.y = g_stone[i].pos.y - 88.0f;
				pPlayer->gravityscale = 0.0f;
			}
			if (HitCheckwallleft(pPlayer->pos, 44.0f, 80.0f, g_stone[i].pos, 96.0f, 96.0f))
			{
				pPlayer->pos.x = g_stone[i].pos.x + 70.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckwallright(pPlayer->pos, 44.0f, 80.0f, g_stone[i].pos, 96.0f, 96.0f))
			{
				pPlayer->pos.x = g_stone[i].pos.x - 70.0f;
				pPlayer->moveinpulse = 0.0f;
			}
			if (HitCheckCelling(pPlayer->pos, 44.0f, 80.0f, g_stone[i].pos, 96.0f, 96.0f))
			{
				pPlayer->jumpPower = 0.0f;
				pPlayer->pos.y = g_stone[i].pos.y + 90.0f;

			}
		}
	}
}
void DrawStone(void)
{
	D3DXVECTOR2 basePos = GetBase();

	for (int i = 0; i < g_stone[1].usecount; i++)
	{
		DrawSprite(g_TextureStone, g_stone[i].pos.x, basePos.y + g_stone[i].pos.y - 45, 96.0f, 96.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}
}

STONE* GetStone(void)
{
	return &g_stone[0];
}