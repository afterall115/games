#include "player.h"
#include "inputx.h"
#include "texture.h"
#include "sprite.h"
#include "camera.h"
#include "collision.h"
#include "fieldcollision.h"
#include "weapon.h"
#include "map.h"
#include "toge.h"

//===================================================

static int   g_TextureToge = 0;

static THORN g_Togegimmick[500];

static int count = 0;

static float togetable[4]=
{
	0.0f,
	1.57f,
	3.14f,
	4.71f

};

void InitThorn(void)
{

	g_TextureToge = LoadTexture((char*)"data/TEXTURE/toge.png");

}

void UninitThorn(void)
{

}

void UpdateThorn(void)
{

	PLAYER* pPlayer = GetPlayer();
	WEAPON* pweapon = Getweapon();

	for (int x = 0; x < g_Togegimmick[1].usecount; x++)
	{
		if (g_Togegimmick[x].use == true)
		{
			if (HitCheckBox(pweapon->hooklancepos, 172.0f, 30.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
			{
				pweapon->lancehit = true;
			}
			if (HitCheckBox(pPlayer->pos, 88.0f, 150.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
			{
				if (HitCheckField(pPlayer->pos,88.0f, 140.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.y = g_Togegimmick[x].pos.y - 102.0f;
					pPlayer->gravityscale = 0.0f;
					pPlayer->jumpFlag = false;
					if (pPlayer->hitcool <= 0 && g_Togegimmick[x].muki == 0)
					{
						pPlayer->hit = true;
						pPlayer->gravityscale = -4.0f;
						pPlayer->hitcool = 100;
						pPlayer->moveinpulse = 0.0f;
					}
				}
				if (HitCheckwallleft(pPlayer->pos, 88.0f, 140.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.x = g_Togegimmick[x].pos.x + 76.0f;

					if (pPlayer->hitcool <= 0 && g_Togegimmick[x].muki == 1 && pPlayer->hit == false)
					{
						pPlayer->hit = true;
						pPlayer->moveinpulse = 12.0f;
						pPlayer->hitcool = 100;
						pPlayer->moveinpulse = 0.0f;
					}

				}
				if (HitCheckwallright(pPlayer->pos, 88.0f, 140.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.x = g_Togegimmick[x].pos.x - 76.0f;

					if (pPlayer->hitcool <= 0 && g_Togegimmick[x].muki == 3 && pPlayer->hit == false)
					{
						pPlayer->hit = true;
						pPlayer->moveinpulse = -12.0f;
						pPlayer->hitcool = 100;
						pPlayer->moveinpulse = 0.0f;

					}
				}
				if (HitCheckCelling(pPlayer->pos, 88.0f, 140.0f, g_Togegimmick[x].pos, 64.0f, 64.0f))
				{
					pPlayer->pos.y = g_Togegimmick[x].pos.y + 110.0f;

					if (pPlayer->hitcool <= 0 && g_Togegimmick[x].muki == 2 && pPlayer->hit == false)
					{
						pPlayer->hit = true;
						pPlayer->hitcool = 100;
						pPlayer->jumpPower = 0.0f;
					}
				}
			}
		}
		g_Togegimmick[x].use = true;

		//if (g_Togegimmick[x].use == false){}

			
	}


}

void DrawThorn(void)
{

	D3DXVECTOR2 basePos = GetBase();

	for (int x = 0; x < g_Togegimmick[1].usecount; x++)
	{
		if (g_Togegimmick[x].use == true)
		{
			DrawSpriteColorRotate(g_TextureToge, basePos.x + g_Togegimmick[x].pos.x, basePos.y + g_Togegimmick[x].pos.y, 64.0f, 64.0f, 0.0f, 0.0f, 1.0f, 1.0f,D3DXCOLOR(1.0f,1.0f,1.0f,1.0f),togetable[g_Togegimmick[x].muki]);
			
		}
	}
}

THORN* GetThorn(void)
{
	return &g_Togegimmick[0];
}