#include "failed.h"
#include "sound.h"
#include "camera.h"
#include "Texture.h"
#include "Sprite.h"
#include "main.h"
#include "inputx.h"

static int g_Textureplayer;
static int g_TextureUI;
static int g_Texturefail;
static int g_TextureUIarrow;
static int g_Texturefadebg;
static int g_Texturefailfont;

struct FAIL g_fail;

void Initfail(void)
{
	g_Textureplayer = LoadTexture((char*)"data/TEXTURE/player.png");
	g_Texturefail = LoadTexture((char*)"data/TEXTURE/fail.png");
	g_TextureUI = LoadTexture((char*)"data/TEXTURE/UI_00.png");
	g_TextureUIarrow = LoadTexture((char*)"data/TEXTURE/hooklance.png");
	g_Texturefadebg = LoadTexture((char*)"data/TEXTURE/fadebg.png");
	g_Texturefailfont = LoadTexture((char*)"data/TEXTURE/resultui.png");

	g_fail.animtime = 0;
	g_fail.gravity = -10.0f;
	g_fail.rotate = 0;
	g_fail.pos.x = 960.0f;
	g_fail.pos.y = 540.0f;
	g_fail.fade = 0;
	g_fail.revenge = false;
	g_fail.uicolor = 0;
}

void Uninitfail(void)
{

}

void Updatefail(void)
{
	g_fail.animtime++;

	if (g_fail.animtime >= 60)
	{
		g_fail.pos.x -= 2.0f;
		g_fail.pos.y += g_fail.gravity;
		g_fail.gravity += 0.5f;
		g_fail.rotate -= 0.1f;
	}
	if (g_fail.animtime >= 100)
	{
		g_fail.uicolor += 0.05f;

		if (GetThumbLeftXTriggered(0, -0.9f)) //DIK_A
		{
			g_fail.choise = 0;
		}
		if (GetThumbLeftXTriggered(0, 0.9f)) //DIK_D
		{
			g_fail.choise = 1;
		}

		if (IsButtonTriggered(0, XINPUT_GAMEPAD_B)) //DIK_SPACE
		{
			g_fail.revenge = true;
		}
		if (g_fail.revenge == true)
		{
			g_fail.fade += 0.05f;
			if (g_fail.fade >= 1.0f && g_fail.choise == 0)
			{
				SetScene(SCENE_GAME);
			}
			if (g_fail.fade >= 1.0f && g_fail.choise == 1)
			{
				SetScene(SCENE_TITLE);
			}
		}
	}
}

void Drawfail(void)
{
	DrawSpriteColorRotate(g_Textureplayer, g_fail.pos.x, g_fail.pos.y, 172.0f, 172.0f, 0.0f, 0.1f, 0.1f, 0.1f,D3DXCOLOR(1.0f,1.0f,1.0f,1.0f),g_fail.rotate);

	DrawSpriteColorRotate(g_Texturefail, 960.0f, 220.0f, 1280.0f, 256.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_fail.uicolor), 0.0f);

	for (int i = 0; i < 2; i++)
	{
		DrawSpriteColorRotate(g_TextureUI, 704.0f + (512.0f * i), 720.0f, 440.0f, 128.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_fail.uicolor), 0.0f);
	
		DrawSpriteColorRotate(g_Texturefailfont, 704.0f + (512.0f * i), 720.0f, 440.0f, 96.0f, 0.0f, 0.0f + (0.333333f * i * 2), 1.0f, 0.333333f,D3DXCOLOR(1.0f,1.0f,1.0f,g_fail.uicolor),0.0f);
	}
	DrawSpriteColorRotate(g_TextureUIarrow, 430.0f + (512.0f * g_fail.choise), 720.0f, 128.0f, 64.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_fail.uicolor), 0.0f);

	DrawSpriteColorRotate(g_Texturefadebg, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_fail.fade), 0.0f);
}