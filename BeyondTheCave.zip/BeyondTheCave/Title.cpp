
#include "Texture.h"
#include "sprite.h"
#include "renderer.h"
#include "inputx.h"
#include "Title.h"
#include "main.h"
#include "sound.h"
#include "fade.h"

#define MODE_CHOISE  3

static int g_TextureTitleUI;
static int g_TextureTitleUI2;
static int g_Texturestageselect;
static int g_Textureback;
static int g_Texturemode;
static int g_title;
static int g_title2;
static int g_titlelight;
static int g_titleeffect;
static int g_rogo;
static int g_Textureconfig;


static int g_BGMtitle;
static int g_SEUIchoise;
static int g_SEUIdecide;
static int g_SEUIcansel;
static int g_SEUIstart;

static TITLE g_Title[STAGE_NUMBER + 1];
static TITLECOUNT g_Titlecount;
static MODEUI g_mode[MODE_CHOISE + 1];

static TITLEEFFECT g_Titleeffe[100];

static float g_stagetitle[5]=
{
	0.0f,
	0.2f,
	0.4f,
	0.6f,
	0.8f
};

static float g_modetitle[3]=
{
	0.0f,
	0.333333f,
	0.666667f
};


void InitTitle()
{
	g_title = LoadTexture((char*)"data/TEXTURE/taitoru.png");
	g_title2 = LoadTexture((char*)"data/TEXTURE/taitoru2.png");
	g_titlelight = LoadTexture((char*)"data/TEXTURE/light.png");
	g_titleeffect = LoadTexture((char*)"data/TEXTURE/fireparticle.png");
	g_rogo = LoadTexture((char*)"data/TEXTURE/rogo.png");
	g_Textureconfig = LoadTexture((char*)"data/TEXTURE/menu.png");

	g_TextureTitleUI = LoadTexture((char*)"data/TEXTURE/UI_00.png");
	g_TextureTitleUI2 = LoadTexture((char*)"data/TEXTURE/UI_01.png");
	g_Texturestageselect = LoadTexture((char*)"data/TEXTURE/stagetitle.png");
	g_Textureback = LoadTexture((char*)"data/TEXTURE/back.png");
	g_Texturemode = LoadTexture((char*)"data/TEXTURE/modechoise.png");
	g_BGMtitle = LoadSound((char*)"data/BGM/title.wav");
	g_SEUIchoise = LoadSound((char*)"data/SE/choise.wav");
	g_SEUIdecide = LoadSound((char*)"data/SE/decide.wav");
	g_SEUIcansel = LoadSound((char*)"data/SE/cansel.wav");
	g_SEUIstart = LoadSound((char*)"data/SE/start.wav");


	//�X�e�[�W�I��UI�̍��W��쐬
	for (int i = 1; i <= STAGE_NUMBER; i++)
	{
		g_Title[i].purpos.x = 1600.0f + (200.0f * i);
		g_Title[i].purpos.y = 940.0f - (160.0f * i);
	}
	for (int n = 1; n <= MODE_CHOISE; n++)
	{
		g_mode[n].purpos.x = 1700.0f;
		g_mode[n].purpos.y = 520.0f + (160.0f * n);
	}
	g_Titlecount.choise = 1;
	g_Titlecount.modechoise = 1;
	g_Titlecount.stagechoise = false;

	Setfadein();
	PlaySound(g_BGMtitle, -1);


	for (int k = 0; k < 100; k++)
	{
		g_Titleeffe[k].use = false;
	}

	g_Titlecount.start = false;

}

void UninitTitle()
{
	StopSound(g_BGMtitle);
}

void UpdateTitle()
{
	FADECENTER* pfadec = Getfadec();
	if (pfadec->fadeON == false)
	{

		if (GetThumbLeftYTriggered(0, 0.9f)) //DIK_W
		{
			PlaySound(g_SEUIchoise, 0);

			if (g_Titlecount.stagechoise == false)
			{
				if (g_Titlecount.modechoise == 1)
				{
					g_Titlecount.modechoise = 3;
				}
				else
				{
					g_Titlecount.modechoise--;
				}
			}
		}
		if (GetThumbLeftYTriggered(0, -0.9f)) //DIK_S
		{
			PlaySound(g_SEUIchoise, 0);

			if (g_Titlecount.stagechoise == false)
			{
				if (g_Titlecount.modechoise == 3)
				{
					g_Titlecount.modechoise = 1;
				}
				else
				{
					g_Titlecount.modechoise++;
				}
			}
		}

		if (IsButtonTriggered(0, XINPUT_GAMEPAD_B)) //DIK_SPACE
		{
			if (g_Titlecount.modechoise == 1)
			{

				if (g_Titlecount.stagechoise == true)
				{
					if (g_Titlecount.choise == 6)
					{
						PlaySound(g_SEUIcansel, 0);
						g_Titlecount.stagechoise = false;
					}
					else
					{
						PlaySound(g_SEUIstart, 0);
						Setfadeout();
					}
				}
				else
				{
					PlaySound(g_SEUIdecide, 0);
					g_Titlecount.choise = 1;
					g_Titlecount.stagechoise = true;
				}
			}
			if (g_Titlecount.modechoise == 2)
			{
				PlaySound(g_SEUIchoise, 0);

				g_Titlecount.config = true;

			}
			if (g_Titlecount.modechoise == 3)
			{
				g_Titlecount.choise = 6;
				PlaySound(g_SEUIstart, 0);
				Setfadeout();

			}
		}

		if (IsButtonTriggered(0, XINPUT_GAMEPAD_A)) //DIK_B
		{
			if (g_Titlecount.stagechoise == true)
			{
				PlaySound(g_SEUIcansel, 0);
				g_Titlecount.stagechoise = false;
			}
			if (g_Titlecount.config == true)
			{
				PlaySound(g_SEUIcansel, 0);
				g_Titlecount.config = false;
			}
		}

		//���[�h�I��UI�̏���

		for (int i = 1; i <= MODE_CHOISE; i++)
		{
			if (g_Titlecount.stagechoise == false)
			{
				if (g_Titlecount.modechoise == i)
				{
					g_mode[i].pos.x -= (g_mode[i].pos.x - (g_mode[i].purpos.x - 200.0f)) * 0.1f;
					g_mode[i].pos.y = g_mode[i].purpos.y;
				}

				else
				{
					g_mode[i].pos.x -= (g_mode[i].pos.x - g_mode[i].purpos.x) * 0.1f;
					g_mode[i].pos.y = g_mode[i].purpos.y;

				}
			}

			else
			{
				g_mode[i].pos.x = 4000.0f;
				g_mode[i].pos.y = 2000.0f;
			}
		}

		//�X�e�[�W�I��UI�̏���
		if (GetThumbLeftYTriggered(0, 0.9f)) //DIK_W
		{
			if (g_Titlecount.choise >= STAGE_NUMBER && g_Titlecount.stagechoise == true)
			{
				g_Titlecount.choise = 1;
			}
			else
			{
				g_Titlecount.choise++;
			}
		}
		if (GetThumbLeftYTriggered(0, -0.9f)) //DIK_S
		{
			if (g_Titlecount.choise <= 1 && g_Titlecount.stagechoise == true)
			{
				g_Titlecount.choise = STAGE_NUMBER;
			}
			else
			{
				g_Titlecount.choise -= 1;
			}
		}


		for (int i = 1; i <= STAGE_NUMBER; i++)
		{
			if (g_Titlecount.modechoise == 1 && g_Titlecount.stagechoise == true)
			{
				if (g_Titlecount.choise == i)
				{
					g_Title[i].pos.x -= (g_Title[i].pos.x - (g_Title[i].purpos.x - (200.0f * g_Titlecount.choise)) + 400.0f)  * 0.1f;
					g_Title[i].pos.y -= (g_Title[i].pos.y - (g_Title[i].purpos.y + (160.0f * g_Titlecount.choise)))  * 0.1f;
				}
				else
				{
					g_Title[i].pos.x -= (g_Title[i].pos.x - (g_Title[i].purpos.x - (200.0f * g_Titlecount.choise)))  * 0.1f;
					g_Title[i].pos.y -= (g_Title[i].pos.y - (g_Title[i].purpos.y + (160.0f * g_Titlecount.choise)))  * 0.1f;
				}
			}
			else
			{
				g_Title[i].pos.x = 4000.0f;
				g_Title[i].pos.y = 2000.0f;
			}
		}
	}
	
	if (fadeoutOK())
	{
		SetScene(SCENE_GAME);
	}


	if (g_Titlecount.titlecolor >= 0.8f)
	{
		g_Titlecount.titlecolorcon = false;
	}
	if (g_Titlecount.titlecolor <= 0.0f)
	{
		g_Titlecount.titlecolorcon = true;
	}

	if (g_Titlecount.titlecolorcon == true)
	{
		g_Titlecount.titlecolor += 0.0075f;
	}
	else
	{
		g_Titlecount.titlecolor -= 0.0075f;
	}
	for (int i = 0; i < 100; i++)
	{
		if (g_Titlecount.particlecount >= 5 && g_Titleeffe[i].use == false)
		{
			g_Titleeffe[i].pos.x = 760.0f + (frand() * 300.0f);
			g_Titleeffe[i].pos.y = 770.0f - (frand() * 100.0f);
			g_Titleeffe[i].size = 8.0f;
			g_Titleeffe[i].xrand = 3.0f - (frand() * 6.0f);
			g_Titleeffe[i].use = true;
			g_Titlecount.particlecount = 0;
		}

		if (g_Titleeffe[i].use == true)
		{
			g_Titleeffe[i].pos.x += g_Titleeffe[i].xrand;
			g_Titleeffe[i].pos.y -=  frand() * 6.0f;
			g_Titleeffe[i].size -= 0.05f;
		}

		if (g_Titleeffe[i].size <= 0.0f)
		{
			g_Titleeffe[i].use = false;
		}
	}
	g_Titlecount.particlecount++;

}

void DrawTitle()
{

	DrawSprite(g_title, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	DrawSpriteColorRotate(g_title2, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f, D3DXCOLOR(1.0f, 1.0f, 1.0f, g_Titlecount.titlecolor), 0.0f);
	DrawSpriteColorRotate(g_titlelight, 960.0f, 540.0f, 1920.0f, 1080.0f, 0.0f, 0.0f, 1.0f, 1.0f,D3DXCOLOR(1.0f,1.0f,1.0f,1.0f - g_Titlecount.titlecolor),0.0f);

	for (int i = 0 ; i < 100; i++)
	{
		if (g_Titleeffe[i].use == true)
		{
			DrawSprite(g_titleeffect, g_Titleeffe[i].pos.x, g_Titleeffe[i].pos.y, g_Titleeffe[i].size, g_Titleeffe[i].size, 0.0f, 0.0f, 1.0f, 1.0f);
		}
	}
	for (int i = 1; i <= STAGE_NUMBER; i++)
	{
		DrawSprite(g_TextureTitleUI2, g_Title[i].pos.x, g_Title[i].pos.y, 920.0f, 160.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		if (i == 6)
		{
			DrawSprite(g_Textureback, g_Title[i].pos.x, g_Title[i].pos.y, 920.0f, 160.0f, 0.0f, 0.0f, 1.0f, 1.0f);

		}
		else
		{
			DrawSprite(g_Texturestageselect, g_Title[i].pos.x, g_Title[i].pos.y, 860.0f, 160.0f, 0.0f, g_stagetitle[i - 1], 1.0f, 0.2f);
		}
	}
	for (int i = 1; i <= MODE_CHOISE; i++)
	{
		DrawSprite(g_TextureTitleUI, g_mode[i].pos.x, g_mode[i].pos.y, 920.0f, 160.0f, 0.0f, 0.0f, 1.0f, 1.0f);
		DrawSprite(g_Texturemode, g_mode[i].pos.x, g_mode[i].pos.y, 860.0f, 160.0f, 0.0f, g_modetitle[i - 1], 1.0f, 0.3333333f);
	}

	DrawSprite(g_rogo, 960.0f, 200.0f, 1650.0f, 550.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	if (g_Titlecount.config == true)
	{
		DrawSprite(g_Textureconfig, 960.0f, 540.0f, 1280.0f, 720.0f, 0.0f, 0.0f, 1.0f, 1.0f);
	}


}

TITLECOUNT* GetTitlecount(void)
{
	return &g_Titlecount;

}