#pragma once

#include "main.h"
#include "renderer.h"

struct ICEBOX
{
	D3DXVECTOR2 pos;

	bool iceuse;

	float ice;

	int usecount;
	bool use;

	float size;
};

void Initice(void);
void Uninitice(void);
void Updateice(void);
void Drawice(void);

ICEBOX* Getice(void);